/* =====================================================================
   CONTENU DES PAGES D'INFORMATION (4 langues)
   Aide, sécurité, règles, conditions, confidentialité (nLPD),
   mentions légales, à propos.
   ===================================================================== */

export const PAGE_ORDER = ["aide", "securite", "regles", "conditions", "confidentialite", "mentions-legales", "a-propos"];

const EMERGENCY = {
  fr: ["117 — Police", "144 — Urgences sanitaires / ambulance", "118 — Pompiers", "112 — Numéro d'urgence européen", "143 — La Main Tendue (écoute, 24 h/24)", "147 — Pro Juventute (enfants et jeunes)"],
  de: ["117 — Polizei", "144 — Sanitätsnotruf", "118 — Feuerwehr", "112 — Europäische Notrufnummer", "143 — Die Dargebotene Hand (rund um die Uhr)", "147 — Pro Juventute (Kinder und Jugendliche)"],
  it: ["117 — Polizia", "144 — Emergenza sanitaria / ambulanza", "118 — Pompieri", "112 — Numero d'emergenza europeo", "143 — Telefono Amico (24 ore su 24)", "147 — Pro Juventute (bambini e giovani)"],
  en: ["117 — Police", "144 — Medical emergency / ambulance", "118 — Fire brigade", "112 — European emergency number", "143 — Die Dargebotene Hand / La Main Tendue (24/7 listening line)", "147 — Pro Juventute (children and young people)"],
};

export const PAGES = {
  /* ------------------------------------------------------------ AIDE */
  aide: {
    fr: {
      title: "Aide & questions fréquentes",
      intro: "Tout ce qu'il faut savoir pour bien démarrer sur Voisina.",
      sections: [
        { h: "Premiers pas", qa: [
          ["Qu'est-ce que Voisina ?", "Voisina est une plateforme d'entraide entre voisins, partout en Suisse. Vous pouvez proposer un coup de main, demander de l'aide ou donner un objet, gratuitement ou contre une petite rémunération."],
          ["Est-ce gratuit ?", "Oui. Publier, rechercher et discuter est entièrement gratuit. Voisina ne prend aucune commission et n'affiche aucune publicité."],
          ["Faut-il un compte ?", "Vous pouvez consulter les annonces et les ajouter à vos favoris sans compte. Pour publier une annonce ou écrire à un membre, un compte gratuit est nécessaire."],
        ] },
        { h: "Publier une annonce", qa: [
          ["Comment écrire une bonne annonce ?", "Choisissez un titre court et précis, décrivez clairement le besoin ou l'aide proposée, indiquez une date si possible et précisez si c'est gratuit, rémunéré ou à discuter."],
          ["Mon adresse sera-t-elle visible ?", "Non, jamais. Seule votre localité est affichée et la position sur la carte est volontairement floutée d'environ un kilomètre."],
          ["Puis-je modifier ou supprimer mon annonce ?", "Oui, à tout moment depuis « Mon compte › Mes annonces ». Vous pouvez aussi la marquer comme terminée une fois l'entraide réalisée."],
          ["Puis-je ajouter des photos ?", "Oui, jusqu'à trois. Elles sont automatiquement redimensionnées et leurs métadonnées (dont la position GPS enregistrée par les smartphones) sont supprimées."],
        ] },
        { h: "Contacter un membre", qa: [
          ["Comment contacter l'auteur d'une annonce ?", "Cliquez sur « Contacter » sur la page de l'annonce. Une conversation s'ouvre dans la messagerie, sans que votre numéro ou votre e-mail ne soient partagés."],
          ["Que faire en cas de comportement suspect ?", "Utilisez le bouton « Signaler » (sur l'annonce, le profil ou la conversation) et, si besoin, bloquez la personne. En cas de danger, appelez le 117."],
        ] },
        { h: "Compte et données", qa: [
          ["Comment exporter ou supprimer mes données ?", "Dans « Mon compte › Mes données », vous pouvez télécharger toutes vos données (fichier JSON) ou supprimer définitivement votre compte."],
          ["J'ai oublié mon mot de passe", "Dans cette version de démonstration, il n'existe pas encore d'envoi d'e-mail de réinitialisation : créez simplement un nouveau compte. La version serveur ajoutera cette fonction."],
        ] },
      ],
    },
    de: {
      title: "Hilfe & häufige Fragen",
      intro: "Alles, was Sie für einen guten Start auf Voisina wissen müssen.",
      sections: [
        { h: "Erste Schritte", qa: [
          ["Was ist Voisina?", "Voisina ist eine Plattform für Nachbarschaftshilfe in der ganzen Schweiz. Sie können Hilfe anbieten, um Hilfe bitten oder Gegenstände verschenken – kostenlos oder gegen eine kleine Entschädigung."],
          ["Ist Voisina kostenlos?", "Ja. Inserieren, Suchen und Schreiben sind komplett kostenlos. Voisina verlangt keine Kommission und zeigt keine Werbung."],
          ["Brauche ich ein Konto?", "Anzeigen ansehen und als Favoriten speichern geht ohne Konto. Um zu inserieren oder einem Mitglied zu schreiben, brauchen Sie ein kostenloses Konto."],
        ] },
        { h: "Eine Anzeige erstellen", qa: [
          ["Wie schreibe ich eine gute Anzeige?", "Wählen Sie einen kurzen, präzisen Titel, beschreiben Sie klar, was Sie brauchen oder anbieten, geben Sie wenn möglich ein Datum an und ob es kostenlos, bezahlt oder verhandelbar ist."],
          ["Ist meine Adresse sichtbar?", "Nein, nie. Angezeigt wird nur Ihr Ort; die Position auf der Karte ist absichtlich um etwa einen Kilometer ungenau."],
          ["Kann ich meine Anzeige ändern oder löschen?", "Ja, jederzeit unter «Mein Konto › Meine Anzeigen». Nach erfolgter Hilfe können Sie sie auch als erledigt markieren."],
          ["Kann ich Fotos hinzufügen?", "Ja, bis zu drei. Sie werden automatisch verkleinert und ihre Metadaten (inklusive der GPS-Position von Smartphones) werden entfernt."],
        ] },
        { h: "Ein Mitglied kontaktieren", qa: [
          ["Wie kontaktiere ich jemanden?", "Klicken Sie auf der Anzeige auf «Kontaktieren». Es öffnet sich ein Chat – ohne dass Telefonnummer oder E-Mail geteilt werden."],
          ["Was tun bei verdächtigem Verhalten?", "Nutzen Sie «Melden» (bei Anzeige, Profil oder Chat) und blockieren Sie die Person bei Bedarf. Bei Gefahr rufen Sie 117 an."],
        ] },
        { h: "Konto und Daten", qa: [
          ["Wie exportiere oder lösche ich meine Daten?", "Unter «Mein Konto › Meine Daten» können Sie alle Ihre Daten herunterladen (JSON-Datei) oder Ihr Konto endgültig löschen."],
          ["Ich habe mein Passwort vergessen", "In dieser Demoversion gibt es noch keine E-Mail zum Zurücksetzen: Erstellen Sie einfach ein neues Konto. Die Serverversion wird diese Funktion ergänzen."],
        ] },
      ],
    },
    it: {
      title: "Aiuto e domande frequenti",
      intro: "Tutto ciò che serve sapere per iniziare bene su Voisina.",
      sections: [
        { h: "Primi passi", qa: [
          ["Che cos'è Voisina?", "Voisina è una piattaforma di aiuto tra vicini in tutta la Svizzera. Potete offrire una mano, chiedere aiuto o regalare un oggetto, gratuitamente o con un piccolo compenso."],
          ["È gratuito?", "Sì. Pubblicare, cercare e scrivere è completamente gratuito. Voisina non prende commissioni e non mostra pubblicità."],
          ["Serve un account?", "Potete consultare gli annunci e salvarli nei preferiti senza account. Per pubblicare o scrivere a un membro serve un account gratuito."],
        ] },
        { h: "Pubblicare un annuncio", qa: [
          ["Come scrivere un buon annuncio?", "Scegliete un titolo breve e preciso, descrivete chiaramente il bisogno o l'aiuto offerto, indicate una data se possibile e specificate se è gratuito, retribuito o da concordare."],
          ["Il mio indirizzo sarà visibile?", "No, mai. Viene mostrata solo la località e la posizione sulla carta è volutamente sfocata di circa un chilometro."],
          ["Posso modificare o eliminare l'annuncio?", "Sì, in qualsiasi momento da «Il mio account › I miei annunci». Potete anche segnarlo come concluso."],
          ["Posso aggiungere foto?", "Sì, fino a tre. Vengono ridimensionate automaticamente e i metadati (compresa la posizione GPS registrata dagli smartphone) vengono eliminati."],
        ] },
        { h: "Contattare un membro", qa: [
          ["Come contatto l'autore di un annuncio?", "Cliccate su «Contatta» nella pagina dell'annuncio. Si apre una conversazione, senza condividere numero di telefono o e-mail."],
          ["Cosa fare in caso di comportamento sospetto?", "Usate il pulsante «Segnala» (annuncio, profilo o conversazione) e, se necessario, bloccate la persona. In caso di pericolo chiamate il 117."],
        ] },
        { h: "Account e dati", qa: [
          ["Come esporto o elimino i miei dati?", "In «Il mio account › I miei dati» potete scaricare tutti i vostri dati (file JSON) o eliminare definitivamente l'account."],
          ["Ho dimenticato la password", "In questa versione dimostrativa non esiste ancora l'e-mail di reimpostazione: create semplicemente un nuovo account. La versione con server aggiungerà questa funzione."],
        ] },
      ],
    },
    en: {
      title: "Help & FAQ",
      intro: "Everything you need to get started on Voisina.",
      sections: [
        { h: "Getting started", qa: [
          ["What is Voisina?", "Voisina is a neighbourly help platform covering all of Switzerland. You can offer a hand, ask for help or give items away — for free or for a small fee."],
          ["Is it free?", "Yes. Posting, searching and messaging are completely free. Voisina takes no commission and shows no ads."],
          ["Do I need an account?", "You can browse listings and save favourites without an account. To post a listing or message a member, you need a free account."],
        ] },
        { h: "Posting a listing", qa: [
          ["How do I write a good listing?", "Pick a short, precise title, clearly describe what you need or offer, add a date if possible and say whether it's free, paid or negotiable."],
          ["Will my address be visible?", "No, never. Only your town is shown and the map position is deliberately blurred by about one kilometre."],
          ["Can I edit or delete my listing?", "Yes, at any time from “My account › My listings”. You can also mark it as done once the help has happened."],
          ["Can I add photos?", "Yes, up to three. They are resized automatically and their metadata (including the GPS position smartphones record) is removed."],
        ] },
        { h: "Contacting a member", qa: [
          ["How do I contact someone?", "Click “Contact” on the listing page. A conversation opens in the inbox — your phone number and email are never shared."],
          ["What if someone behaves suspiciously?", "Use the “Report” button (on the listing, profile or conversation) and block the person if needed. If you are in danger, call 117."],
        ] },
        { h: "Account and data", qa: [
          ["How do I export or delete my data?", "In “My account › My data” you can download all your data (JSON file) or permanently delete your account."],
          ["I forgot my password", "This demo version cannot send reset emails yet: simply create a new account. The server version will add this feature."],
        ] },
      ],
    },
  },

  /* ------------------------------------------------------- SÉCURITÉ */
  securite: {
    fr: {
      title: "Conseils de sécurité",
      intro: "L'immense majorité des échanges se passe très bien. Quelques réflexes simples permettent de s'entraider en toute sérénité.",
      sections: [
        { h: "Avant de vous rencontrer", list: [
          "Échangez d'abord via la messagerie de Voisina : ne partagez pas votre numéro, votre adresse ou votre e-mail trop tôt.",
          "Consultez le profil : ancienneté, évaluations, annonces publiées, badge « vérifié ».",
          "Pour une première rencontre, choisissez un lieu public (gare, café, place du village).",
          "Prévenez un proche de l'heure et du lieu du rendez-vous.",
        ] },
        { h: "Argent et paiements", list: [
          "Ne payez jamais à l'avance une personne que vous n'avez pas rencontrée.",
          "Ne communiquez jamais de mot de passe, code SMS, code PIN ou code de confirmation TWINT / e-banking.",
          "Méfiez-vous des demandes de cartes cadeaux, de cryptomonnaies ou de transferts d'argent (Western Union, etc.).",
          "Pour un service rémunéré, convenez du montant par écrit avant de commencer. Le montant affiché sur l'annonce est indicatif.",
        ] },
        { h: "Signes d'alerte", list: [
          "La personne veut absolument quitter la messagerie ou vous presse d'agir.",
          "L'offre est trop belle pour être vraie.",
          "On vous demande des documents d'identité ou des informations bancaires.",
          "Le récit change ou devient incohérent.",
        ] },
        { h: "Personnes vulnérables et enfants", p: [
          "Pour la garde d'enfants ou l'aide aux personnes âgées, prenez le temps de rencontrer la personne, demandez des références et restez joignable. Un mineur ne doit jamais se rendre seul chez un inconnu : parlez-en d'abord à un adulte de confiance.",
        ] },
        { h: "En cas de problème", p: ["Signalez l'annonce, le profil ou la conversation : notre équipe de modération examine chaque signalement. Vous pouvez aussi bloquer une personne à tout moment. En cas d'urgence, contactez directement les services compétents :"], list: EMERGENCY.fr },
      ],
    },
    de: {
      title: "Sicherheitstipps",
      intro: "Die allermeisten Begegnungen verlaufen bestens. Mit ein paar einfachen Regeln helfen Sie sich gegenseitig ganz entspannt.",
      sections: [
        { h: "Vor dem Treffen", list: [
          "Schreiben Sie zuerst über den Voisina-Chat: Teilen Sie Telefonnummer, Adresse oder E-Mail nicht zu früh.",
          "Schauen Sie sich das Profil an: Mitglied seit, Bewertungen, Anzeigen, Badge «verifiziert».",
          "Wählen Sie für das erste Treffen einen öffentlichen Ort (Bahnhof, Café, Dorfplatz).",
          "Sagen Sie einer vertrauten Person, wann und wo Sie sich treffen.",
        ] },
        { h: "Geld und Zahlungen", list: [
          "Bezahlen Sie nie im Voraus jemanden, den Sie nicht getroffen haben.",
          "Geben Sie nie Passwörter, SMS-Codes, PIN-Codes oder Bestätigungscodes für TWINT / E-Banking weiter.",
          "Seien Sie misstrauisch bei Anfragen nach Geschenkkarten, Kryptowährungen oder Geldüberweisungen (Western Union usw.).",
          "Vereinbaren Sie bei bezahlten Diensten den Betrag schriftlich, bevor Sie beginnen. Der Betrag in der Anzeige ist ein Richtwert.",
        ] },
        { h: "Warnsignale", list: [
          "Die Person will unbedingt den Chat verlassen oder setzt Sie unter Druck.",
          "Das Angebot ist zu schön, um wahr zu sein.",
          "Sie werden nach Ausweisen oder Bankdaten gefragt.",
          "Die Geschichte ändert sich oder wird widersprüchlich.",
        ] },
        { h: "Verletzliche Personen und Kinder", p: [
          "Nehmen Sie sich bei Kinderbetreuung oder Seniorenhilfe Zeit, die Person kennenzulernen, fragen Sie nach Referenzen und bleiben Sie erreichbar. Minderjährige sollten nie allein zu Unbekannten gehen: zuerst mit einer erwachsenen Vertrauensperson sprechen.",
        ] },
        { h: "Bei Problemen", p: ["Melden Sie die Anzeige, das Profil oder den Chat: Unser Moderationsteam prüft jede Meldung. Sie können eine Person jederzeit blockieren. Im Notfall wenden Sie sich direkt an:"], list: EMERGENCY.de },
      ],
    },
    it: {
      title: "Consigli di sicurezza",
      intro: "La grande maggioranza degli scambi va benissimo. Qualche semplice accorgimento permette di aiutarsi in tutta tranquillità.",
      sections: [
        { h: "Prima di incontrarsi", list: [
          "Scrivetevi prima tramite la chat di Voisina: non condividete numero, indirizzo o e-mail troppo presto.",
          "Guardate il profilo: anzianità, valutazioni, annunci pubblicati, badge «verificato».",
          "Per il primo incontro scegliete un luogo pubblico (stazione, bar, piazza del paese).",
          "Avvisate una persona di fiducia dell'ora e del luogo dell'appuntamento.",
        ] },
        { h: "Denaro e pagamenti", list: [
          "Non pagate mai in anticipo una persona che non avete incontrato.",
          "Non comunicate mai password, codici SMS, codici PIN o codici di conferma TWINT / e-banking.",
          "Diffidate di richieste di carte regalo, criptovalute o trasferimenti di denaro (Western Union, ecc.).",
          "Per un servizio retribuito, concordate l'importo per iscritto prima di iniziare. L'importo indicato nell'annuncio è indicativo.",
        ] },
        { h: "Segnali d'allarme", list: [
          "La persona vuole assolutamente lasciare la chat o vi mette fretta.",
          "L'offerta è troppo bella per essere vera.",
          "Vi vengono chiesti documenti d'identità o dati bancari.",
          "La storia cambia o diventa incoerente.",
        ] },
        { h: "Persone vulnerabili e bambini", p: [
          "Per la custodia di bambini o l'aiuto agli anziani prendetevi il tempo di conoscere la persona, chiedete referenze e restate raggiungibili. Un minorenne non deve mai recarsi da solo da uno sconosciuto: ne parli prima con un adulto di fiducia.",
        ] },
        { h: "In caso di problemi", p: ["Segnalate l'annuncio, il profilo o la conversazione: il nostro team di moderazione esamina ogni segnalazione. Potete anche bloccare una persona in qualsiasi momento. In caso di emergenza contattate direttamente:"], list: EMERGENCY.it },
      ],
    },
    en: {
      title: "Safety tips",
      intro: "The vast majority of exchanges go perfectly well. A few simple habits let you help each other with complete peace of mind.",
      sections: [
        { h: "Before you meet", list: [
          "Talk through Voisina's messaging first: don't share your phone number, address or email too early.",
          "Check the profile: member since, ratings, listings, “verified” badge.",
          "For a first meeting, choose a public place (station, café, village square).",
          "Tell someone you trust when and where you are meeting.",
        ] },
        { h: "Money and payments", list: [
          "Never pay in advance to someone you haven't met.",
          "Never share passwords, SMS codes, PIN codes or TWINT / e-banking confirmation codes.",
          "Be wary of requests for gift cards, cryptocurrency or money transfers (Western Union, etc.).",
          "For paid help, agree on the amount in writing before starting. The amount on the listing is indicative.",
        ] },
        { h: "Warning signs", list: [
          "The person insists on leaving the messaging system or rushes you.",
          "The offer is too good to be true.",
          "You are asked for identity documents or bank details.",
          "The story changes or stops making sense.",
        ] },
        { h: "Vulnerable people and children", p: [
          "For childcare or help for older people, take time to meet the person, ask for references and stay reachable. A minor should never go alone to a stranger's home: talk to a trusted adult first.",
        ] },
        { h: "If something goes wrong", p: ["Report the listing, profile or conversation: our moderation team reviews every report. You can also block someone at any time. In an emergency, contact the services directly:"], list: EMERGENCY.en },
      ],
    },
  },

  /* ---------------------------------------------------------- RÈGLES */
  regles: {
    fr: {
      title: "Règles de la communauté",
      intro: "Voisina repose sur la confiance. Ces règles s'appliquent à toutes les annonces, à tous les profils et à tous les messages.",
      sections: [
        { h: "1. Respect et bienveillance", p: ["Soyez courtois, même en cas de désaccord. Les insultes, le harcèlement, les menaces et tout propos discriminatoire (origine, religion, genre, orientation, handicap, âge…) sont interdits."] },
        { h: "2. Honnêteté", p: ["Décrivez votre annonce de façon exacte. N'utilisez que votre vraie identité et ne publiez pas d'annonce pour le compte d'autrui sans son accord."] },
        { h: "3. Entraide, pas commerce", p: ["Voisina est destiné à l'entraide entre particuliers. La publicité, le démarchage commercial, les annonces en série et les offres d'emploi professionnelles ne sont pas autorisés."] },
        { h: "4. Contenus interdits", list: [
          "Services ou objets illégaux (médicaments sur ordonnance, armes, substances, contrefaçons…).",
          "Activités dangereuses ou nécessitant une autorisation que vous n'avez pas (électricité, gaz, soins médicaux…).",
          "Contenus à caractère sexuel, violent ou haineux.",
          "Toute demande d'argent sans service réel, de codes bancaires ou de documents d'identité.",
        ] },
        { h: "5. Vie privée", p: ["Ne publiez jamais les données personnelles d'une autre personne (adresse, numéro, photos) sans son consentement. Utilisez la messagerie pour échanger vos coordonnées lorsque vous vous faites confiance."] },
        { h: "6. Engagement", p: ["Si vous acceptez d'aider, tenez parole ou prévenez à temps. Marquez vos annonces comme terminées lorsqu'elles ne sont plus d'actualité."] },
        { h: "7. Modération", p: ["Chaque signalement est examiné. Une annonce ou un profil ne respectant pas ces règles peut être masqué, et un compte peut être suspendu en cas d'abus répétés."] },
      ],
    },
    de: {
      title: "Community-Regeln",
      intro: "Voisina beruht auf Vertrauen. Diese Regeln gelten für alle Anzeigen, Profile und Nachrichten.",
      sections: [
        { h: "1. Respekt und Freundlichkeit", p: ["Bleiben Sie höflich, auch bei Meinungsverschiedenheiten. Beleidigungen, Belästigung, Drohungen und jede Diskriminierung (Herkunft, Religion, Geschlecht, Orientierung, Behinderung, Alter…) sind verboten."] },
        { h: "2. Ehrlichkeit", p: ["Beschreiben Sie Ihre Anzeige korrekt. Verwenden Sie nur Ihre echte Identität und inserieren Sie nicht ohne Einverständnis für andere Personen."] },
        { h: "3. Hilfe, nicht Handel", p: ["Voisina dient der Hilfe unter Privatpersonen. Werbung, kommerzielle Akquise, Serienanzeigen und professionelle Stellenangebote sind nicht erlaubt."] },
        { h: "4. Verbotene Inhalte", list: [
          "Illegale Dienste oder Gegenstände (verschreibungspflichtige Medikamente, Waffen, Substanzen, Fälschungen…).",
          "Gefährliche Tätigkeiten oder solche, für die eine Bewilligung nötig ist, die Sie nicht haben (Elektro, Gas, medizinische Pflege…).",
          "Sexuelle, gewalttätige oder hasserfüllte Inhalte.",
          "Geldforderungen ohne echte Leistung, Anfragen nach Bankcodes oder Ausweisen.",
        ] },
        { h: "5. Privatsphäre", p: ["Veröffentlichen Sie nie persönliche Daten anderer (Adresse, Nummer, Fotos) ohne deren Zustimmung. Tauschen Sie Kontaktdaten über den Chat aus, wenn Sie einander vertrauen."] },
        { h: "6. Verbindlichkeit", p: ["Wenn Sie Hilfe zusagen, halten Sie Wort oder sagen Sie rechtzeitig ab. Markieren Sie Anzeigen als erledigt, wenn sie nicht mehr aktuell sind."] },
        { h: "7. Moderation", p: ["Jede Meldung wird geprüft. Anzeigen oder Profile, die gegen diese Regeln verstossen, können ausgeblendet und Konten bei wiederholtem Missbrauch gesperrt werden."] },
      ],
    },
    it: {
      title: "Regole della comunità",
      intro: "Voisina si basa sulla fiducia. Queste regole valgono per tutti gli annunci, i profili e i messaggi.",
      sections: [
        { h: "1. Rispetto e gentilezza", p: ["Siate cortesi anche in caso di disaccordo. Insulti, molestie, minacce e ogni forma di discriminazione (origine, religione, genere, orientamento, disabilità, età…) sono vietati."] },
        { h: "2. Onestà", p: ["Descrivete l'annuncio in modo corretto. Usate solo la vostra vera identità e non pubblicate per conto di altri senza il loro consenso."] },
        { h: "3. Aiuto, non commercio", p: ["Voisina è dedicato all'aiuto tra privati. Pubblicità, promozione commerciale, annunci in serie e offerte di lavoro professionali non sono ammessi."] },
        { h: "4. Contenuti vietati", list: [
          "Servizi o oggetti illegali (farmaci soggetti a ricetta, armi, sostanze, contraffazioni…).",
          "Attività pericolose o che richiedono un'autorizzazione che non avete (elettricità, gas, cure mediche…).",
          "Contenuti sessuali, violenti o d'odio.",
          "Richieste di denaro senza un vero servizio, di codici bancari o di documenti d'identità.",
        ] },
        { h: "5. Privacy", p: ["Non pubblicate mai dati personali di altre persone (indirizzo, numero, foto) senza il loro consenso. Scambiatevi i contatti tramite la chat quando vi fidate l'uno dell'altro."] },
        { h: "6. Impegno", p: ["Se accettate di aiutare, mantenete la parola o avvisate in tempo. Segnate gli annunci come conclusi quando non sono più attuali."] },
        { h: "7. Moderazione", p: ["Ogni segnalazione viene esaminata. Annunci o profili che non rispettano queste regole possono essere nascosti e gli account sospesi in caso di abusi ripetuti."] },
      ],
    },
    en: {
      title: "Community rules",
      intro: "Voisina is built on trust. These rules apply to every listing, profile and message.",
      sections: [
        { h: "1. Respect and kindness", p: ["Stay polite, even when you disagree. Insults, harassment, threats and any discrimination (origin, religion, gender, orientation, disability, age…) are forbidden."] },
        { h: "2. Honesty", p: ["Describe your listing accurately. Only use your real identity and don't post on someone else's behalf without their consent."] },
        { h: "3. Help, not business", p: ["Voisina is for help between private individuals. Advertising, commercial canvassing, mass listings and professional job offers are not allowed."] },
        { h: "4. Forbidden content", list: [
          "Illegal services or items (prescription drugs, weapons, substances, counterfeits…).",
          "Dangerous work or work requiring a licence you don't hold (electrical, gas, medical care…).",
          "Sexual, violent or hateful content.",
          "Requests for money without a real service, for bank codes or identity documents.",
        ] },
        { h: "5. Privacy", p: ["Never publish another person's personal data (address, number, photos) without their consent. Use the messaging system to exchange contact details once you trust each other."] },
        { h: "6. Commitment", p: ["If you agree to help, keep your word or cancel in good time. Mark your listings as done when they are no longer relevant."] },
        { h: "7. Moderation", p: ["Every report is reviewed. Listings or profiles breaking these rules may be hidden, and accounts may be suspended after repeated abuse."] },
      ],
    },
  },

  /* ------------------------------------------------------ CONDITIONS */
  conditions: {
    fr: {
      title: "Conditions d'utilisation",
      updated: "Version de démonstration — dernière mise à jour : septembre 2026",
      sections: [
        { h: "1. Objet", p: ["Voisina est une plateforme qui met en relation des particuliers souhaitant s'entraider en Suisse. Voisina n'est partie à aucun accord conclu entre membres et n'agit pas comme employeur, intermédiaire de paiement ou prestataire de services."] },
        { h: "2. Statut du service", p: ["Le site est actuellement un prototype réalisé dans le cadre d'un projet scolaire de fin d'année. Les annonces d'exemple sont fictives et les données saisies restent dans votre navigateur. Le service est fourni tel quel, sans garantie de disponibilité."] },
        { h: "3. Inscription", p: ["L'inscription est gratuite et réservée aux personnes âgées d'au moins 16 ans ; en dessous, l'accord d'un représentant légal est nécessaire. Vous vous engagez à fournir des informations exactes et à garder votre mot de passe confidentiel."] },
        { h: "4. Annonces et comportements", p: ["Vous êtes responsable du contenu que vous publiez et de vos échanges. Vous vous engagez à respecter les Règles de la communauté et le droit suisse."] },
        { h: "5. Services rémunérés", p: ["Les montants sont convenus librement entre membres ; Voisina n'encaisse rien. Il appartient aux membres de respecter leurs éventuelles obligations légales (déclaration des revenus, cotisations sociales AVS pour certains travaux domestiques, assurances)."] },
        { h: "6. Modération", p: ["Voisina peut masquer ou supprimer tout contenu contraire aux présentes conditions et suspendre un compte en cas d'abus, sans préavis."] },
        { h: "7. Responsabilité", p: ["Dans les limites permises par la loi, Voisina décline toute responsabilité pour les dommages résultant des échanges entre membres. Chacun reste responsable de ses actes."] },
        { h: "8. Droit applicable", p: ["Les présentes conditions sont soumises au droit suisse. Le for est au siège de l'exploitant, sous réserve des fors impératifs prévus par la loi."] },
      ],
    },
    de: {
      title: "Nutzungsbedingungen",
      updated: "Demoversion — letzte Aktualisierung: September 2026",
      sections: [
        { h: "1. Zweck", p: ["Voisina ist eine Plattform, die Privatpersonen in der Schweiz für gegenseitige Hilfe zusammenbringt. Voisina ist nicht Partei von Vereinbarungen zwischen Mitgliedern und handelt weder als Arbeitgeberin noch als Zahlungsvermittlerin oder Dienstleisterin."] },
        { h: "2. Status des Dienstes", p: ["Die Website ist derzeit ein Prototyp im Rahmen eines schulischen Abschlussprojekts. Die Beispielanzeigen sind fiktiv, und eingegebene Daten bleiben in Ihrem Browser. Der Dienst wird ohne Verfügbarkeitsgarantie bereitgestellt."] },
        { h: "3. Registrierung", p: ["Die Registrierung ist kostenlos und Personen ab 16 Jahren vorbehalten; darunter ist die Zustimmung einer gesetzlichen Vertretung nötig. Sie verpflichten sich zu korrekten Angaben und halten Ihr Passwort geheim."] },
        { h: "4. Anzeigen und Verhalten", p: ["Sie sind für Ihre Inhalte und Ihren Austausch verantwortlich und verpflichten sich, die Community-Regeln und das Schweizer Recht einzuhalten."] },
        { h: "5. Bezahlte Dienste", p: ["Beträge werden frei zwischen Mitgliedern vereinbart; Voisina kassiert nichts. Die Mitglieder sind selbst für allfällige gesetzliche Pflichten verantwortlich (Einkommensdeklaration, AHV-Beiträge bei gewissen Hausarbeiten, Versicherungen)."] },
        { h: "6. Moderation", p: ["Voisina kann Inhalte, die gegen diese Bedingungen verstossen, ohne Vorankündigung ausblenden oder löschen und Konten bei Missbrauch sperren."] },
        { h: "7. Haftung", p: ["Soweit gesetzlich zulässig, lehnt Voisina jede Haftung für Schäden aus dem Austausch zwischen Mitgliedern ab. Jede Person bleibt für ihr Handeln verantwortlich."] },
        { h: "8. Anwendbares Recht", p: ["Es gilt Schweizer Recht. Gerichtsstand ist der Sitz der Betreiberin, vorbehaltlich zwingender gesetzlicher Gerichtsstände."] },
      ],
    },
    it: {
      title: "Condizioni d'uso",
      updated: "Versione dimostrativa — ultimo aggiornamento: settembre 2026",
      sections: [
        { h: "1. Oggetto", p: ["Voisina è una piattaforma che mette in contatto privati che desiderano aiutarsi in Svizzera. Voisina non è parte degli accordi tra membri e non agisce come datore di lavoro, intermediario di pagamento o fornitore di servizi."] },
        { h: "2. Stato del servizio", p: ["Il sito è attualmente un prototipo realizzato nell'ambito di un progetto scolastico di fine anno. Gli annunci d'esempio sono fittizi e i dati inseriti restano nel vostro browser. Il servizio è fornito senza garanzia di disponibilità."] },
        { h: "3. Iscrizione", p: ["L'iscrizione è gratuita e riservata alle persone di almeno 16 anni; al di sotto è necessario il consenso di un rappresentante legale. Vi impegnate a fornire informazioni corrette e a mantenere segreta la password."] },
        { h: "4. Annunci e comportamenti", p: ["Siete responsabili dei contenuti che pubblicate e dei vostri scambi. Vi impegnate a rispettare le Regole della comunità e il diritto svizzero."] },
        { h: "5. Servizi retribuiti", p: ["Gli importi sono concordati liberamente tra membri; Voisina non incassa nulla. Spetta ai membri rispettare eventuali obblighi legali (dichiarazione dei redditi, contributi AVS per alcuni lavori domestici, assicurazioni)."] },
        { h: "6. Moderazione", p: ["Voisina può nascondere o eliminare senza preavviso qualsiasi contenuto contrario alle presenti condizioni e sospendere un account in caso di abuso."] },
        { h: "7. Responsabilità", p: ["Nei limiti consentiti dalla legge, Voisina declina ogni responsabilità per danni derivanti dagli scambi tra membri. Ciascuno resta responsabile delle proprie azioni."] },
        { h: "8. Diritto applicabile", p: ["Si applica il diritto svizzero. Il foro è presso la sede del gestore, riservati i fori imperativi previsti dalla legge."] },
      ],
    },
    en: {
      title: "Terms of use",
      updated: "Demo version — last updated: September 2026",
      sections: [
        { h: "1. Purpose", p: ["Voisina is a platform connecting private individuals who want to help each other in Switzerland. Voisina is not a party to any agreement between members and does not act as an employer, payment intermediary or service provider."] },
        { h: "2. Service status", p: ["The site is currently a prototype built as an end-of-year school project. Sample listings are fictional and the data you enter stays in your browser. The service is provided as is, with no availability guarantee."] },
        { h: "3. Registration", p: ["Registration is free and reserved for people aged 16 or over; under 16, a legal guardian's consent is required. You agree to provide accurate information and keep your password confidential."] },
        { h: "4. Listings and behaviour", p: ["You are responsible for the content you post and for your exchanges. You agree to follow the Community rules and Swiss law."] },
        { h: "5. Paid help", p: ["Amounts are freely agreed between members; Voisina collects nothing. Members are responsible for any legal obligations (declaring income, AHV/AVS social contributions for certain household work, insurance)."] },
        { h: "6. Moderation", p: ["Voisina may hide or remove any content that breaches these terms and suspend accounts in case of abuse, without notice."] },
        { h: "7. Liability", p: ["To the extent permitted by law, Voisina accepts no liability for damage arising from exchanges between members. Everyone remains responsible for their own actions."] },
        { h: "8. Governing law", p: ["These terms are governed by Swiss law. The place of jurisdiction is the operator's registered office, subject to mandatory statutory jurisdictions."] },
      ],
    },
  },

  /* ---------------------------------------------------- CONFIDENTIALITÉ */
  confidentialite: {
    fr: {
      title: "Politique de confidentialité",
      intro: "Rédigée selon la loi fédérale sur la protection des données (nLPD), en vigueur depuis le 1er septembre 2023.",
      updated: "Dernière mise à jour : septembre 2026",
      sections: [
        { h: "En bref", list: [
          "Aucun cookie, aucun outil de statistiques, aucune publicité, aucun traceur.",
          "Dans cette version, vos données restent uniquement dans votre navigateur : elles ne sont envoyées à aucun serveur Voisina.",
          "Votre mot de passe n'est jamais enregistré : seule une empreinte chiffrée (PBKDF2) est conservée.",
          "Votre adresse exacte n'est jamais demandée ni affichée.",
        ] },
        { h: "Responsable du traitement", p: ["Voisina — projet scolaire de fin d'année (voir les mentions légales)."] },
        { h: "Données traitées", list: [
          "Compte : prénom, nom (seule l'initiale est publique), e-mail, localité, canton, empreinte du mot de passe.",
          "Profil facultatif : photo, présentation, langues, spécialités.",
          "Contenus : annonces, photos d'annonces, messages, favoris, signalements.",
          "Préférences : langue, thème, point de référence pour le calcul des distances.",
        ] },
        { h: "Où sont stockées vos données ?", p: ["Dans ce prototype, toutes les données sont enregistrées dans le stockage local (localStorage) de votre navigateur, sur votre appareil. Elles ne sont pas partagées avec d'autres appareils. Vider les données du site dans votre navigateur les supprime définitivement."] },
        { h: "Services tiers", p: ["Pour fonctionner, le site fait appel aux services suivants, qui reçoivent techniquement votre adresse IP :"], list: [
          "GitHub Pages (GitHub Inc., États-Unis) : hébergement du site.",
          "unpkg.com : distribution de la bibliothèque de cartes Leaflet (fichier vérifié par empreinte SRI).",
          "swisstopo (Office fédéral de topographie, Suisse) : fonds de carte ; OpenStreetMap en secours.",
          "geo.admin.ch (Confédération suisse) : recherche de localités — seul le texte saisi dans le champ « localité » est transmis.",
          "DeepL (Allemagne) : uniquement si vous cliquez sur « Traduire », le texte de l'annonce est ouvert sur deepl.com.",
        ] },
        { h: "Vos droits", p: ["Vous pouvez à tout moment consulter, corriger, exporter (fichier JSON) ou supprimer vos données depuis « Mon compte ». Vous pouvez également adresser une réclamation au Préposé fédéral à la protection des données et à la transparence (PFPDT)."] },
        { h: "Sécurité", p: ["Politique de sécurité du contenu (CSP) stricte, échappement systématique des contenus, empreintes de mots de passe PBKDF2 avec 600 000 itérations, limitation des tentatives de connexion, suppression des métadonnées GPS des photos, position floutée sur la carte."] },
        { h: "Version future avec serveur", p: ["Si Voisina est un jour mis en ligne avec un serveur, les données seraient hébergées en Suisse ou dans l'UE, cette politique serait mise à jour et vous en seriez informé·e avant tout changement."] },
      ],
    },
    de: {
      title: "Datenschutzerklärung",
      intro: "Verfasst nach dem revidierten Datenschutzgesetz (revDSG), in Kraft seit dem 1. September 2023.",
      updated: "Letzte Aktualisierung: September 2026",
      sections: [
        { h: "Kurz gesagt", list: [
          "Keine Cookies, keine Statistik-Tools, keine Werbung, keine Tracker.",
          "In dieser Version bleiben Ihre Daten ausschliesslich in Ihrem Browser: Sie werden an keinen Voisina-Server gesendet.",
          "Ihr Passwort wird nie gespeichert: Nur ein verschlüsselter Fingerabdruck (PBKDF2) wird aufbewahrt.",
          "Ihre genaue Adresse wird weder abgefragt noch angezeigt.",
        ] },
        { h: "Verantwortliche Stelle", p: ["Voisina — schulisches Abschlussprojekt (siehe Impressum)."] },
        { h: "Bearbeitete Daten", list: [
          "Konto: Vorname, Nachname (nur die Initiale ist öffentlich), E-Mail, Ort, Kanton, Passwort-Fingerabdruck.",
          "Freiwilliges Profil: Foto, Beschreibung, Sprachen, Fähigkeiten.",
          "Inhalte: Anzeigen, Anzeigenfotos, Nachrichten, Favoriten, Meldungen.",
          "Einstellungen: Sprache, Design, Referenzpunkt für Distanzen.",
        ] },
        { h: "Wo werden Ihre Daten gespeichert?", p: ["In diesem Prototyp werden alle Daten im lokalen Speicher (localStorage) Ihres Browsers auf Ihrem Gerät abgelegt. Sie werden nicht mit anderen Geräten geteilt. Wenn Sie die Websitedaten im Browser löschen, sind sie endgültig entfernt."] },
        { h: "Drittdienste", p: ["Für den Betrieb nutzt die Website folgende Dienste, die technisch Ihre IP-Adresse erhalten:"], list: [
          "GitHub Pages (GitHub Inc., USA): Hosting der Website.",
          "unpkg.com: Auslieferung der Kartenbibliothek Leaflet (Datei per SRI-Prüfsumme verifiziert).",
          "swisstopo (Bundesamt für Landestopografie, Schweiz): Kartenhintergrund; OpenStreetMap als Ersatz.",
          "geo.admin.ch (Schweizerische Eidgenossenschaft): Ortssuche — nur der im Feld «Ort» eingegebene Text wird übermittelt.",
          "DeepL (Deutschland): nur wenn Sie auf «Übersetzen» klicken, wird der Anzeigentext auf deepl.com geöffnet.",
        ] },
        { h: "Ihre Rechte", p: ["Sie können Ihre Daten jederzeit unter «Mein Konto» einsehen, berichtigen, exportieren (JSON-Datei) oder löschen. Sie können sich zudem beim Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten (EDÖB) beschweren."] },
        { h: "Sicherheit", p: ["Strikte Content Security Policy (CSP), systematisches Escaping von Inhalten, PBKDF2-Passwort-Fingerabdrücke mit 600 000 Iterationen, Begrenzung der Anmeldeversuche, Entfernung der GPS-Metadaten aus Fotos, ungenaue Position auf der Karte."] },
        { h: "Künftige Serverversion", p: ["Sollte Voisina mit einem Server online gehen, würden die Daten in der Schweiz oder der EU gehostet, diese Erklärung aktualisiert und Sie vorab informiert."] },
      ],
    },
    it: {
      title: "Informativa sulla privacy",
      intro: "Redatta secondo la nuova legge federale sulla protezione dei dati (nLPD), in vigore dal 1° settembre 2023.",
      updated: "Ultimo aggiornamento: settembre 2026",
      sections: [
        { h: "In breve", list: [
          "Nessun cookie, nessuno strumento statistico, nessuna pubblicità, nessun tracker.",
          "In questa versione i vostri dati restano soltanto nel vostro browser: non vengono inviati a nessun server di Voisina.",
          "La password non viene mai salvata: viene conservata solo un'impronta cifrata (PBKDF2).",
          "Il vostro indirizzo esatto non viene mai chiesto né mostrato.",
        ] },
        { h: "Titolare del trattamento", p: ["Voisina — progetto scolastico di fine anno (vedi note legali)."] },
        { h: "Dati trattati", list: [
          "Account: nome, cognome (è pubblica solo l'iniziale), e-mail, località, cantone, impronta della password.",
          "Profilo facoltativo: foto, presentazione, lingue, competenze.",
          "Contenuti: annunci, foto degli annunci, messaggi, preferiti, segnalazioni.",
          "Preferenze: lingua, tema, punto di riferimento per il calcolo delle distanze.",
        ] },
        { h: "Dove sono salvati i dati?", p: ["In questo prototipo tutti i dati sono registrati nella memoria locale (localStorage) del browser, sul vostro dispositivo. Non sono condivisi con altri dispositivi. Cancellando i dati del sito nel browser vengono eliminati definitivamente."] },
        { h: "Servizi di terzi", p: ["Per funzionare, il sito utilizza i seguenti servizi, che ricevono tecnicamente il vostro indirizzo IP:"], list: [
          "GitHub Pages (GitHub Inc., Stati Uniti): hosting del sito.",
          "unpkg.com: distribuzione della libreria cartografica Leaflet (file verificato con impronta SRI).",
          "swisstopo (Ufficio federale di topografia, Svizzera): sfondi cartografici; OpenStreetMap come riserva.",
          "geo.admin.ch (Confederazione Svizzera): ricerca delle località — viene trasmesso solo il testo digitato nel campo «località».",
          "DeepL (Germania): solo se cliccate su «Traduci», il testo dell'annuncio viene aperto su deepl.com.",
        ] },
        { h: "I vostri diritti", p: ["Potete in qualsiasi momento consultare, correggere, esportare (file JSON) o eliminare i vostri dati da «Il mio account». Potete inoltre presentare reclamo all'Incaricato federale della protezione dei dati e della trasparenza (IFPDT)."] },
        { h: "Sicurezza", p: ["Content Security Policy (CSP) rigorosa, escaping sistematico dei contenuti, impronte delle password PBKDF2 con 600 000 iterazioni, limitazione dei tentativi di accesso, rimozione dei metadati GPS dalle foto, posizione sfocata sulla carta."] },
        { h: "Versione futura con server", p: ["Se Voisina venisse messo online con un server, i dati sarebbero ospitati in Svizzera o nell'UE, questa informativa sarebbe aggiornata e ne sareste informati prima di qualsiasi cambiamento."] },
      ],
    },
    en: {
      title: "Privacy policy",
      intro: "Written in line with the revised Swiss Federal Act on Data Protection (FADP), in force since 1 September 2023.",
      updated: "Last updated: September 2026",
      sections: [
        { h: "In short", list: [
          "No cookies, no analytics, no ads, no trackers.",
          "In this version, your data stays in your browser only: it is not sent to any Voisina server.",
          "Your password is never stored: only an encrypted fingerprint (PBKDF2) is kept.",
          "Your exact address is never requested or shown.",
        ] },
        { h: "Controller", p: ["Voisina — end-of-year school project (see legal notice)."] },
        { h: "Data processed", list: [
          "Account: first name, last name (only the initial is public), email, town, canton, password fingerprint.",
          "Optional profile: photo, bio, languages, skills.",
          "Content: listings, listing photos, messages, favourites, reports.",
          "Preferences: language, theme, reference point for distances.",
        ] },
        { h: "Where is your data stored?", p: ["In this prototype, all data is saved in your browser's local storage (localStorage), on your device. It is not shared with other devices. Clearing the site data in your browser deletes it permanently."] },
        { h: "Third-party services", p: ["To work, the site uses the following services, which technically receive your IP address:"], list: [
          "GitHub Pages (GitHub Inc., USA): website hosting.",
          "unpkg.com: delivery of the Leaflet map library (file verified with an SRI hash).",
          "swisstopo (Federal Office of Topography, Switzerland): base maps; OpenStreetMap as a fallback.",
          "geo.admin.ch (Swiss Confederation): place search — only the text typed in the “town” field is sent.",
          "DeepL (Germany): only if you click “Translate”, the listing text is opened on deepl.com.",
        ] },
        { h: "Your rights", p: ["You can view, correct, export (JSON file) or delete your data at any time from “My account”. You may also lodge a complaint with the Federal Data Protection and Information Commissioner (FDPIC)."] },
        { h: "Security", p: ["Strict Content Security Policy (CSP), systematic output escaping, PBKDF2 password fingerprints with 600,000 iterations, login attempt limiting, removal of GPS metadata from photos, blurred map positions."] },
        { h: "Future server version", p: ["Should Voisina go live with a server, data would be hosted in Switzerland or the EU, this policy would be updated and you would be informed beforehand."] },
      ],
    },
  },

  /* ------------------------------------------------ MENTIONS LÉGALES */
  "mentions-legales": {
    fr: {
      title: "Mentions légales",
      sections: [
        { h: "Éditeur du site", p: ["Voisina — projet scolaire de fin d'année réalisé par Lenny H., Suisse.", "Ce site est un prototype pédagogique non commercial. Les annonces et les membres d'exemple sont fictifs ; toute ressemblance avec des personnes réelles serait fortuite."] },
        { h: "Hébergement", p: ["GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, États-Unis."] },
        { h: "Cartes et données géographiques", p: ["Fonds de carte © swisstopo (Office fédéral de topographie). Données de repli © contributeurs OpenStreetMap. Recherche de localités : service geo.admin.ch de la Confédération suisse."] },
        { h: "Crédits", list: ["Bibliothèque de cartes : Leaflet (licence BSD-2).", "Police de titres : Fraunces (SIL Open Font License).", "Icônes inspirées de Lucide (licence ISC)."] },
        { h: "Propriété intellectuelle", p: ["Les textes, le logo et la conception du site sont la propriété de leur auteur. Les contenus publiés par les membres restent leur propriété."] },
      ],
    },
    de: {
      title: "Impressum",
      sections: [
        { h: "Herausgeber", p: ["Voisina — schulisches Abschlussprojekt von Lenny H., Schweiz.", "Diese Website ist ein nicht kommerzieller Lernprototyp. Beispielanzeigen und -mitglieder sind fiktiv; Ähnlichkeiten mit realen Personen wären zufällig."] },
        { h: "Hosting", p: ["GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, USA."] },
        { h: "Karten und Geodaten", p: ["Kartenhintergrund © swisstopo (Bundesamt für Landestopografie). Ersatzdaten © OpenStreetMap-Mitwirkende. Ortssuche: Dienst geo.admin.ch der Schweizerischen Eidgenossenschaft."] },
        { h: "Credits", list: ["Kartenbibliothek: Leaflet (BSD-2-Lizenz).", "Titelschrift: Fraunces (SIL Open Font License).", "Icons inspiriert von Lucide (ISC-Lizenz)."] },
        { h: "Geistiges Eigentum", p: ["Texte, Logo und Gestaltung der Website gehören ihrem Autor. Von Mitgliedern veröffentlichte Inhalte bleiben deren Eigentum."] },
      ],
    },
    it: {
      title: "Note legali",
      sections: [
        { h: "Editore del sito", p: ["Voisina — progetto scolastico di fine anno realizzato da Lenny H., Svizzera.", "Questo sito è un prototipo didattico non commerciale. Gli annunci e i membri d'esempio sono fittizi; ogni somiglianza con persone reali è casuale."] },
        { h: "Hosting", p: ["GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, Stati Uniti."] },
        { h: "Carte e dati geografici", p: ["Sfondi cartografici © swisstopo (Ufficio federale di topografia). Dati di riserva © contributori OpenStreetMap. Ricerca delle località: servizio geo.admin.ch della Confederazione Svizzera."] },
        { h: "Crediti", list: ["Libreria cartografica: Leaflet (licenza BSD-2).", "Carattere dei titoli: Fraunces (SIL Open Font License).", "Icone ispirate a Lucide (licenza ISC)."] },
        { h: "Proprietà intellettuale", p: ["Testi, logo e concezione del sito appartengono al loro autore. I contenuti pubblicati dai membri restano di loro proprietà."] },
      ],
    },
    en: {
      title: "Legal notice",
      sections: [
        { h: "Publisher", p: ["Voisina — end-of-year school project by Lenny H., Switzerland.", "This site is a non-commercial educational prototype. Sample listings and members are fictional; any resemblance to real people is coincidental."] },
        { h: "Hosting", p: ["GitHub Pages — GitHub Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, USA."] },
        { h: "Maps and geodata", p: ["Base maps © swisstopo (Federal Office of Topography). Fallback data © OpenStreetMap contributors. Place search: geo.admin.ch service of the Swiss Confederation."] },
        { h: "Credits", list: ["Map library: Leaflet (BSD-2 licence).", "Heading font: Fraunces (SIL Open Font License).", "Icons inspired by Lucide (ISC licence)."] },
        { h: "Intellectual property", p: ["The texts, logo and design of the site belong to their author. Content posted by members remains their property."] },
      ],
    },
  },

  /* ---------------------------------------------------------- À PROPOS */
  "a-propos": {
    fr: {
      title: "À propos de Voisina",
      intro: "Rendre l'entraide locale plus simple, plus accessible et plus humaine, partout en Suisse.",
      sections: [
        { h: "Notre idée", p: ["Tout le monde a un jour besoin d'un coup de main : porter un meuble, promener un chien, comprendre un formulaire, trouver de la compagnie. Et tout le monde a quelque chose à offrir. Voisina met ces personnes en relation, près de chez elles, dans leur langue."] },
        { h: "Nos principes", list: [
          "Gratuit et sans publicité.",
          "Respect de la vie privée dès la conception : pas de traceur, adresse jamais affichée.",
          "Multilingue comme la Suisse : français, allemand, italien et anglais.",
          "Accessible à toutes et à tous, y compris aux personnes âgées et aux lecteurs d'écran.",
        ] },
        { h: "Un projet de fin d'année", p: ["Voisina a été conçu et développé dans le cadre d'un projet scolaire. Le site fonctionne entièrement dans le navigateur : les annonces d'exemple servent à la démonstration et vos données restent sur votre appareil."] },
        { h: "Sous le capot", list: [
          "HTML, CSS et JavaScript modernes, sans framework, pour un site rapide et léger.",
          "Application monopage avec liens partageables vers chaque annonce.",
          "Carte officielle swisstopo et recherche de communes de la Confédération.",
          "Sécurité : CSP stricte, protection XSS, mots de passe hachés (PBKDF2), anti force brute.",
          "Installable sur smartphone comme une application (PWA) et utilisable hors connexion.",
        ] },
        { h: "Et ensuite ?", p: ["Prochaines étapes envisagées : un serveur sécurisé hébergé en Suisse pour partager les annonces entre tous les appareils, la vérification des profils par e-mail et SMS, les évaluations après chaque échange et des groupes de quartier."] },
      ],
    },
    de: {
      title: "Über Voisina",
      intro: "Nachbarschaftshilfe einfacher, zugänglicher und menschlicher machen – in der ganzen Schweiz.",
      sections: [
        { h: "Unsere Idee", p: ["Alle brauchen irgendwann Hilfe: ein Möbel tragen, den Hund ausführen, ein Formular verstehen, Gesellschaft finden. Und alle haben etwas zu geben. Voisina bringt diese Menschen zusammen – in ihrer Nähe und in ihrer Sprache."] },
        { h: "Unsere Grundsätze", list: [
          "Kostenlos und ohne Werbung.",
          "Datenschutz von Anfang an: keine Tracker, Adresse nie sichtbar.",
          "Mehrsprachig wie die Schweiz: Deutsch, Französisch, Italienisch und Englisch.",
          "Für alle zugänglich, auch für ältere Menschen und Screenreader.",
        ] },
        { h: "Ein Abschlussprojekt", p: ["Voisina wurde im Rahmen eines Schulprojekts konzipiert und entwickelt. Die Website läuft vollständig im Browser: Die Beispielanzeigen dienen der Demonstration, und Ihre Daten bleiben auf Ihrem Gerät."] },
        { h: "Unter der Haube", list: [
          "Modernes HTML, CSS und JavaScript ohne Framework – schnell und leicht.",
          "Single-Page-App mit teilbaren Links zu jeder Anzeige.",
          "Offizielle swisstopo-Karte und Gemeindesuche des Bundes.",
          "Sicherheit: strikte CSP, XSS-Schutz, gehashte Passwörter (PBKDF2), Schutz vor Brute-Force.",
          "Auf dem Smartphone wie eine App installierbar (PWA) und offline nutzbar.",
        ] },
        { h: "Wie geht es weiter?", p: ["Geplante nächste Schritte: ein sicherer Server in der Schweiz, damit Anzeigen auf allen Geräten sichtbar sind, Profilverifizierung per E-Mail und SMS, Bewertungen nach jedem Austausch und Quartiergruppen."] },
      ],
    },
    it: {
      title: "Chi siamo",
      intro: "Rendere l'aiuto tra vicini più semplice, accessibile e umano, in tutta la Svizzera.",
      sections: [
        { h: "La nostra idea", p: ["Tutti prima o poi hanno bisogno di una mano: portare un mobile, portare a spasso il cane, capire un modulo, trovare compagnia. E tutti hanno qualcosa da offrire. Voisina mette in contatto queste persone, vicino a casa e nella loro lingua."] },
        { h: "I nostri principi", list: [
          "Gratuito e senza pubblicità.",
          "Privacy fin dalla progettazione: nessun tracker, indirizzo mai mostrato.",
          "Multilingue come la Svizzera: italiano, francese, tedesco e inglese.",
          "Accessibile a tutti, anche alle persone anziane e ai lettori di schermo.",
        ] },
        { h: "Un progetto di fine anno", p: ["Voisina è stato ideato e sviluppato nell'ambito di un progetto scolastico. Il sito funziona interamente nel browser: gli annunci d'esempio servono alla dimostrazione e i vostri dati restano sul vostro dispositivo."] },
        { h: "Sotto il cofano", list: [
          "HTML, CSS e JavaScript moderni, senza framework, per un sito veloce e leggero.",
          "Applicazione a pagina singola con link condivisibili per ogni annuncio.",
          "Carta ufficiale swisstopo e ricerca dei comuni della Confederazione.",
          "Sicurezza: CSP rigorosa, protezione XSS, password con hash (PBKDF2), protezione brute force.",
          "Installabile sullo smartphone come un'app (PWA) e utilizzabile offline.",
        ] },
        { h: "E poi?", p: ["Prossime tappe previste: un server sicuro ospitato in Svizzera per condividere gli annunci tra tutti i dispositivi, la verifica dei profili via e-mail e SMS, le valutazioni dopo ogni scambio e i gruppi di quartiere."] },
      ],
    },
    en: {
      title: "About Voisina",
      intro: "Making local help simpler, more accessible and more human, all across Switzerland.",
      sections: [
        { h: "Our idea", p: ["Everyone needs a hand at some point: carrying furniture, walking a dog, understanding a form, finding some company. And everyone has something to offer. Voisina connects these people, close to home and in their own language."] },
        { h: "Our principles", list: [
          "Free and ad-free.",
          "Privacy by design: no trackers, addresses never shown.",
          "Multilingual like Switzerland: French, German, Italian and English.",
          "Accessible to everyone, including older people and screen reader users.",
        ] },
        { h: "An end-of-year project", p: ["Voisina was designed and built as a school project. The site runs entirely in the browser: sample listings are for demonstration and your data stays on your device."] },
        { h: "Under the hood", list: [
          "Modern HTML, CSS and JavaScript with no framework, for a fast, lightweight site.",
          "Single-page app with shareable links to every listing.",
          "Official swisstopo map and federal municipality search.",
          "Security: strict CSP, XSS protection, hashed passwords (PBKDF2), brute-force protection.",
          "Installable on smartphones like an app (PWA) and usable offline.",
        ] },
        { h: "What's next?", p: ["Planned next steps: a secure server hosted in Switzerland so listings are shared across all devices, profile verification by email and SMS, ratings after each exchange and neighbourhood groups."] },
      ],
    },
  },
};
