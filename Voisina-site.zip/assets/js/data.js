/* =====================================================================
   DONNÉES DE RÉFÉRENCE : cantons, localités, catégories, modèles d'annonces
   ===================================================================== */

export const LANGS = ["fr", "de", "it", "en"];

/** Les 26 cantons, avec leur nom dans les 4 langues du site. */
export const CANTONS = {
  ZH: { fr: "Zurich", de: "Zürich", it: "Zurigo", en: "Zurich", lang: "de" },
  BE: { fr: "Berne", de: "Bern", it: "Berna", en: "Bern", lang: "de" },
  LU: { fr: "Lucerne", de: "Luzern", it: "Lucerna", en: "Lucerne", lang: "de" },
  UR: { fr: "Uri", de: "Uri", it: "Uri", en: "Uri", lang: "de" },
  SZ: { fr: "Schwytz", de: "Schwyz", it: "Svitto", en: "Schwyz", lang: "de" },
  OW: { fr: "Obwald", de: "Obwalden", it: "Obvaldo", en: "Obwalden", lang: "de" },
  NW: { fr: "Nidwald", de: "Nidwalden", it: "Nidvaldo", en: "Nidwalden", lang: "de" },
  GL: { fr: "Glaris", de: "Glarus", it: "Glarona", en: "Glarus", lang: "de" },
  ZG: { fr: "Zoug", de: "Zug", it: "Zugo", en: "Zug", lang: "de" },
  FR: { fr: "Fribourg", de: "Freiburg", it: "Friburgo", en: "Fribourg", lang: "fr" },
  SO: { fr: "Soleure", de: "Solothurn", it: "Soletta", en: "Solothurn", lang: "de" },
  BS: { fr: "Bâle-Ville", de: "Basel-Stadt", it: "Basilea Città", en: "Basel-City", lang: "de" },
  BL: { fr: "Bâle-Campagne", de: "Basel-Landschaft", it: "Basilea Campagna", en: "Basel-Country", lang: "de" },
  SH: { fr: "Schaffhouse", de: "Schaffhausen", it: "Sciaffusa", en: "Schaffhausen", lang: "de" },
  AR: { fr: "Appenzell Rh.-Ext.", de: "Appenzell Ausserrhoden", it: "Appenzello Esterno", en: "Appenzell Outer Rhodes", lang: "de" },
  AI: { fr: "Appenzell Rh.-Int.", de: "Appenzell Innerrhoden", it: "Appenzello Interno", en: "Appenzell Inner Rhodes", lang: "de" },
  SG: { fr: "Saint-Gall", de: "St. Gallen", it: "San Gallo", en: "St. Gallen", lang: "de" },
  GR: { fr: "Grisons", de: "Graubünden", it: "Grigioni", en: "Grisons", lang: "de" },
  AG: { fr: "Argovie", de: "Aargau", it: "Argovia", en: "Aargau", lang: "de" },
  TG: { fr: "Thurgovie", de: "Thurgau", it: "Turgovia", en: "Thurgau", lang: "de" },
  TI: { fr: "Tessin", de: "Tessin", it: "Ticino", en: "Ticino", lang: "it" },
  VD: { fr: "Vaud", de: "Waadt", it: "Vaud", en: "Vaud", lang: "fr" },
  VS: { fr: "Valais", de: "Wallis", it: "Vallese", en: "Valais", lang: "fr" },
  NE: { fr: "Neuchâtel", de: "Neuenburg", it: "Neuchâtel", en: "Neuchâtel", lang: "fr" },
  GE: { fr: "Genève", de: "Genf", it: "Ginevra", en: "Geneva", lang: "fr" },
  JU: { fr: "Jura", de: "Jura", it: "Giura", en: "Jura", lang: "fr" },
};

export const CANTON_CODES = Object.keys(CANTONS);

/** Localités : [nom, NPA, canton, latitude, longitude, langue locale (facultatif)]
 *  Coordonnées approximatives du centre (la position exacte n'est jamais utilisée). */
const RAW_LOCALITIES = [
  ["Zürich", "8001", "ZH", 47.3769, 8.5417], ["Winterthur", "8400", "ZH", 47.4999, 8.7241], ["Uster", "8610", "ZH", 47.3471, 8.7209],
  ["Dübendorf", "8600", "ZH", 47.3972, 8.6186], ["Dietikon", "8953", "ZH", 47.4017, 8.4001], ["Wädenswil", "8820", "ZH", 47.2303, 8.6716],
  ["Kloten", "8302", "ZH", 47.4515, 8.5849], ["Horgen", "8810", "ZH", 47.2596, 8.5977], ["Bülach", "8180", "ZH", 47.522, 8.5405], ["Meilen", "8706", "ZH", 47.27, 8.6435],
  ["Bern", "3011", "BE", 46.948, 7.4474], ["Biel/Bienne", "2502", "BE", 47.1368, 7.2468], ["Thun", "3600", "BE", 46.758, 7.628],
  ["Köniz", "3098", "BE", 46.9244, 7.4146], ["Burgdorf", "3400", "BE", 47.059, 7.628], ["Langenthal", "4900", "BE", 47.2153, 7.787],
  ["Interlaken", "3800", "BE", 46.6863, 7.8632], ["Spiez", "3700", "BE", 46.6865, 7.6793], ["Moutier", "2740", "BE", 47.2786, 7.3706, "fr"], ["Saint-Imier", "2610", "BE", 47.1527, 6.9965, "fr"],
  ["Luzern", "6003", "LU", 47.0502, 8.3093], ["Emmen", "6020", "LU", 47.0782, 8.294], ["Kriens", "6010", "LU", 47.0359, 8.2765], ["Sursee", "6210", "LU", 47.1717, 8.111],
  ["Altdorf", "6460", "UR", 46.8804, 8.6444], ["Andermatt", "6490", "UR", 46.6356, 8.5939],
  ["Schwyz", "6430", "SZ", 47.0207, 8.6524], ["Freienbach", "8807", "SZ", 47.2047, 8.7584], ["Einsiedeln", "8840", "SZ", 47.1285, 8.743], ["Küssnacht", "6403", "SZ", 47.0859, 8.4419],
  ["Sarnen", "6060", "OW", 46.896, 8.246], ["Engelberg", "6390", "OW", 46.8211, 8.4013],
  ["Stans", "6370", "NW", 46.958, 8.366], ["Glarus", "8750", "GL", 47.04, 9.068],
  ["Zug", "6300", "ZG", 47.1662, 8.5155], ["Baar", "6340", "ZG", 47.1963, 8.5295], ["Cham", "6330", "ZG", 47.182, 8.4636],
  ["Fribourg", "1700", "FR", 46.8065, 7.161], ["Bulle", "1630", "FR", 46.617, 7.0577], ["Murten/Morat", "3280", "FR", 46.9283, 7.1172, "de"],
  ["Estavayer", "1470", "FR", 46.849, 6.846], ["Villars-sur-Glâne", "1752", "FR", 46.7905, 7.117], ["Düdingen", "3186", "FR", 46.8491, 7.1886, "de"],
  ["Solothurn", "4500", "SO", 47.2088, 7.5323], ["Olten", "4600", "SO", 47.3499, 7.9033], ["Grenchen", "2540", "SO", 47.1921, 7.3959],
  ["Basel", "4051", "BS", 47.5596, 7.5886], ["Riehen", "4125", "BS", 47.5788, 7.6468],
  ["Liestal", "4410", "BL", 47.4841, 7.7343], ["Allschwil", "4123", "BL", 47.5508, 7.5358], ["Pratteln", "4133", "BL", 47.5207, 7.693],
  ["Reinach", "4153", "BL", 47.4935, 7.591], ["Muttenz", "4132", "BL", 47.5228, 7.6453],
  ["Schaffhausen", "8200", "SH", 47.696, 8.635], ["Neuhausen am Rheinfall", "8212", "SH", 47.683, 8.617],
  ["Herisau", "9100", "AR", 47.3862, 9.2792], ["Appenzell", "9050", "AI", 47.3311, 9.409],
  ["St. Gallen", "9000", "SG", 47.4245, 9.3767], ["Rapperswil-Jona", "8640", "SG", 47.2298, 8.836], ["Wil", "9500", "SG", 47.4615, 9.0455],
  ["Gossau", "9200", "SG", 47.415, 9.254], ["Buchs", "9470", "SG", 47.167, 9.478],
  ["Chur", "7000", "GR", 46.8508, 9.531], ["Davos", "7270", "GR", 46.8027, 9.836], ["St. Moritz", "7500", "GR", 46.4908, 9.8355],
  ["Ilanz", "7130", "GR", 46.774, 9.204], ["Poschiavo", "7742", "GR", 46.324, 10.058, "it"],
  ["Aarau", "5000", "AG", 47.3904, 8.0457], ["Baden", "5400", "AG", 47.4733, 8.3059], ["Wettingen", "5430", "AG", 47.4597, 8.316],
  ["Brugg", "5200", "AG", 47.484, 8.2084], ["Wohlen", "5610", "AG", 47.351, 8.278], ["Rheinfelden", "4310", "AG", 47.554, 7.794],
  ["Frauenfeld", "8500", "TG", 47.557, 9.108], ["Kreuzlingen", "8280", "TG", 47.65, 9.175], ["Arbon", "9320", "TG", 47.5167, 9.4333], ["Weinfelden", "8570", "TG", 47.5667, 9.1],
  ["Lugano", "6900", "TI", 46.0037, 8.9511], ["Bellinzona", "6500", "TI", 46.1957, 9.022], ["Locarno", "6600", "TI", 46.1709, 8.7995],
  ["Mendrisio", "6850", "TI", 45.8702, 8.9819], ["Chiasso", "6830", "TI", 45.835, 9.03], ["Biasca", "6710", "TI", 46.359, 8.969],
  ["Lausanne", "1003", "VD", 46.5197, 6.6323], ["Montreux", "1820", "VD", 46.4312, 6.9107], ["Nyon", "1260", "VD", 46.3833, 6.2396],
  ["Vevey", "1800", "VD", 46.4625, 6.8431], ["Yverdon-les-Bains", "1400", "VD", 46.7785, 6.6412], ["Renens", "1020", "VD", 46.539, 6.588],
  ["Morges", "1110", "VD", 46.511, 6.499], ["Pully", "1009", "VD", 46.51, 6.662], ["Gland", "1196", "VD", 46.421, 6.27],
  ["Aigle", "1860", "VD", 46.318, 6.969], ["Payerne", "1530", "VD", 46.822, 6.938], ["Orbe", "1350", "VD", 46.725, 6.532],
  ["Sainte-Croix", "1450", "VD", 46.822, 6.503], ["Vallorbe", "1337", "VD", 46.712, 6.379],
  ["Sion", "1950", "VS", 46.2331, 7.3606], ["Martigny", "1920", "VS", 46.1022, 7.0729], ["Monthey", "1870", "VS", 46.2549, 6.9541],
  ["Sierre", "3960", "VS", 46.292, 7.535], ["Brig", "3900", "VS", 46.3167, 7.9833, "de"], ["Visp", "3930", "VS", 46.293, 7.882, "de"],
  ["Zermatt", "3920", "VS", 46.0207, 7.7491, "de"], ["Verbier", "1936", "VS", 46.096, 7.228],
  ["Neuchâtel", "2000", "NE", 46.9896, 6.9293], ["La Chaux-de-Fonds", "2300", "NE", 47.0999, 6.8259], ["Le Locle", "2400", "NE", 47.056, 6.749], ["Fleurier", "2114", "NE", 46.903, 6.582],
  ["Genève", "1204", "GE", 46.2044, 6.1432], ["Carouge", "1227", "GE", 46.1815, 6.1395], ["Meyrin", "1217", "GE", 46.234, 6.08],
  ["Vernier", "1214", "GE", 46.217, 6.084], ["Lancy", "1212", "GE", 46.189, 6.116], ["Onex", "1213", "GE", 46.184, 6.102], ["Thônex", "1226", "GE", 46.192, 6.2],
  ["Delémont", "2800", "JU", 47.364, 7.344], ["Porrentruy", "2900", "JU", 47.4173, 7.0754], ["Saignelégier", "2350", "JU", 47.256, 6.996],
];

export const LOCALITIES = RAW_LOCALITIES.map(([name, npa, canton, lat, lng, lang]) => ({
  name, npa, canton, lat, lng, lang: lang || CANTONS[canton].lang,
}));

/** Supprime les accents pour des recherches tolérantes ("geneve" trouve "Genève"). */
export function normalize(text) {
  return String(text || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
}

/** Recherche locale d'une localité par nom ou NPA (fonctionne hors ligne). */
export function searchLocalities(query, limit = 8) {
  const q = normalize(query);
  if (!q) return [];
  const starts = [];
  const contains = [];
  for (const loc of LOCALITIES) {
    const n = normalize(loc.name);
    if (n.startsWith(q) || loc.npa.startsWith(q)) starts.push(loc);
    else if (n.includes(q)) contains.push(loc);
  }
  return [...starts, ...contains].slice(0, limit);
}

export function findLocality(name) {
  const q = normalize(name);
  return LOCALITIES.find((l) => normalize(l.name) === q) || null;
}

export const SWITZERLAND_CENTER = { lat: 46.8182, lng: 8.2275 };

/** Catégories : icône + teinte + libellés traduits. */
export const CATEGORIES = [
  { id: "shopping", icon: "cart", tone: 0, fr: "Courses & commissions", de: "Einkäufe & Besorgungen", it: "Spesa e commissioni", en: "Shopping & errands" },
  { id: "pets", icon: "paw", tone: 1, fr: "Animaux", de: "Tiere", it: "Animali", en: "Pets" },
  { id: "seniors", icon: "armchair", tone: 2, fr: "Aide aux aînés", de: "Hilfe für Senioren", it: "Aiuto agli anziani", en: "Help for seniors" },
  { id: "family", icon: "smile", tone: 3, fr: "Famille & enfants", de: "Familie & Kinder", it: "Famiglia e bambini", en: "Family & kids" },
  { id: "transport", icon: "car", tone: 4, fr: "Transport", de: "Fahrdienste", it: "Trasporti", en: "Transport & rides" },
  { id: "repair", icon: "wrench", tone: 5, fr: "Bricolage & réparations", de: "Heimwerken & Reparaturen", it: "Fai da te e riparazioni", en: "DIY & repairs" },
  { id: "digital", icon: "laptop", tone: 4, fr: "Aide informatique", de: "Computerhilfe", it: "Aiuto informatico", en: "Tech help" },
  { id: "language", icon: "languages", tone: 3, fr: "Langues & cours", de: "Sprachen & Nachhilfe", it: "Lingue e lezioni", en: "Languages & tutoring" },
  { id: "garden", icon: "sprout", tone: 0, fr: "Jardin", de: "Garten", it: "Giardino", en: "Garden" },
  { id: "home", icon: "home", tone: 2, fr: "Maison & ménage", de: "Haushalt", it: "Casa e pulizie", en: "Home & housekeeping" },
  { id: "moving", icon: "package", tone: 5, fr: "Déménagement", de: "Umzug", it: "Trasloco", en: "Moving" },
  { id: "donation", icon: "gift", tone: 1, fr: "Dons & objets", de: "Verschenken", it: "Regali e oggetti", en: "Giveaways" },
  { id: "community", icon: "users", tone: 0, fr: "Vie de quartier", de: "Quartierleben", it: "Vita di quartiere", en: "Neighbourhood life" },
  { id: "other", icon: "sparkles", tone: 3, fr: "Autre", de: "Sonstiges", it: "Altro", en: "Other" },
];

export const CATEGORY_IDS = CATEGORIES.map((c) => c.id);
export const getCategory = (id) => CATEGORIES.find((c) => c.id === id) || CATEGORIES[CATEGORIES.length - 1];

export const TYPES = ["offer", "request", "donation"];
export const PAYMENTS = ["free", "paid", "negotiable"];
export const UNITS = ["total", "hour", "visit"];
export const DURATIONS = [30, 60, 90, 120, 180, 240, 480];
export const RECURRENCES = ["once", "weekly", "monthly"];

/* ---------------------------------------------------------------------
   MODÈLES D'ANNONCES DE DÉMONSTRATION (traduits dans les 4 langues)
   c = catégorie, ty = type, pay = rémunération, amt = montant CHF,
   unit = unité, dur = durée (min), rec = récurrence
   --------------------------------------------------------------------- */
export const TEMPLATES = [
  { c: "shopping", ty: "offer", pay: "paid", amt: 15, unit: "visit", dur: 60,
    t: { fr: "Je fais vos courses de la semaine", de: "Ich erledige Ihren Wocheneinkauf", it: "Faccio la vostra spesa settimanale", en: "I'll do your weekly grocery run" },
    d: { fr: "Je passe à la Migros ou à la Coop pour vous et je livre à domicile. Idéal si vous avez peu de temps ou du mal à vous déplacer. Vous me donnez la liste, je m'occupe du reste.",
         de: "Ich gehe für Sie in die Migros oder den Coop und bringe alles nach Hause. Ideal, wenn Sie wenig Zeit haben oder nicht gut zu Fuss sind. Sie geben mir die Liste, ich kümmere mich um den Rest.",
         it: "Vado alla Migros o alla Coop per voi e consegno a domicilio. Ideale se avete poco tempo o difficoltà a spostarvi. Voi mi date la lista, io penso al resto.",
         en: "I'll go to Migros or Coop for you and deliver to your door. Perfect if you're short on time or have trouble getting around. Just give me the list and I'll take care of the rest." } },
  { c: "shopping", ty: "request", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Quelqu'un pour passer à la pharmacie ?", de: "Wer holt mir Medikamente in der Apotheke?", it: "Qualcuno può passare in farmacia per me?", en: "Could someone pick up my prescription?" },
    d: { fr: "Je suis alitée quelques jours après une opération et j'aurais besoin qu'on passe chercher mes médicaments à la pharmacie du quartier. L'ordonnance est déjà transmise.",
         de: "Ich bin nach einer Operation ein paar Tage ans Bett gebunden und bräuchte jemanden, der meine Medikamente in der Quartierapotheke abholt. Das Rezept ist bereits dort.",
         it: "Dopo un'operazione devo restare a letto qualche giorno e avrei bisogno che qualcuno ritiri i miei medicinali nella farmacia del quartiere. La ricetta è già stata inviata.",
         en: "I'm stuck in bed for a few days after surgery and need someone to collect my medication from the local pharmacy. The prescription has already been sent." } },
  { c: "pets", ty: "offer", pay: "paid", amt: 15, unit: "visit", dur: 60,
    t: { fr: "Promenade de chiens en semaine", de: "Hundespaziergänge unter der Woche", it: "Passeggiate con il cane in settimana", en: "Weekday dog walking" },
    d: { fr: "Amoureuse des animaux, je promène votre chien pendant que vous travaillez. Balades de 45 minutes par tous les temps, avec des photos envoyées par la messagerie.",
         de: "Als Tierfreundin führe ich Ihren Hund aus, während Sie arbeiten. Spaziergänge von 45 Minuten bei jedem Wetter – mit Fotos über den Chat.",
         it: "Amante degli animali, porto a spasso il vostro cane mentre lavorate. Passeggiate di 45 minuti con qualsiasi tempo, con foto inviate in chat.",
         en: "Animal lover here: I'll walk your dog while you're at work. 45-minute walks in any weather, with photos sent through the chat." } },
  { c: "pets", ty: "request", pay: "negotiable", amt: 0, unit: "visit", dur: 30,
    t: { fr: "Garde de chat pendant les vacances", de: "Katzensitting während der Ferien", it: "Cercasi cat sitter per le vacanze", en: "Cat sitting during the holidays" },
    d: { fr: "Nous partons deux semaines. Nous cherchons une personne de confiance pour nourrir notre chat et changer sa litière une fois par jour.",
         de: "Wir sind zwei Wochen weg und suchen eine vertrauenswürdige Person, die unsere Katze einmal täglich füttert und das Katzenklo reinigt.",
         it: "Partiamo per due settimane. Cerchiamo una persona di fiducia che dia da mangiare al nostro gatto e pulisca la lettiera una volta al giorno.",
         en: "We're away for two weeks and are looking for someone trustworthy to feed our cat and clean the litter box once a day." } },
  { c: "seniors", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 90,
    t: { fr: "Visites et compagnie pour personnes âgées", de: "Besuche und Gesellschaft für Senioren", it: "Visite e compagnia per persone anziane", en: "Visits and company for older people" },
    d: { fr: "Retraité, j'ai du temps libre et j'aime la conversation. Je propose de rendre visite, jouer aux cartes, faire une promenade ou simplement boire un café ensemble.",
         de: "Ich bin pensioniert, habe Zeit und unterhalte mich gerne. Ich biete Besuche, Kartenspiele, Spaziergänge oder einfach einen gemeinsamen Kaffee an.",
         it: "Sono in pensione, ho tempo libero e amo chiacchierare. Propongo visite, partite a carte, passeggiate o semplicemente un caffè insieme.",
         en: "I'm retired, have free time and love a good chat. I can drop by for cards, a walk or simply a coffee together." } },
  { c: "seniors", ty: "request", pay: "free", amt: 0, unit: "total", dur: 120,
    t: { fr: "Accompagner ma mère chez le médecin", de: "Begleitung zum Arzttermin gesucht", it: "Accompagnare mia madre dal medico", en: "Someone to take my mother to the doctor" },
    d: { fr: "Ma mère de 84 ans a un rendez-vous chez son médecin et ne conduit plus. Je cherche quelqu'un pour l'accompagner en transports publics, car je travaille ce jour-là.",
         de: "Meine 84-jährige Mutter hat einen Arzttermin und fährt nicht mehr Auto. Ich suche jemanden, der sie mit dem ÖV begleitet – ich muss an diesem Tag arbeiten.",
         it: "Mia madre di 84 anni ha un appuntamento dal medico e non guida più. Cerco qualcuno che la accompagni con i mezzi pubblici, perché quel giorno lavoro.",
         en: "My 84-year-old mother has a doctor's appointment and no longer drives. I'm looking for someone to go with her on public transport, as I'm working that day." } },
  { c: "family", ty: "offer", pay: "paid", amt: 20, unit: "hour", dur: 180,
    t: { fr: "Baby-sitting les soirs et week-ends", de: "Babysitting abends und am Wochenende", it: "Baby-sitting la sera e nel weekend", en: "Evening and weekend babysitting" },
    d: { fr: "Étudiante de 21 ans, j'ai suivi le cours de baby-sitting de la Croix-Rouge. Disponible les soirs et les week-ends pour garder vos enfants de 2 à 10 ans.",
         de: "Studentin, 21, mit dem Babysitting-Kurs des SRK. Abends und am Wochenende verfügbar für Kinder von 2 bis 10 Jahren.",
         it: "Studentessa di 21 anni, ho seguito il corso di baby-sitting della Croce Rossa. Disponibile la sera e nel fine settimana per bambini dai 2 ai 10 anni.",
         en: "21-year-old student with the Red Cross babysitting course. Available evenings and weekends for children aged 2 to 10." } },
  { c: "family", ty: "request", pay: "paid", amt: 20, unit: "hour", dur: 180, rec: "weekly",
    t: { fr: "Récupérer les enfants à l'école", de: "Kinder von der Schule abholen", it: "Prendere i bambini a scuola", en: "School pick-up for two kids" },
    d: { fr: "Deux après-midi par semaine, j'ai besoin de quelqu'un pour aller chercher mes deux enfants (6 et 8 ans) à l'école et les garder jusqu'à 18 h.",
         de: "An zwei Nachmittagen pro Woche brauche ich jemanden, der meine zwei Kinder (6 und 8) von der Schule abholt und bis 18 Uhr betreut.",
         it: "Due pomeriggi a settimana ho bisogno di qualcuno che vada a prendere i miei due figli (6 e 8 anni) a scuola e li tenga fino alle 18.",
         en: "Two afternoons a week I need someone to pick up my two children (6 and 8) from school and look after them until 6 pm." } },
  { c: "language", ty: "offer", pay: "paid", amt: 30, unit: "hour", dur: 60,
    t: { fr: "Aide aux devoirs – maths et français", de: "Nachhilfe in Mathe und Deutsch", it: "Aiuto compiti – matematica e italiano", en: "Homework help – maths and languages" },
    d: { fr: "Enseignant à la retraite, j'aide les élèves de la 5P à la 11H en mathématiques et en français. Méthode douce et beaucoup de patience.",
         de: "Als pensionierter Lehrer helfe ich Schülerinnen und Schülern der 3. bis 9. Klasse in Mathematik und Deutsch. Ruhige Art, viel Geduld.",
         it: "Insegnante in pensione, aiuto gli allievi delle elementari e delle medie in matematica e italiano. Metodo tranquillo e tanta pazienza.",
         en: "Retired teacher helping primary and secondary pupils with maths and languages. Calm approach and lots of patience." } },
  { c: "language", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 60, rec: "weekly",
    t: { fr: "Tandem de conversation français–allemand", de: "Sprachtandem Deutsch–Französisch", it: "Tandem linguistico italiano–tedesco", en: "Language exchange over coffee" },
    d: { fr: "Je parle français et j'aimerais améliorer mon allemand. On se retrouve autour d'un café : une demi-heure dans chaque langue.",
         de: "Ich spreche Deutsch und möchte mein Französisch verbessern. Treffen wir uns bei einem Kaffee: eine halbe Stunde pro Sprache.",
         it: "Parlo italiano e vorrei migliorare il mio tedesco. Ci vediamo per un caffè: mezz'ora in ogni lingua.",
         en: "Let's meet for coffee and practise languages together: half an hour in each language. All levels welcome." } },
  { c: "digital", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 60,
    t: { fr: "Aide smartphone et ordinateur pour débutants", de: "Handy- und Computerhilfe für Einsteiger", it: "Aiuto smartphone e computer per principianti", en: "Smartphone and computer help for beginners" },
    d: { fr: "Je vous aide à configurer votre téléphone, utiliser WhatsApp, faire des appels vidéo, gérer vos e-mails ou acheter un billet CFF en ligne.",
         de: "Ich helfe Ihnen beim Einrichten des Handys, bei WhatsApp, Videoanrufen, E-Mails oder beim Kauf eines SBB-Billetts online.",
         it: "Vi aiuto a configurare il telefono, usare WhatsApp, fare videochiamate, gestire le e-mail o comprare un biglietto FFS online.",
         en: "I'll help you set up your phone, use WhatsApp, make video calls, manage emails or buy an SBB train ticket online." } },
  { c: "digital", ty: "request", pay: "negotiable", amt: 0, unit: "visit", dur: 60,
    t: { fr: "Mon imprimante ne fonctionne plus", de: "Mein Drucker funktioniert nicht mehr", it: "La mia stampante non funziona più", en: "My printer stopped working" },
    d: { fr: "Depuis une mise à jour, mon ordinateur ne trouve plus l'imprimante. Quelqu'un de patient pourrait-il passer jeter un œil ?",
         de: "Seit einem Update findet mein Computer den Drucker nicht mehr. Könnte jemand mit Geduld vorbeikommen und nachschauen?",
         it: "Dopo un aggiornamento il computer non trova più la stampante. Qualcuno di paziente potrebbe passare a dare un'occhiata?",
         en: "Since an update, my computer can't find the printer anymore. Could someone patient come by and take a look?" } },
  { c: "digital", ty: "offer", pay: "paid", amt: 25, unit: "hour", dur: 120,
    t: { fr: "Numérisation de photos et diapositives", de: "Digitalisierung von Fotos und Dias", it: "Digitalizzazione di foto e diapositive", en: "Digitising photos and slides" },
    d: { fr: "Je numérise vos anciennes photos, diapositives et cassettes vidéo pour les conserver et les partager en famille.",
         de: "Ich digitalisiere Ihre alten Fotos, Dias und Videokassetten, damit Sie sie aufbewahren und mit der Familie teilen können.",
         it: "Digitalizzo vecchie foto, diapositive e videocassette per conservarle e condividerle in famiglia.",
         en: "I'll digitise your old photos, slides and video tapes so you can keep them and share them with family." } },
  { c: "transport", ty: "offer", pay: "paid", amt: 30, unit: "total", dur: 90,
    t: { fr: "Transport pour objets encombrants", de: "Transport für sperrige Sachen", it: "Trasporto per oggetti ingombranti", en: "Van for bulky items" },
    d: { fr: "J'ai une camionnette et je peux transporter un meuble, des achats encombrants ou des objets pour la déchetterie.",
         de: "Ich habe einen Lieferwagen und transportiere Möbel, sperrige Einkäufe oder Sachen für die Entsorgungsstelle.",
         it: "Ho un furgoncino e posso trasportare un mobile, acquisti ingombranti o oggetti da portare all'ecocentro.",
         en: "I have a small van and can move a piece of furniture, bulky shopping or items for the recycling centre." } },
  { c: "transport", ty: "request", pay: "free", amt: 0, unit: "total", dur: 60, rec: "weekly",
    t: { fr: "Covoiturage pour le marché du samedi", de: "Mitfahrgelegenheit zum Samstagsmarkt", it: "Passaggio per il mercato del sabato", en: "Lift to the Saturday market" },
    d: { fr: "Je n'ai pas de voiture et le marché est mal desservi le samedi matin. Quelqu'un y va régulièrement et aurait une place ?",
         de: "Ich habe kein Auto und der Markt ist am Samstagmorgen schlecht erreichbar. Fährt jemand regelmässig hin und hätte einen Platz frei?",
         it: "Non ho l'auto e il sabato mattina il mercato è mal servito. Qualcuno ci va regolarmente e ha un posto libero?",
         en: "I don't have a car and the market is poorly served on Saturday mornings. Does anyone go regularly and have a free seat?" } },
  { c: "repair", ty: "offer", pay: "negotiable", amt: 0, unit: "visit", dur: 120,
    t: { fr: "Petits travaux de bricolage à domicile", de: "Kleine Handwerksarbeiten zu Hause", it: "Piccoli lavori di bricolage a domicilio", en: "Small DIY jobs at home" },
    d: { fr: "Monter un meuble, fixer une étagère, changer une ampoule difficile d'accès ou réparer un robinet qui goutte : j'ai l'outillage et l'expérience.",
         de: "Möbel aufbauen, ein Regal montieren, schwer erreichbare Lampen wechseln oder einen tropfenden Wasserhahn reparieren: Werkzeug und Erfahrung sind vorhanden.",
         it: "Montare un mobile, fissare una mensola, cambiare una lampadina difficile da raggiungere o riparare un rubinetto che gocciola: ho gli attrezzi e l'esperienza.",
         en: "Assembling furniture, putting up a shelf, changing a hard-to-reach bulb or fixing a dripping tap: I have the tools and the experience." } },
  { c: "repair", ty: "request", pay: "paid", amt: 40, unit: "total", dur: 60,
    t: { fr: "Réparer mon vélo (freins et vitesses)", de: "Velo reparieren (Bremsen und Schaltung)", it: "Riparare la mia bici (freni e cambio)", en: "Bike repair (brakes and gears)" },
    d: { fr: "Mon vélo a besoin d'un réglage des freins et du dérailleur. Les pièces sont à ma charge, merci d'avance pour votre aide !",
         de: "Mein Velo braucht eine Einstellung der Bremsen und der Schaltung. Ersatzteile zahle ich – danke für die Hilfe!",
         it: "La mia bici ha bisogno di una regolazione dei freni e del cambio. I pezzi li pago io, grazie in anticipo!",
         en: "My bike needs its brakes and gears adjusted. I'll pay for any parts — thanks in advance for your help!" } },
  { c: "garden", ty: "request", pay: "paid", amt: 25, unit: "hour", dur: 180,
    t: { fr: "Aide pour tailler la haie", de: "Hilfe beim Heckenschneiden", it: "Aiuto per potare la siepe", en: "Help trimming the hedge" },
    d: { fr: "Notre haie a bien poussé. Nous cherchons un coup de main pour la tailler et évacuer les branches. Taille-haie et échelle fournis.",
         de: "Unsere Hecke ist stark gewachsen. Wir suchen Hilfe beim Schneiden und Wegbringen der Äste. Heckenschere und Leiter sind vorhanden.",
         it: "La nostra siepe è cresciuta parecchio. Cerchiamo aiuto per potarla e portare via i rami. Tagliasiepi e scala a disposizione.",
         en: "Our hedge has grown a lot. We need a hand trimming it and clearing the branches. Hedge trimmer and ladder provided." } },
  { c: "garden", ty: "donation", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Plantons de tomates à donner", de: "Tomatensetzlinge zu verschenken", it: "Piantine di pomodoro da regalare", en: "Tomato seedlings to give away" },
    d: { fr: "J'ai trop de plantons cette année : tomates, courgettes et basilic. Venez les chercher, je vous donne aussi quelques conseils de culture.",
         de: "Ich habe dieses Jahr zu viele Setzlinge: Tomaten, Zucchetti und Basilikum. Holen Sie sie ab – Tipps zum Anbau gibt es gratis dazu.",
         it: "Quest'anno ho troppe piantine: pomodori, zucchine e basilico. Venite a prenderle, vi do anche qualche consiglio.",
         en: "I have too many seedlings this year: tomatoes, courgettes and basil. Come and pick them up — gardening tips included." } },
  { c: "home", ty: "offer", pay: "paid", amt: 28, unit: "hour", dur: 180,
    t: { fr: "Aide au ménage et au repassage", de: "Hilfe bei Haushalt und Bügeln", it: "Aiuto per pulizie e stiro", en: "Cleaning and ironing help" },
    d: { fr: "Soigneuse et discrète, je vous aide pour le ménage, le repassage ou un grand nettoyage de printemps.",
         de: "Sorgfältig und diskret helfe ich Ihnen beim Putzen, Bügeln oder beim grossen Frühlingsputz.",
         it: "Precisa e discreta, vi aiuto con le pulizie, lo stiro o le grandi pulizie di primavera.",
         en: "Careful and discreet, I can help with cleaning, ironing or a big spring clean." } },
  { c: "home", ty: "request", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Arroser mes plantes pendant mon absence", de: "Pflanzen giessen während meiner Abwesenheit", it: "Innaffiare le piante durante la mia assenza", en: "Water my plants while I'm away" },
    d: { fr: "Je m'absente une semaine. Qui pourrait passer deux fois pour arroser mes plantes ? Je rendrai volontiers la pareille.",
         de: "Ich bin eine Woche weg. Wer könnte zweimal vorbeikommen und meine Pflanzen giessen? Ich revanchiere mich gern.",
         it: "Sarò via una settimana. Chi potrebbe passare due volte ad annaffiare le mie piante? Ricambierò volentieri.",
         en: "I'm away for a week. Could someone drop by twice to water my plants? Happy to return the favour." } },
  { c: "moving", ty: "request", pay: "paid", amt: 25, unit: "hour", dur: 240,
    t: { fr: "Besoin de bras pour un déménagement", de: "Helfer für einen Umzug gesucht", it: "Cercasi braccia per un trasloco", en: "Extra hands for a move" },
    d: { fr: "Je déménage d'un 3e étage sans ascenseur. Je cherche deux personnes motivées pour porter les cartons. Pizza et boissons offertes !",
         de: "Ich ziehe aus dem 3. Stock ohne Lift aus und suche zwei motivierte Personen zum Kistentragen. Pizza und Getränke offeriert!",
         it: "Trasloco da un terzo piano senza ascensore. Cerco due persone motivate per portare gli scatoloni. Pizza e bibite offerte!",
         en: "I'm moving out of a 3rd-floor flat with no lift and need two motivated people to carry boxes. Pizza and drinks on me!" } },
  { c: "moving", ty: "donation", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Cartons de déménagement à donner", de: "Umzugskartons zu verschenken", it: "Scatoloni da trasloco da regalare", en: "Moving boxes to give away" },
    d: { fr: "Une trentaine de cartons solides, déjà pliés, et du papier bulle. À venir chercher rapidement.",
         de: "Rund dreissig stabile, zusammengefaltete Kartons und Luftpolsterfolie. Bitte bald abholen.",
         it: "Una trentina di scatoloni robusti già piegati e del pluriball. Da ritirare al più presto.",
         en: "About thirty sturdy flat-packed boxes plus bubble wrap. Please pick them up soon." } },
  { c: "donation", ty: "donation", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Table en bois et quatre chaises", de: "Holztisch mit vier Stühlen", it: "Tavolo in legno e quattro sedie", en: "Wooden table and four chairs" },
    d: { fr: "Table en chêne massif (160 × 90 cm) et quatre chaises en bon état. À donner contre un petit coup de main pour la descente.",
         de: "Massiver Eichentisch (160 × 90 cm) und vier Stühle in gutem Zustand. Gratis gegen etwas Hilfe beim Heruntertragen.",
         it: "Tavolo in rovere massiccio (160 × 90 cm) e quattro sedie in buono stato. In regalo, basta un aiuto a portarli giù.",
         en: "Solid oak table (160 × 90 cm) and four chairs in good condition. Free — just help me carry them downstairs." } },
  { c: "donation", ty: "donation", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Vêtements d'enfant 2–4 ans", de: "Kinderkleider 2–4 Jahre", it: "Vestiti per bambini 2–4 anni", en: "Children's clothes, ages 2–4" },
    d: { fr: "Deux sacs de vêtements d'enfant propres et en bon état, pour garçon et fille. Idéal pour une famille qui s'agrandit.",
         de: "Zwei Säcke saubere Kinderkleider in gutem Zustand, für Buben und Mädchen. Ideal für eine wachsende Familie.",
         it: "Due sacchi di vestiti per bambini puliti e in buono stato, per maschi e femmine. Ideali per una famiglia che cresce.",
         en: "Two bags of clean children's clothes in good condition, for boys and girls. Ideal for a growing family." } },
  { c: "donation", ty: "donation", pay: "free", amt: 0, unit: "total", dur: 30,
    t: { fr: "Livres et bandes dessinées", de: "Bücher und Comics", it: "Libri e fumetti", en: "Books and comics" },
    d: { fr: "Je vide ma bibliothèque : romans, livres de cuisine et une belle collection de BD. Servez-vous !",
         de: "Ich räume mein Büchergestell: Romane, Kochbücher und eine schöne Comic-Sammlung. Bedienen Sie sich!",
         it: "Svuoto la mia libreria: romanzi, libri di cucina e una bella collezione di fumetti. Servitevi pure!",
         en: "Clearing my bookshelves: novels, cookbooks and a nice comic collection. Help yourself!" } },
  { c: "community", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 180, rec: "monthly",
    t: { fr: "Repair Café du quartier", de: "Repair Café im Quartier", it: "Repair Café di quartiere", en: "Neighbourhood Repair Café" },
    d: { fr: "Chaque mois, des bénévoles réparent gratuitement petits appareils, vêtements et vélos. Apportez vos objets cassés, on les répare ensemble !",
         de: "Jeden Monat reparieren Freiwillige kostenlos Kleingeräte, Kleider und Velos. Bringen Sie Ihre kaputten Sachen mit – wir flicken sie gemeinsam!",
         it: "Ogni mese dei volontari riparano gratuitamente piccoli elettrodomestici, vestiti e bici. Portate i vostri oggetti rotti, li ripariamo insieme!",
         en: "Every month, volunteers repair small appliances, clothes and bikes for free. Bring your broken items and we'll fix them together!" } },
  { c: "community", ty: "request", pay: "free", amt: 0, unit: "total", dur: 180,
    t: { fr: "Bénévoles pour la fête des voisins", de: "Freiwillige für das Nachbarschaftsfest", it: "Volontari per la festa dei vicini", en: "Volunteers for the neighbours' party" },
    d: { fr: "Nous organisons la fête des voisins de l'immeuble. Qui peut aider à installer les tables, préparer un gâteau ou animer un jeu pour les enfants ?",
         de: "Wir organisieren ein Fest für die Nachbarschaft. Wer hilft beim Aufstellen der Tische, backt einen Kuchen oder leitet ein Spiel für Kinder?",
         it: "Organizziamo la festa dei vicini del palazzo. Chi può aiutare a montare i tavoli, preparare una torta o animare un gioco per i bambini?",
         en: "We're organising a party for our building. Who can help set up tables, bake a cake or run a game for the kids?" } },
  { c: "community", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 60, rec: "weekly",
    t: { fr: "Balade du dimanche en groupe", de: "Gemeinsamer Sonntagsspaziergang", it: "Passeggiata domenicale in gruppo", en: "Sunday group walk" },
    d: { fr: "Chaque semaine, une balade tranquille d'une heure pour découvrir la région et faire connaissance. Ouvert à toutes et à tous, rythme doux.",
         de: "Jede Woche ein gemütlicher, einstündiger Spaziergang, um die Gegend zu entdecken und sich kennenzulernen. Offen für alle, gemächliches Tempo.",
         it: "Ogni settimana una passeggiata tranquilla di un'ora per scoprire la zona e conoscersi. Aperta a tutti, ritmo lento.",
         en: "A relaxed one-hour walk every week to explore the area and meet people. Open to everyone, gentle pace." } },
  { c: "other", ty: "request", pay: "negotiable", amt: 0, unit: "total", dur: 60,
    t: { fr: "Aide pour ma déclaration d'impôts", de: "Hilfe bei der Steuererklärung", it: "Aiuto per la dichiarazione d'imposta", en: "Help with my tax return" },
    d: { fr: "Je viens d'arriver dans le canton et je ne comprends pas bien le formulaire de déclaration d'impôts. Quelqu'un d'expérimenté pourrait-il m'expliquer ?",
         de: "Ich bin neu im Kanton und verstehe das Formular der Steuererklärung nicht ganz. Könnte mir jemand mit Erfahrung helfen?",
         it: "Sono appena arrivato nel cantone e non capisco bene il modulo della dichiarazione d'imposta. Qualcuno con esperienza potrebbe spiegarmelo?",
         en: "I've just moved to the canton and don't quite understand the tax return form. Could someone experienced walk me through it?" } },
  { c: "other", ty: "offer", pay: "paid", amt: 20, unit: "hour", dur: 120,
    t: { fr: "Cours de cuisine italienne à domicile", de: "Italienischer Kochkurs bei Ihnen zu Hause", it: "Corso di cucina italiana a domicilio", en: "Italian cooking class at your home" },
    d: { fr: "Pâtes fraîches, risotto, tiramisu : je vous apprends les recettes de ma nonna dans votre cuisine. Pour 1 à 4 personnes.",
         de: "Frische Pasta, Risotto, Tiramisu: Ich zeige Ihnen die Rezepte meiner Nonna in Ihrer Küche. Für 1 bis 4 Personen.",
         it: "Pasta fresca, risotto, tiramisù: vi insegno le ricette della nonna nella vostra cucina. Da 1 a 4 persone.",
         en: "Fresh pasta, risotto, tiramisu: I'll teach you my nonna's recipes in your own kitchen. For 1 to 4 people." } },
  { c: "seniors", ty: "offer", pay: "free", amt: 0, unit: "total", dur: 60, rec: "weekly",
    t: { fr: "Lecture à voix haute", de: "Vorlesen für Seniorinnen und Senioren", it: "Lettura ad alta voce", en: "Reading aloud" },
    d: { fr: "J'aime lire et je propose de faire la lecture du journal ou d'un roman aux personnes malvoyantes ou qui apprécient simplement la compagnie.",
         de: "Ich lese gerne und biete an, Zeitung oder Romane für sehbehinderte Menschen oder alle, die Gesellschaft schätzen, vorzulesen.",
         it: "Mi piace leggere e propongo di leggere il giornale o un romanzo a persone ipovedenti o a chi apprezza un po' di compagnia.",
         en: "I love reading and can read the newspaper or a novel to people with impaired vision, or anyone who enjoys some company." } },
];

/** Prénoms et noms réalistes selon la région linguistique. */
export const NAMES = {
  fr: {
    first: ["Léa", "Camille", "Chloé", "Manon", "Julie", "Sophie", "Élodie", "Nathalie", "Lucas", "Thomas", "Nicolas", "Julien", "Mathieu", "Olivier", "Antoine", "Yves", "Pascal", "Aline", "Céline", "Karim", "Amélie", "Loïc", "Inès", "Samuel"],
    last: ["Favre", "Rochat", "Bonvin", "Dubois", "Perrin", "Jaquet", "Monnier", "Chappuis", "Pittet", "Rey", "Mottier", "Cuendet", "Aebischer", "Berset", "Gashi", "Da Silva", "Nguyen", "Morel"],
  },
  de: {
    first: ["Anna", "Laura", "Sarah", "Lea", "Nina", "Sandra", "Ursula", "Monika", "Luca", "Noah", "Jonas", "David", "Daniel", "Marco", "Stefan", "Reto", "Beat", "Thomas", "Fabienne", "Mia", "Leon", "Arben", "Selin", "Elias"],
    last: ["Müller", "Meier", "Schmid", "Keller", "Weber", "Huber", "Schneider", "Brunner", "Baumann", "Fischer", "Gerber", "Steiner", "Frei", "Graf", "Krasniqi", "Ferreira", "Yilmaz", "Bühler"],
  },
  it: {
    first: ["Giulia", "Chiara", "Sara", "Martina", "Francesca", "Elena", "Luca", "Marco", "Matteo", "Davide", "Andrea", "Paolo", "Giorgio", "Sofia", "Alessandro", "Noemi"],
    last: ["Bernasconi", "Rossi", "Ferrari", "Bianchi", "Lombardi", "Galli", "Fontana", "Pedrazzini", "Rezzonico", "Colombo", "Moretti", "Guidi"],
  },
};

export const SPECIALTY_POOL = {
  shopping: ["courses", "Einkaufen", "spesa", "errands"],
  pets: ["animaux", "Tiere", "animali", "pets"],
  seniors: ["accompagnement", "Begleitung", "compagnia", "companionship"],
  family: ["enfants", "Kinder", "bambini", "childcare"],
  transport: ["transport", "Fahrdienst", "trasporti", "driving"],
  repair: ["bricolage", "Handwerk", "fai da te", "DIY"],
  digital: ["informatique", "Informatik", "informatica", "IT"],
  language: ["langues", "Sprachen", "lingue", "languages"],
  garden: ["jardinage", "Gartenarbeit", "giardinaggio", "gardening"],
  home: ["ménage", "Haushalt", "casa", "housekeeping"],
  moving: ["déménagement", "Umzug", "trasloco", "moving"],
  donation: ["récup'", "Recycling", "riuso", "reuse"],
  community: ["vie de quartier", "Quartier", "quartiere", "community"],
  other: ["cuisine", "Kochen", "cucina", "cooking"],
};
