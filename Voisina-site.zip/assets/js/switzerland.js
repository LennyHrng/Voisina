/* Silhouette simplifiée de la Suisse (longitude, latitude) pour l'illustration
   de la page d'accueil, et projection des annonces sur ce dessin. */
import { raw } from "./util.js";

const BORDER = [
  [7.59, 47.59], [7.7, 47.54], [7.95, 47.55], [8.22, 47.61], [8.42, 47.58], [8.55, 47.62], [8.4, 47.68], [8.47, 47.77],
  [8.6, 47.8], [8.7, 47.79], [8.81, 47.72], [8.73, 47.69], [8.86, 47.66], [9.0, 47.66], [9.18, 47.66], [9.4, 47.55],
  [9.56, 47.53], [9.67, 47.46], [9.55, 47.3], [9.48, 47.1], [9.6, 47.05], [9.87, 46.99], [10.1, 46.92], [10.23, 46.87],
  [10.39, 46.98], [10.49, 46.94], [10.47, 46.8], [10.49, 46.62], [10.43, 46.54], [10.3, 46.55], [10.1, 46.42], [10.16, 46.26],
  [10.05, 46.3], [9.95, 46.37], [9.72, 46.3], [9.51, 46.33], [9.45, 46.45], [9.3, 46.5], [9.27, 46.42], [9.15, 46.2],
  [9.07, 45.92], [9.02, 45.83], [8.94, 45.84], [8.86, 45.97], [8.79, 46.0], [8.71, 46.11], [8.61, 46.13], [8.45, 46.25],
  [8.44, 46.44], [8.3, 46.41], [8.14, 46.25], [7.99, 46.05], [7.86, 45.92], [7.66, 45.98], [7.35, 45.91], [7.17, 45.87],
  [7.04, 45.93], [6.93, 46.06], [6.8, 46.16], [6.87, 46.28], [6.79, 46.39], [6.55, 46.4], [6.23, 46.31], [6.31, 46.25],
  [6.17, 46.18], [6.1, 46.14], [5.96, 46.14], [6.0, 46.23], [6.12, 46.31], [6.07, 46.41], [6.07, 46.46], [6.14, 46.56],
  [6.37, 46.71], [6.45, 46.84], [6.46, 46.91], [6.63, 46.97], [6.72, 47.03], [6.85, 47.08], [6.95, 47.25], [7.03, 47.36],
  [6.88, 47.37], [6.95, 47.44], [7.0, 47.5], [7.13, 47.5], [7.2, 47.44], [7.33, 47.44], [7.45, 47.47], [7.53, 47.5],
];

const K = 200;
const COS = Math.cos((46.8 * Math.PI) / 180);
export const VIEW_W = 640;
export const VIEW_H = 412;

export function project(lng, lat) {
  return [(lng - 5.9) * K * COS + 4, (47.87 - lat) * K + 4];
}

export const outlinePath = () =>
  BORDER.map(([lng, lat], i) => {
    const [x, y] = project(lng, lat);
    return `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join("") + "Z";

/** Lac Léman (très simplifié) pour reconnaître la carte au premier coup d'œil. */
const LEMAN = [[6.15, 46.21], [6.25, 46.3], [6.45, 46.4], [6.62, 46.5], [6.8, 46.47], [6.91, 46.39], [6.78, 46.39], [6.55, 46.38], [6.3, 46.34], [6.17, 46.24]];
export const lemanPath = () =>
  LEMAN.map(([lng, lat], i) => {
    const [x, y] = project(lng, lat);
    return `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join("") + "Z";

export function swissMapSvg(dots = []) {
  const circles = dots
    .map((d) => {
      const [x, y] = project(d.lng, d.lat);
      return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${d.r || 3.2}" class="dot tone-${d.tone}"/>`;
    })
    .join("");
  return raw(`<svg class="swiss-map" viewBox="0 0 ${VIEW_W} ${VIEW_H}" role="img" aria-hidden="true" focusable="false">
    <path class="swiss-shape" d="${outlinePath()}"/>
    <path class="swiss-lake" d="${lemanPath()}"/>
    <g class="swiss-dots">${circles}</g>
  </svg>`);
}
