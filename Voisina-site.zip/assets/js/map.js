/* =====================================================================
   CARTE (Leaflet + fond de carte officiel swisstopo)
   ---------------------------------------------------------------------
   - Fond de carte : Office fédéral de topographie (swisstopo), données
     libres. Si le service ne répond pas, on bascule sur OpenStreetMap.
   - Vie privée : zoom maximal limité et positions floutées (±1 km),
     on ne peut donc jamais voir l'adresse exacte de quelqu'un.
   - Si la librairie de carte ne charge pas, le reste du site continue
     de fonctionner normalement (l'ancienne version plantait entièrement).
   ===================================================================== */
import { html, esc } from "./util.js";
import { icon } from "./icons.js";
import { t } from "./i18n.js";
import { getCategory } from "./data.js";
import { priceLabel, listingTitle } from "./ui.js";

export const MAX_ZOOM = 15;
const SWISS_BOUNDS = [[45.75, 5.9], [47.85, 10.55]];

export const leafletReady = () => typeof window.L !== "undefined" && typeof window.L.map === "function";

export function mapUnavailable(el) {
  el.classList.add("map-fallback");
  el.innerHTML = html`<div class="map-fallback-inner">${icon("map")}<p>${t("map.unavailable")}</p></div>`.toString();
}

function addBaseLayer(map) {
  const L = window.L;
  const swiss = L.tileLayer("https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-grau/default/current/3857/{z}/{x}/{y}.jpeg", {
    maxZoom: 18,
    attribution: '&copy; <a href="https://www.swisstopo.admin.ch/" target="_blank" rel="noopener noreferrer">swisstopo</a>',
  });
  let loaded = 0;
  let errors = 0;
  let switched = false;
  swiss.on("tileload", () => { loaded++; });
  swiss.on("tileerror", () => {
    errors++;
    if (!switched && loaded === 0 && errors >= 4) {
      switched = true;
      map.removeLayer(swiss);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>',
      }).addTo(map);
    }
  });
  swiss.addTo(map);
}

/** Crée une carte dans un élément. */
export function createMap(el, { center = [46.8, 8.23], zoom = 8, interactive = true } = {}) {
  if (!leafletReady()) { mapUnavailable(el); return null; }
  try {
    const L = window.L;
    const map = L.map(el, {
      center,
      zoom,
      minZoom: 7,
      maxZoom: MAX_ZOOM,
      maxBounds: [[45.2, 5.0], [48.4, 11.4]],
      zoomControl: interactive,
      scrollWheelZoom: false,
      dragging: interactive,
      touchZoom: interactive,
      doubleClickZoom: interactive,
      keyboard: interactive,
      attributionControl: true,
    });
    map.attributionControl.setPrefix(false);
    addBaseLayer(map);
    // Molette active seulement après un clic sur la carte (évite de "piéger" le défilement de la page).
    if (interactive) {
      map.once("focus", () => map.scrollWheelZoom.enable());
      map.on("click", () => map.scrollWheelZoom.enable());
    }
    return map;
  } catch (e) {
    console.error(e);
    mapUnavailable(el);
    return null;
  }
}

function pinIcon(listing, active = false) {
  const cat = getCategory(listing.category);
  return window.L.divIcon({
    className: "",
    html: `<span class="map-pin tone-${cat.tone}${listing.urgent ? " is-urgent" : ""}${active ? " is-active" : ""}">${icon(cat.icon)}</span>`,
    iconSize: [34, 34],
    iconAnchor: [17, 17],
    popupAnchor: [0, -16],
  });
}

function clusterIcon(count) {
  const size = count < 10 ? "s" : count < 50 ? "m" : "l";
  const px = size === "s" ? 36 : size === "m" ? 44 : 54;
  return window.L.divIcon({
    className: "",
    html: `<span class="map-cluster size-${size}"><span>${count}</span></span>`,
    iconSize: [px, px],
    iconAnchor: [px / 2, px / 2],
  });
}

function popupContent(listing) {
  return html`<div class="map-popup">
    <a class="map-popup-title" href="#/annonce/${listing.id}">${listingTitle(listing)}</a>
    <div class="map-popup-meta">${listing.city} · ${listing.canton}</div>
    <div class="map-popup-foot"><strong>${priceLabel(listing)}</strong><a class="btn btn-primary btn-xs" href="#/annonce/${listing.id}">${t("common.view")}</a></div>
  </div>`.toString();
}

/** Couche d'annonces avec regroupement automatique ("clusters"). */
export function listingsLayer(map) {
  const L = window.L;
  const group = L.layerGroup().addTo(map);
  let items = [];
  let highlighted = null;

  function draw() {
    group.clearLayers();
    const zoom = map.getZoom();
    const bounds = map.getBounds().pad(0.25);
    const cell = zoom >= 13 ? 40 : 58;
    const cells = new Map();
    for (const l of items) {
      if (!bounds.contains([l.lat, l.lng])) continue;
      const p = map.project([l.lat, l.lng], zoom);
      const key = `${Math.floor(p.x / cell)}:${Math.floor(p.y / cell)}`;
      if (!cells.has(key)) cells.set(key, []);
      cells.get(key).push(l);
    }
    for (const members of cells.values()) {
      if (members.length === 1 || zoom >= MAX_ZOOM) {
        members.forEach((l, i) => {
          // Petits décalages si plusieurs annonces se superposent au zoom maximal
          const offset = members.length > 1 ? 0.0009 * i : 0;
          const m = L.marker([l.lat + offset, l.lng + offset], { icon: pinIcon(l, l.id === highlighted), title: listingTitle(l), riseOnHover: true, keyboard: true });
          m.bindPopup(popupContent(l), { maxWidth: 260, minWidth: 200 });
          m.addTo(group);
        });
      } else {
        const lat = members.reduce((s, l) => s + l.lat, 0) / members.length;
        const lng = members.reduce((s, l) => s + l.lng, 0) / members.length;
        const m = L.marker([lat, lng], { icon: clusterIcon(members.length), title: t("map.clusterTitle", { count: members.length }), keyboard: true });
        m.on("click", () => {
          const b = L.latLngBounds(members.map((l) => [l.lat, l.lng]));
          map.fitBounds(b, { padding: [50, 50], maxZoom: Math.min(MAX_ZOOM, zoom + 3) });
        });
        m.addTo(group);
      }
    }
  }

  map.on("zoomend moveend", draw);
  return {
    setItems(list, { fit = false } = {}) {
      items = list;
      if (fit && list.length) {
        const b = L.latLngBounds(list.map((l) => [l.lat, l.lng]));
        map.fitBounds(b, { padding: [40, 40], maxZoom: 12 });
      }
      draw();
    },
    highlight(id) { highlighted = id; draw(); },
  };
}

/** Petite carte d'une annonce : zone approximative (cercle), jamais de point exact. */
export function detailMap(el, listing) {
  const map = createMap(el, { center: [listing.lat, listing.lng], zoom: 13, interactive: true });
  if (!map) return null;
  window.L.circle([listing.lat, listing.lng], { radius: 900, color: "#2F6F4E", weight: 2, fillColor: "#5E9F68", fillOpacity: 0.18, interactive: false }).addTo(map);
  return map;
}

export function fitSwitzerland(map) {
  map.fitBounds(SWISS_BOUNDS, { padding: [10, 10] });
}

export { esc };
