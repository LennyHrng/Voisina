/* =====================================================================
   SÉCURITÉ DES COMPTES
   ---------------------------------------------------------------------
   - Les mots de passe ne sont JAMAIS enregistrés : on garde seulement une
     "empreinte" PBKDF2-SHA256 (600 000 itérations + sel aléatoire, norme
     recommandée par l'OWASP). Impossible de retrouver le mot de passe.
   - La session ne contient qu'un identifiant et une date d'expiration.
   - Après 5 essais ratés, la connexion est bloquée temporairement
     (protection contre les attaques par force brute).

   LIMITE (honnête) : ce prototype n'a pas de serveur. Tout se passe dans
   le navigateur ; pour un vrai lancement, ces contrôles doivent être faits
   sur un serveur (voir docs/SECURITE.md).
   ===================================================================== */
import { storage, uid } from "./util.js";

const ITERATIONS = 600000;
const SESSION_DAYS = 14;

const toB64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const fromB64 = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));

/** Calcule l'empreinte d'un mot de passe. */
export async function hashPassword(password, saltB64 = null, iterations = ITERATIONS) {
  const salt = saltB64 ? fromB64(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256);
  return { algo: "PBKDF2-SHA256", iterations, salt: toB64(salt), hash: toB64(bits) };
}

/** Comparaison en temps constant (évite les attaques temporelles). */
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function verifyPassword(password, record) {
  if (!record || !record.salt || !record.hash) return false;
  const computed = await hashPassword(password, record.salt, record.iterations || ITERATIONS);
  return safeEqual(computed.hash, record.hash);
}

/* Compte administrateur de démonstration (demandé pour le projet).
   Identifiant : admin — le mot de passe n'apparaît PAS dans le code :
   seule son empreinte PBKDF2 est présente. */
export const ADMIN_ACCOUNT = {
  id: "admin",
  email: "admin@voisina.ch",
  firstname: "Équipe",
  lastname: "Voisina",
  role: "admin",
  verified: true,
  city: "Yverdon-les-Bains",
  canton: "VD",
  languages: ["fr", "de", "it", "en"],
  specialties: [],
  bio: "",
  created: "2026-01-01T00:00:00.000Z",
  password: {
    algo: "PBKDF2-SHA256",
    iterations: 600000,
    salt: "jIBAzr+12tTP0RjGBPxuYg==",
    hash: "oE2TyT3mXGdo87J/zcdjBDy+P0LwYMkGl3nu1LZwVLo=",
  },
};

/* ---------------------- Mots de passe : règles ---------------------- */
const COMMON = ["12345678", "123456789", "1234567890", "password", "motdepasse", "passwort", "azertyuiop", "qwertzuiop", "qwertyuiop", "11111111", "00000000", "iloveyou", "voisina123", "switzerland", "suisse123", "schweiz123", "admin123", "password1", "abcdefgh"];

/** Retourne un score de 0 à 4 et la liste des problèmes. */
export function passwordStrength(pw, context = []) {
  const value = String(pw || "");
  const issues = [];
  if (value.length < 10) issues.push("length");
  const lower = value.toLowerCase();
  if (COMMON.includes(lower) || context.some((c) => c && c.length > 2 && lower.includes(String(c).toLowerCase()))) issues.push("common");
  let variety = 0;
  if (/[a-z]/.test(value)) variety++;
  if (/[A-Z]/.test(value)) variety++;
  if (/\d/.test(value)) variety++;
  if (/[^A-Za-z0-9]/.test(value)) variety++;
  // Une longue phrase de passe (16+ caractères) est acceptée même sans chiffres/symboles.
  if (variety < 3 && value.length < 16) issues.push("variety");
  let score = 0;
  if (value.length >= 10) score++;
  if (value.length >= 14) score++;
  if (variety >= 3) score++;
  if (variety === 4) score++;
  if (issues.includes("common")) score = 0;
  return { score: Math.min(4, score), issues, ok: !issues.length };
}

/* ---------------------- Anti force brute ---------------------- */
export function loginLock() {
  const state = storage.get("loginGuard", { fails: 0, until: 0 });
  const remaining = Math.max(0, Math.ceil((state.until - Date.now()) / 1000));
  return { ...state, remaining };
}

export function registerFailure() {
  const state = storage.get("loginGuard", { fails: 0, until: 0 });
  const fails = state.fails + 1;
  let until = 0;
  if (fails >= 5) until = Date.now() + Math.min(15 * 60, 30 * 2 ** (fails - 5)) * 1000;
  storage.set("loginGuard", { fails, until });
}

export function resetFailures() {
  storage.set("loginGuard", { fails: 0, until: 0 });
}

/* ---------------------- Session ---------------------- */
export function createSession(userId) {
  const session = { id: uid("s_"), userId, created: Date.now(), expires: Date.now() + SESSION_DAYS * 86400000 };
  storage.set("session", session);
  return session;
}

export function readSession() {
  const s = storage.get("session", null);
  if (!s || typeof s.userId !== "string" || typeof s.expires !== "number") return null;
  if (s.expires < Date.now()) {
    storage.remove("session");
    return null;
  }
  return s;
}

export function destroySession() {
  storage.remove("session");
}

export function isValidEmail(email) {
  return /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[a-z]{2,}$/i.test(String(email || "")) && String(email).length <= 120;
}
