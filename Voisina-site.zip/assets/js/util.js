/* =====================================================================
   OUTILS GÉNÉRAUX
   ---------------------------------------------------------------------
   Le point le plus important de ce fichier est la fonction `html` :
   toutes les valeurs insérées dans une page passent par elle et sont
   automatiquement "échappées". Un texte comme <script> devient
   &lt;script&gt; et s'affiche au lieu de s'exécuter => protection XSS.
   ===================================================================== */

const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;", "`": "&#96;", "=": "&#61;" };

/** Échappe un texte pour l'insérer sans danger dans du HTML. */
export function esc(value) {
  return String(value ?? "").replace(/[&<>"'`=]/g, (c) => ESCAPES[c]);
}

/** Contenu HTML déjà sûr (généré par `html` ou par nous-mêmes). */
class SafeHTML {
  constructor(value) { this.value = value; }
  toString() { return this.value; }
}

/** Marque une chaîne comme sûre. À n'utiliser QUE pour du HTML écrit par nous (icônes…). */
export const raw = (value) => new SafeHTML(String(value));

function renderValue(value) {
  if (value === null || value === undefined || value === false || value === true) return "";
  if (value instanceof SafeHTML) return value.value;
  if (Array.isArray(value)) return value.map(renderValue).join("");
  return esc(value);
}

/** Gabarit HTML avec échappement automatique : html`<p>${texte}</p>` */
export function html(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i++) out += renderValue(values[i]) + strings[i + 1];
  return new SafeHTML(out);
}

/** Insère un contenu sûr dans un élément. */
export function mount(el, content) {
  if (!el) return;
  el.innerHTML = content instanceof SafeHTML ? content.value : esc(content);
}

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

/* ---------------------------------------------------------------------
   STOCKAGE LOCAL
   Toutes les lectures/écritures sont protégées (try/catch) : en navigation
   privée ou si le stockage est plein, le site continue de fonctionner.
   --------------------------------------------------------------------- */
const PREFIX = "voisina:v2:";
const memoryFallback = new Map();

export const storage = {
  get(key, fallback) {
    try {
      const rawValue = localStorage.getItem(PREFIX + key);
      if (rawValue === null) return memoryFallback.has(key) ? memoryFallback.get(key) : fallback;
      return JSON.parse(rawValue);
    } catch {
      return memoryFallback.has(key) ? memoryFallback.get(key) : fallback;
    }
  },
  /** Retourne true si l'écriture a réussi, false si le stockage est plein. */
  set(key, value) {
    memoryFallback.set(key, value);
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  },
  remove(key) {
    memoryFallback.delete(key);
    try { localStorage.removeItem(PREFIX + key); } catch { /* ignoré */ }
  },
  /** Supprime toutes les données Voisina de ce navigateur. */
  clearAll() {
    memoryFallback.clear();
    try {
      Object.keys(localStorage).filter((k) => k.startsWith(PREFIX)).forEach((k) => localStorage.removeItem(k));
    } catch { /* ignoré */ }
  },
  /** Supprime les données de l'ancienne version (mots de passe en clair !). */
  purgeLegacy() {
    try {
      Object.keys(localStorage)
        .filter((k) => k.startsWith("vc_"))
        .forEach((k) => localStorage.removeItem(k));
    } catch { /* ignoré */ }
  },
};

/** Identifiant aléatoire non devinable (générateur cryptographique). */
export function uid(prefix = "") {
  const bytes = new Uint8Array(9);
  crypto.getRandomValues(bytes);
  return prefix + Array.from(bytes, (b) => b.toString(36).padStart(2, "0")).join("").slice(0, 14);
}

export function debounce(fn, wait = 250) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

export const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

/** Distance en km entre deux points GPS (formule de haversine). */
export function distanceKm(a, b) {
  if (!a || !b) return null;
  const R = 6371;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Générateur pseudo-aléatoire "à graine" : mêmes données sur tous les appareils. */
export function seededRandom(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(text) {
  let h = 2166136261;
  for (const ch of String(text)) {
    h ^= ch.codePointAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Date locale au format AAAA-MM-JJ (sans décalage de fuseau horaire). */
export function dateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function parseDateKey(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? null : d;
}

export function todayKey() {
  return dateKey(new Date());
}

/** Initiales pour les avatars : "Léa Martin" -> "LM" */
export function initials(name) {
  return String(name || "?")
    .trim()
    .split(/\s+/)
    .map((part) => part[0] || "")
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

/** Couleur d'avatar stable dérivée du nom (6 teintes de la charte). */
export function avatarTone(seed) {
  return `tone-${hashString(seed) % 6}`;
}

/** Détection simple de coordonnées ou demandes sensibles (conseil de sécurité). */
export function detectSensitive(text) {
  const value = String(text || "");
  const found = [];
  if (/(\+41|0041|\b0)\s?\d{2}[\s./-]?\d{3}[\s./-]?\d{2}[\s./-]?\d{2}\b/.test(value)) found.push("phone");
  if (/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(value)) found.push("email");
  if (/\bCH\d{2}[\s]?(\d{4}[\s]?){4}\d\b/i.test(value) || /\biban\b/i.test(value)) found.push("iban");
  if (/(mot de passe|passwort|password|code (pin|sms|de confirmation)|pin-code|tan\b|western union|moneygram|carte cadeau|gift ?card|geschenkkarte|crypto|bitcoin)/i.test(value)) found.push("scam");
  return found;
}

export function prefersReducedMotion() {
  return window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
}

/** Lit un fichier image, vérifie son type réel et le ré-encode.
 *  Le ré-encodage supprime les métadonnées EXIF (dont la position GPS
 *  que les smartphones ajoutent aux photos !). */
export async function processImage(file, maxSize = 1200, quality = 0.82) {
  if (!file) throw new Error("no-file");
  if (file.size > 8 * 1024 * 1024) throw new Error("too-large");
  const header = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  const isJpeg = header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff;
  const isPng = header[0] === 0x89 && header[1] === 0x50 && header[2] === 0x4e && header[3] === 0x47;
  const isWebp = header[0] === 0x52 && header[1] === 0x49 && header[2] === 0x46 && header[3] === 0x46 && header[8] === 0x57 && header[9] === 0x45;
  const isGif = header[0] === 0x47 && header[1] === 0x49 && header[2] === 0x46;
  if (!(isJpeg || isPng || isWebp || isGif)) throw new Error("bad-type");

  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("bad-type"));
      image.src = url;
    });
    const ratio = Math.min(1, maxSize / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * ratio));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * ratio));
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", quality);
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** N'accepte que des images que NOUS avons produites (data:image/jpeg;base64). */
export function safeImageSrc(value) {
  return typeof value === "string" && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(value) ? value : "";
}

/** Télécharge un fichier généré dans le navigateur. */
export function downloadFile(filename, content, type = "application/octet-stream") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
