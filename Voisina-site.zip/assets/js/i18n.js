/* =====================================================================
   TRADUCTIONS (français, allemand, italien, anglais)
   Les textes sont dans translations.js. Ici : la logique.
   ===================================================================== */
import { DICT } from "./translations.js";
import { storage } from "./util.js";
import { LANGS, CANTONS, getCategory } from "./data.js";

const LOCALES = { fr: "fr-CH", de: "de-CH", it: "it-CH", en: "en-GB" };

function detectLanguage() {
  const saved = storage.get("prefs", {}).lang;
  if (LANGS.includes(saved)) return saved;
  for (const l of navigator.languages || [navigator.language || "fr"]) {
    const code = String(l).slice(0, 2).toLowerCase();
    if (LANGS.includes(code)) return code;
  }
  return "fr";
}

let current = detectLanguage();
const missing = new Set();

export const getLang = () => current;
export const locale = () => LOCALES[current];

export function setLang(lang) {
  if (!LANGS.includes(lang)) return;
  current = lang;
  const prefs = storage.get("prefs", {});
  storage.set("prefs", { ...prefs, lang });
  document.documentElement.lang = lang;
}

/** Traduit une clé. Les {variables} sont remplacées par les paramètres.
 *  Pluriel : t("x", {count}) cherche "x.one" / "x.other". */
export function t(key, params = {}) {
  let k = key;
  if (typeof params.count === "number") {
    const plural = params.count === 1 ? `${key}.one` : `${key}.other`;
    if (DICT[current]?.[plural] !== undefined || DICT.fr[plural] !== undefined) k = plural;
  }
  let text = DICT[current]?.[k];
  if (text === undefined) {
    text = DICT.fr[k];
    if (!missing.has(`${current}:${k}`)) {
      missing.add(`${current}:${k}`);
      console.warn(`[i18n] clé manquante: ${current}:${k}`);
    }
  }
  if (text === undefined) return key;
  return String(text).replace(/\{(\w+)\}/g, (_, name) => (params[name] ?? `{${name}}`));
}

/** Texte multilingue {fr,de,it,en} ou simple chaîne. */
export function pick(value) {
  if (value && typeof value === "object") return value[current] || value.fr || Object.values(value)[0] || "";
  return value ?? "";
}

export const cantonName = (code) => (CANTONS[code] ? CANTONS[code][current] : code || "");
export const categoryName = (id) => getCategory(id)[current];

export const languageName = (code) => t(`lang.${code}`);

/* ----------------------------- FORMATS ----------------------------- */

export function fmtDate(date, options = { day: "numeric", month: "long", year: "numeric" }) {
  const d = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat(locale(), options).format(d);
}

export function fmtShortDate(date) {
  return fmtDate(date, { weekday: "short", day: "numeric", month: "short" });
}

export function fmtTime(date) {
  return fmtDate(date, { hour: "2-digit", minute: "2-digit" });
}

/** "il y a 3 heures", "hier"… */
export function fmtRelative(date) {
  const d = date instanceof Date ? date : new Date(date);
  const diff = (d.getTime() - Date.now()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(locale(), { numeric: "auto" });
  const abs = Math.abs(diff);
  if (abs < 60) return rtf.format(Math.round(diff), "second");
  if (abs < 3600) return rtf.format(Math.round(diff / 60), "minute");
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), "hour");
  if (abs < 86400 * 30) return rtf.format(Math.round(diff / 86400), "day");
  return fmtDate(d, { day: "numeric", month: "short" });
}

export function fmtNumber(n) {
  return new Intl.NumberFormat(locale()).format(n);
}

/** Montant en francs suisses : "CHF 25.–" (convention suisse). */
export function fmtCHF(amount) {
  const n = Number(amount) || 0;
  return Number.isInteger(n) ? `CHF ${fmtNumber(n)}.–` : `CHF ${n.toFixed(2)}`;
}

export function fmtDuration(minutes) {
  const m = Number(minutes) || 0;
  if (!m) return t("common.flexible");
  if (m >= 480) return t("duration.day");
  if (m >= 240 && m % 60 === 0 && m < 480) return t("duration.half");
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (h && rest) return `${h} h ${rest}`;
  if (h) return `${h} h`;
  return `${rest} min`;
}

export function fmtDistance(km) {
  if (km === null || km === undefined) return "";
  if (km < 1) return "< 1 km";
  return `${km < 10 ? km.toFixed(1) : Math.round(km)} km`;
}
