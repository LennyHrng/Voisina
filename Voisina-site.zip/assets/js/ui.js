/* =====================================================================
   COMPOSANTS D'INTERFACE RÉUTILISABLES
   (cartes d'annonce, avatars, boîtes de dialogue, notifications, etc.)
   ===================================================================== */
import { html, raw, esc, $, mount, initials, avatarTone, debounce, safeImageSrc } from "./util.js";
import { icon } from "./icons.js";
import { t, pick, cantonName, categoryName, fmtCHF, fmtShortDate, fmtDistance, getLang } from "./i18n.js";
import { getCategory, searchLocalities, LOCALITIES, CANTON_CODES } from "./data.js";
import { getPerson, isFavorite, REPORT_REASONS, createReport } from "./store.js";
import { distanceKm } from "./util.js";

/* ------------------------------------------------------------------
   ACTIONS : les boutons portent data-action="nom" au lieu de onclick.
   (Les attributs onclick sont interdits par notre politique de sécurité.)
   ------------------------------------------------------------------ */
export const actions = {};
export function registerActions(map) { Object.assign(actions, map); }

/* ----------------------------- Toasts ----------------------------- */
export function toast(message, kind = "info") {
  const box = $("#toasts");
  if (!box) return;
  const el = document.createElement("div");
  el.className = `toast toast-${kind}`;
  const iconName = kind === "success" ? "checkCircle" : kind === "error" ? "alert" : "info";
  mount(el, html`${icon(iconName)}<span>${message}</span>`);
  box.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 300);
  }, 3600);
}

/* ------------------------ Petits éléments ------------------------- */
export function avatar(person, size = "md") {
  const name = person?.name || person?.firstname || "?";
  const photo = safeImageSrc(person?.photo);
  if (photo) return html`<span class="avatar avatar-${size}"><img src="${photo}" alt=""></span>`;
  return html`<span class="avatar avatar-${size} ${avatarTone(person?.id || name)}" aria-hidden="true">${initials(name)}</span>`;
}

export function priceLabel(l) {
  if (l.payment === "free") return t("pay.free");
  if (l.payment === "negotiable") return t("pay.negotiable");
  const suffix = l.unit === "hour" ? t("unit.perHour") : l.unit === "visit" ? t("unit.perVisit") : "";
  return `${fmtCHF(l.amount)}${suffix}`;
}

export function scheduleLabel(l) {
  if (!l.date) return t("listing.flexibleDate");
  return l.time ? `${fmtShortDate(l.date + "T12:00:00")} · ${l.time}` : fmtShortDate(l.date + "T12:00:00");
}

export const typeLabel = (type) => t(`type.${type}`);

export function categoryThumb(l, cls = "") {
  const cat = getCategory(l.category);
  const photo = safeImageSrc(l.photos?.[0]);
  if (photo) return html`<div class="media ${cls}"><img src="${photo}" alt="" loading="lazy"></div>`;
  return html`<div class="media media-illu tone-${cat.tone} ${cls}"><span class="media-icon">${icon(cat.icon)}</span></div>`;
}

export function listingTitle(l) { return pick(l.title); }
export function listingDescription(l) { return pick(l.description); }

/** Carte d'annonce utilisée partout (accueil, recherche, favoris…). */
export function listingCard(l, { distance = null, origin = null } = {}) {
  const author = getPerson(l.authorId);
  const fav = isFavorite(l.id);
  const d = distance ?? (origin ? distanceKm(origin, l) : null);
  const title = listingTitle(l);
  return html`
  <article class="listing-card${l.status !== "active" ? " is-inactive" : ""}">
    <div class="listing-card-media">
      ${categoryThumb(l)}
      <div class="media-chips">
        <span class="chip chip-type type-${l.type}">${typeLabel(l.type)}</span>
        ${l.urgent ? html`<span class="chip chip-urgent">${icon("zap")}${t("listing.urgent")}</span>` : ""}
      </div>
    </div>
    <button class="fav-btn${fav ? " is-active" : ""}" type="button" data-action="fav" data-id="${l.id}" aria-pressed="${fav ? "true" : "false"}" aria-label="${fav ? t("fav.remove") : t("fav.add")}">${icon("heart")}</button>
    <div class="listing-card-body">
      <div class="listing-card-cat">${icon(getCategory(l.category).icon)}${categoryName(l.category)}</div>
      <h3 class="listing-card-title"><a href="#/annonce/${l.id}" class="stretched">${title}</a></h3>
      <div class="listing-card-meta">
        <span>${icon("pin")}${l.city} · ${l.canton}</span>
        ${d !== null ? html`<span class="distance">${fmtDistance(d)}</span>` : ""}
      </div>
      <div class="listing-card-meta">${icon("calendar")}<span>${scheduleLabel(l)}</span></div>
      <div class="listing-card-foot">
        <span class="mini-author">${avatar(author, "xs")}<span>${author?.name || t("common.formerMember")}</span>${author?.verified ? html`<span class="verified-dot" title="${t("trust.verified")}">${icon("badgeCheck")}</span>` : ""}</span>
        <span class="price${l.payment === "free" ? " is-free" : ""}">${priceLabel(l)}</span>
      </div>
    </div>
  </article>`;
}

export function emptyState({ iconName = "inbox", title, text = "", action = "" }) {
  return html`<div class="empty-state">
    <div class="empty-icon">${icon(iconName)}</div>
    <h3>${title}</h3>
    ${text ? html`<p>${text}</p>` : ""}
    ${action}
  </div>`;
}

export function stars(rating) {
  if (rating === null || rating === undefined) return html`<span class="muted">${t("trust.newMember")}</span>`;
  return html`<span class="stars" aria-label="${t("trust.ratingOutOf", { rating })}">${icon("star")}<strong>${rating.toFixed(1)}</strong></span>`;
}

/* ---------------------------- Dialogues --------------------------- */
let dialogResolve = null;

/** Ouvre la boîte de dialogue. `onSubmit(form)` peut retourner false pour la garder ouverte. */
export function openDialog({ title, body, footer = "", size = "", onSubmit = null, onOpen = null }) {
  const dlg = $("#dialog");
  if (dialogResolve) { dialogResolve(null); dialogResolve = null; }
  dlg.className = `dialog ${size}`;
  mount(dlg, html`
    <form class="dialog-form" method="dialog" novalidate>
      <header class="dialog-head">
        <h2 id="dialog-title">${title}</h2>
        <button class="icon-btn" type="button" data-dialog-close aria-label="${t("common.close")}">${icon("x")}</button>
      </header>
      <div class="dialog-body">${body}</div>
      ${footer ? html`<footer class="dialog-foot">${footer}</footer>` : ""}
    </form>`);
  dlg.setAttribute("aria-labelledby", "dialog-title");
  const form = $("form", dlg);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const result = onSubmit ? await onSubmit(form, e.submitter) : true;
    if (result !== false) closeDialog(result);
  });
  $$dialogClose(dlg);
  dlg.showModal();
  onOpen?.(dlg);
  return new Promise((resolve) => { dialogResolve = resolve; });
}

function $$dialogClose(dlg) {
  dlg.querySelectorAll("[data-dialog-close]").forEach((b) => b.addEventListener("click", () => closeDialog(null)));
}

export function closeDialog(result = null) {
  const dlg = $("#dialog");
  if (dlg.open) dlg.close();
  if (dialogResolve) { dialogResolve(result); dialogResolve = null; }
}

export function initDialog() {
  const dlg = $("#dialog");
  dlg.addEventListener("cancel", () => { if (dialogResolve) { dialogResolve(null); dialogResolve = null; } });
  // Clic sur le fond sombre = fermer
  dlg.addEventListener("click", (e) => { if (e.target === dlg) closeDialog(null); });
}

export async function confirmDialog({ title, text, confirm, danger = false }) {
  const result = await openDialog({
    title,
    size: "dialog-sm",
    body: html`<p class="dialog-text">${text}</p>`,
    footer: html`<button type="button" class="btn btn-ghost" data-dialog-close>${t("common.cancel")}</button>
      <button type="submit" class="btn ${danger ? "btn-danger" : "btn-primary"}">${confirm}</button>`,
    onSubmit: () => true,
  });
  return result === true;
}

export async function reportDialog(targetType, targetId) {
  const done = await openDialog({
    title: t("report.title"),
    body: html`
      <p class="dialog-text">${t("report.intro")}</p>
      <fieldset class="choice-list">
        <legend class="sr-only">${t("report.reason")}</legend>
        ${REPORT_REASONS.map((r, i) => html`<label class="choice"><input type="radio" name="reason" value="${r}" ${i === 0 ? raw("checked") : ""}><span>${t("report.reason." + r)}</span></label>`)}
      </fieldset>
      <label class="field"><span class="field-label">${t("report.details")}</span>
        <textarea name="details" rows="3" maxlength="500" class="input" placeholder="${t("report.detailsPh")}"></textarea></label>
      <p class="help">${icon("info")} ${t("report.emergency")}</p>`,
    footer: html`<button type="button" class="btn btn-ghost" data-dialog-close>${t("common.cancel")}</button>
      <button type="submit" class="btn btn-danger">${icon("flag")}${t("report.send")}</button>`,
    onSubmit: (form) => {
      const data = new FormData(form);
      return createReport({ targetType, targetId, reason: data.get("reason"), details: data.get("details") });
    },
  });
  if (done) toast(t("report.thanks"), "success");
}

export async function shareLink(url, title) {
  if (navigator.share) {
    try { await navigator.share({ title, url }); return; } catch (e) { if (e?.name === "AbortError") return; }
  }
  try {
    await navigator.clipboard.writeText(url);
    toast(t("share.copied"), "success");
  } catch {
    openDialog({ title: t("share.title"), size: "dialog-sm", body: html`<input class="input" readonly value="${url}">` });
  }
}

/* ---------------------- Saisie d'une localité ---------------------- */
/* Suggestions hors ligne (liste intégrée) + recherche officielle de la
   Confédération (geo.admin.ch) pour trouver n'importe quelle commune. */
const remoteCache = new Map();

async function searchRemote(query) {
  const q = query.trim();
  if (q.length < 2) return [];
  if (remoteCache.has(q)) return remoteCache.get(q);
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000);
    const url = `https://api3.geo.admin.ch/rest/services/api/SearchServer?searchText=${encodeURIComponent(q)}&type=locations&origins=zipcode,gg25&limit=8&sr=4326`;
    const res = await fetch(url, { signal: ctrl.signal, referrerPolicy: "strict-origin-when-cross-origin", credentials: "omit" });
    clearTimeout(timer);
    if (!res.ok) return [];
    const json = await res.json();
    const out = [];
    for (const item of json.results || []) {
      const a = item.attrs || {};
      // Le libellé officiel contient du HTML (<b>) : on n'en garde que le texte.
      const text = String(a.label || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
      const lat = Number(a.lat);
      const lng = Number(a.lon);
      if (!text || !Number.isFinite(lat) || !Number.isFinite(lng)) continue;
      let canton = (/\(([A-Z]{2})\)/.exec(text) || [])[1];
      if (!CANTON_CODES.includes(canton)) canton = nearestCanton(lat, lng);
      const npa = (/\b(\d{4})\b/.exec(text) || [])[1] || "";
      const name = text.replace(/\(([A-Z]{2})\)/, "").replace(/\b\d{4}\b/, "").replace(/^[\s-–]+|[\s-–]+$/g, "").trim();
      if (!name || !canton) continue;
      out.push({ name: name.slice(0, 60), npa, canton, lat, lng, remote: true });
    }
    remoteCache.set(q, out);
    return out;
  } catch {
    return [];
  }
}

function nearestCanton(lat, lng) {
  let best = null;
  let bestD = Infinity;
  for (const l of LOCALITIES) {
    const d = (l.lat - lat) ** 2 + (l.lng - lng) ** 2;
    if (d < bestD) { bestD = d; best = l; }
  }
  return best?.canton || null;
}

function renderSuggestions(list, items, activeIndex) {
  if (!items.length) {
    list.hidden = true;
    return;
  }
  mount(list, html`${items.map((it, i) => html`<li role="option" id="${list.id}-opt-${i}" class="suggest-item${i === activeIndex ? " is-active" : ""}" data-index="${i}" aria-selected="${i === activeIndex ? "true" : "false"}">
    ${icon("pin")}<span><strong>${it.name}</strong> <span class="muted">${it.npa ? it.npa + " · " : ""}${cantonName(it.canton)}</span></span></li>`)}`);
  list.hidden = false;
}

/** Active l'autocomplétion sur tous les champs [data-locality] d'un conteneur. */
export function initLocalityFields(root = document) {
  root.querySelectorAll("[data-locality]").forEach((input, n) => {
    if (input.dataset.ready) return;
    input.dataset.ready = "1";
    const wrap = input.closest(".locality-field");
    const list = wrap.querySelector(".suggest");
    list.id = list.id || `suggest-${n}-${Math.random().toString(36).slice(2, 7)}`;
    input.setAttribute("role", "combobox");
    input.setAttribute("aria-autocomplete", "list");
    input.setAttribute("aria-expanded", "false");
    input.setAttribute("aria-controls", list.id);
    input.setAttribute("autocomplete", "off");
    let items = [];
    let active = -1;
    const hidden = (name) => wrap.querySelector(`[data-loc="${name}"]`);

    const choose = (it) => {
      input.value = it.name;
      if (hidden("canton")) hidden("canton").value = it.canton;
      if (hidden("npa")) hidden("npa").value = it.npa || "";
      if (hidden("lat")) hidden("lat").value = it.lat;
      if (hidden("lng")) hidden("lng").value = it.lng;
      list.hidden = true;
      input.setAttribute("aria-expanded", "false");
      input.removeAttribute("aria-activedescendant");
      input.dispatchEvent(new CustomEvent("locality-change", { bubbles: true, detail: it }));
    };

    const update = async () => {
      const q = input.value;
      ["canton", "npa", "lat", "lng"].forEach((k) => { if (hidden(k)) hidden(k).value = ""; });
      items = searchLocalities(q, 6);
      active = -1;
      renderSuggestions(list, items, active);
      input.setAttribute("aria-expanded", String(!list.hidden));
      const remote = await searchRemote(q);
      if (input.value !== q) return;
      const known = new Set(items.map((i) => i.name.toLowerCase() + i.npa));
      items = [...items, ...remote.filter((r) => !known.has(r.name.toLowerCase() + r.npa))].slice(0, 8);
      renderSuggestions(list, items, active);
      input.setAttribute("aria-expanded", String(!list.hidden));
    };
    const debounced = debounce(update, 180);

    input.addEventListener("input", debounced);
    input.addEventListener("focus", () => { if (input.value && !hidden("lat")?.value) update(); });
    input.addEventListener("keydown", (e) => {
      if (list.hidden) return;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        active = (active + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
        renderSuggestions(list, items, active);
        input.setAttribute("aria-activedescendant", `${list.id}-opt-${active}`);
      } else if (e.key === "Enter" && active >= 0) {
        e.preventDefault();
        choose(items[active]);
      } else if (e.key === "Escape") {
        list.hidden = true;
      }
    });
    list.addEventListener("mousedown", (e) => {
      const li = e.target.closest("[data-index]");
      if (li) { e.preventDefault(); choose(items[Number(li.dataset.index)]); }
    });
    input.addEventListener("blur", () => setTimeout(() => {
      list.hidden = true;
      input.setAttribute("aria-expanded", "false");
      // Si la personne a tapé un nom exact sans cliquer, on le reconnaît.
      if (!hidden("lat")?.value) {
        const exact = searchLocalities(input.value, 1)[0];
        if (exact && exact.name.toLowerCase() === input.value.trim().toLowerCase()) choose(exact);
      }
    }, 120));
  });
}

/** Champ de localité (à placer dans un formulaire). */
export function localityField({ name = "city", label, value = "", canton = "", npa = "", lat = "", lng = "", required = false, placeholder = "", error = "" }) {
  return html`<div class="field locality-field">
    ${label ? html`<label class="field-label" for="f-${name}">${label}${required ? html` <span class="req" aria-hidden="true">*</span>` : ""}</label>` : ""}
    <div class="input-icon">${icon("pin")}<input id="f-${name}" class="input" name="${name}" data-locality value="${value}" placeholder="${placeholder || t("loc.placeholder")}" ${required ? raw("required") : ""} maxlength="60"></div>
    <input type="hidden" name="canton" data-loc="canton" value="${canton}">
    <input type="hidden" name="npa" data-loc="npa" value="${npa}">
    <input type="hidden" name="lat" data-loc="lat" value="${lat}">
    <input type="hidden" name="lng" data-loc="lng" value="${lng}">
    <ul class="suggest" role="listbox" hidden></ul>
    ${error ? html`<p class="field-error">${error}</p>` : ""}
  </div>`;
}

export function langChips(name, selected = []) {
  return html`<div class="chip-choices">${["fr", "de", "it", "en"].map((l) => html`<label class="chip-choice"><input type="checkbox" name="${name}" value="${l}" ${selected.includes(l) ? raw("checked") : ""}><span>${t("lang." + l)}</span></label>`)}</div>`;
}

export { esc, getLang };
