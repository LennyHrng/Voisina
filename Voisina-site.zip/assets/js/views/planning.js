/* Mon planning : favoris + calendrier + export agenda */
import { html, raw, $, mount, dateKey, parseDateKey } from "../util.js";
import { icon } from "../icons.js";
import { t, locale, fmtDate, fmtDuration } from "../i18n.js";
import { getCategory } from "../data.js";
import { getFavorites, getListing, clearFavorites, currentUser } from "../store.js";
import { listingCard, emptyState, confirmDialog, toast, listingTitle } from "../ui.js";
import { downloadIcs } from "../ics.js";

let cursor = null; // premier jour du mois affiché
let selectedDay = null;

function favListings() {
  return getFavorites().map(getListing).filter((l) => l && l.status !== "hidden");
}

/** Occurrences d'une annonce dans un mois (gère les récurrences). */
function occurrences(l, year, month) {
  if (!l.date) return [];
  const start = parseDateKey(l.date);
  if (!start) return [];
  const out = [];
  const last = new Date(year, month + 1, 0);
  if (l.recurrence === "weekly") {
    for (let d = new Date(start), n = 0; d <= last && n < 8; d.setDate(d.getDate() + 7), n++) {
      if (d.getMonth() === month && d.getFullYear() === year) out.push(dateKey(d));
    }
  } else if (l.recurrence === "monthly") {
    for (let d = new Date(start), n = 0; d <= last && n < 6; d.setMonth(d.getMonth() + 1), n++) {
      if (d.getMonth() === month && d.getFullYear() === year) out.push(dateKey(d));
    }
  } else if (start.getMonth() === month && start.getFullYear() === year) out.push(l.date);
  return out;
}

function calendar() {
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const favs = favListings();
  const byDay = {};
  favs.forEach((l) => occurrences(l, year, month).forEach((k) => (byDay[k] ||= []).push(l)));
  Object.values(byDay).forEach((list) => list.sort((a, b) => (a.time || "").localeCompare(b.time || "")));

  const first = new Date(year, month, 1);
  const offset = (first.getDay() + 6) % 7; // lundi en premier (usage suisse)
  const today = dateKey(new Date());
  const weekdays = Array.from({ length: 7 }, (_, i) => new Intl.DateTimeFormat(locale(), { weekday: "short" }).format(new Date(2024, 0, 1 + i)));
  const cells = [];
  for (let i = 0; i < 42; i++) {
    const d = new Date(year, month, 1 - offset + i);
    const key = dateKey(d);
    const events = byDay[key] || [];
    const other = d.getMonth() !== month;
    if (i >= 35 && other && d.getDate() < 8 && i % 7 === 0) break; // évite une 6e ligne vide
    cells.push(html`<button type="button" class="cal-day${other ? " is-other" : ""}${key === today ? " is-today" : ""}${key === selectedDay ? " is-selected" : ""}${events.length ? " has-events" : ""}" data-action="cal-day" data-day="${key}" aria-label="${fmtDate(d, { weekday: "long", day: "numeric", month: "long" })}${events.length ? ` — ${t("planning.eventsCount", { count: events.length })}` : ""}">
      <span class="cal-num">${d.getDate()}</span>
      <span class="cal-events">${events.slice(0, 3).map((l) => html`<span class="cal-event tone-${getCategory(l.category).tone}"><span class="cal-event-time">${l.time || ""}</span> ${listingTitle(l)}</span>`)}
      ${events.length > 3 ? html`<span class="cal-more">+${events.length - 3}</span>` : ""}</span>
      ${events.length ? html`<span class="cal-dots" aria-hidden="true">${events.slice(0, 4).map((l) => html`<i class="tone-${getCategory(l.category).tone}"></i>`)}</span>` : ""}
    </button>`);
  }

  const monthEvents = [];
  favs.forEach((l) => occurrences(l, year, month).forEach((k) => monthEvents.push({ key: k, l })));
  monthEvents.sort((a, b) => (a.key + (a.l.time || "")).localeCompare(b.key + (b.l.time || "")));
  const shown = selectedDay ? monthEvents.filter((e) => e.key === selectedDay) : monthEvents;

  return html`
  <div class="cal-head">
    <h2 class="h3 cal-title">${fmtDate(first, { month: "long", year: "numeric" })}</h2>
    <div class="cal-nav">
      <button type="button" class="icon-btn" data-action="cal-move" data-delta="-1" aria-label="${t("planning.prevMonth")}">${icon("chevronLeft")}</button>
      <button type="button" class="btn btn-ghost btn-sm" data-action="cal-today">${t("planning.today")}</button>
      <button type="button" class="icon-btn" data-action="cal-move" data-delta="1" aria-label="${t("planning.nextMonth")}">${icon("chevronRight")}</button>
    </div>
  </div>
  <div class="cal-grid" role="grid">
    ${weekdays.map((w) => html`<div class="cal-weekday" role="columnheader">${w}</div>`)}
    ${cells}
  </div>
  <div class="agenda">
    <h3 class="h4">${selectedDay ? fmtDate(selectedDay + "T12:00:00", { weekday: "long", day: "numeric", month: "long" }) : t("planning.thisMonth")}
      ${selectedDay ? html`<button type="button" class="link-btn" data-action="cal-day" data-day="${selectedDay}">${t("planning.showMonth")}</button>` : ""}</h3>
    ${shown.length
      ? html`<ul class="agenda-list">${shown.map(({ key, l }) => html`<li class="agenda-item">
          <span class="agenda-date"><strong>${fmtDate(key + "T12:00:00", { day: "numeric" })}</strong><span>${fmtDate(key + "T12:00:00", { month: "short" })}</span></span>
          <span class="agenda-body"><a href="#/annonce/${l.id}">${listingTitle(l)}</a><span class="muted small">${l.time ? l.time + " · " : ""}${fmtDuration(l.duration)} · ${l.city}</span></span>
          <button type="button" class="icon-btn" data-action="ics" data-id="${l.id}" aria-label="${t("listing.addToCalendar")}" title="${t("listing.addToCalendar")}">${icon("download")}</button>
        </li>`)}</ul>`
      : html`<p class="muted">${t("planning.noEvents")}</p>`}
  </div>`;
}

export default {
  title: () => t("meta.planningTitle"),
  refreshOn: ["auth", "listings"],

  render() {
    if (!cursor) { cursor = new Date(); cursor.setDate(1); }
    const favs = favListings();
    const dated = favs.filter((l) => l.date);
    const me = currentUser();
    return html`
    <section class="page-head">
      <div class="container page-head-row">
        <div>
          <span class="kicker">${t("planning.kicker")}</span>
          <h1 class="h1">${t("planning.title")}</h1>
          <p class="lead">${t("planning.lead")}</p>
        </div>
        <div class="page-head-actions">
          <button type="button" class="btn btn-primary" data-action="ics-all" ${dated.length ? "" : raw("disabled")}>${icon("download")}${t("planning.exportAll")}</button>
        </div>
      </div>
    </section>
    <div class="container planning-layout">
      <section class="card cal-card" aria-label="${t("planning.calendar")}" id="calendar">${calendar()}</section>
      <section class="fav-section" aria-labelledby="fav-title">
        <div class="section-head section-head-sm">
          <h2 class="h3" id="fav-title">${icon("heart")}${t("planning.favorites")} <span class="count-pill">${favs.length}</span></h2>
          ${favs.length ? html`<button type="button" class="link-btn" data-action="clear-favs">${t("planning.clearFavs")}</button>` : ""}
        </div>
        ${!me && favs.length ? html`<p class="notice">${icon("info")}<span>${t("planning.guestNotice")}</span> <a href="#/connexion?next=${encodeURIComponent("#/planning")}">${t("auth.login")}</a></p>` : ""}
        ${favs.length
          ? html`<div class="listing-grid listing-grid-compact" id="fav-grid">${favs.map((l) => listingCard(l))}</div>`
          : emptyState({ iconName: "heart", title: t("planning.emptyTitle"), text: t("planning.emptyText"), action: html`<a class="btn btn-primary" href="#/explorer">${t("planning.explore")}</a>` })}
      </section>
    </div>`;
  },

  onData(kind) {
    if (kind === "favorites") {
      const view = document.getElementById("view");
      const y = window.scrollY;
      mount(view, this.render());
      window.scrollTo(0, y);
    }
  },
};

export const planningActions = {
  "cal-move": (el) => {
    cursor.setMonth(cursor.getMonth() + Number(el.dataset.delta));
    selectedDay = null;
    mount($("#calendar"), calendar());
  },
  "cal-today": () => {
    cursor = new Date();
    cursor.setDate(1);
    selectedDay = dateKey(new Date());
    mount($("#calendar"), calendar());
  },
  "cal-day": (el) => {
    selectedDay = selectedDay === el.dataset.day ? null : el.dataset.day;
    const d = parseDateKey(el.dataset.day);
    if (d && (d.getMonth() !== cursor.getMonth() || d.getFullYear() !== cursor.getFullYear())) cursor = new Date(d.getFullYear(), d.getMonth(), 1);
    mount($("#calendar"), calendar());
  },
  "ics-all": () => {
    const list = favListings().filter((l) => l.date);
    if (!list.length) return;
    downloadIcs(list, "voisina-planning.ics");
    toast(t("calendar.icsDone"), "success");
  },
  "clear-favs": async () => {
    if (!(await confirmDialog({ title: t("planning.clearTitle"), text: t("planning.clearText"), confirm: t("planning.clearFavs"), danger: true }))) return;
    clearFavorites();
    toast(t("planning.cleared"), "success");
  },
};
