/* Page "Publier / modifier une annonce" */
import { html, raw, $, $$, mount, storage, processImage, detectSensitive, todayKey, debounce } from "../util.js";
import { icon } from "../icons.js";
import { t, getLang, categoryName } from "../i18n.js";
import { CATEGORIES, TYPES, PAYMENTS, UNITS, DURATIONS, RECURRENCES, getCategory } from "../data.js";
import { currentUser, createListing, updateListing, getListing, isAdmin, validateListing } from "../store.js";
import { listingCard, localityField, initLocalityFields, langChips, toast, emptyState, confirmDialog } from "../ui.js";

let photos = [];
let editId = null;

const TYPE_ICONS = { offer: "hand", request: "help", donation: "gift" };
const PAY_ICONS = { free: "heart", paid: "coins", negotiable: "message" };

function readForm(form) {
  const fd = new FormData(form);
  return {
    type: fd.get("type"),
    title: fd.get("title"),
    category: fd.get("category"),
    description: fd.get("description"),
    city: fd.get("city"),
    canton: fd.get("canton"),
    npa: fd.get("npa"),
    lat: fd.get("lat") || undefined,
    lng: fd.get("lng") || undefined,
    date: fd.get("date"),
    time: fd.get("time"),
    duration: fd.get("duration"),
    recurrence: fd.get("recurrence"),
    urgent: fd.get("urgent") === "1",
    payment: fd.get("payment"),
    amount: fd.get("amount"),
    unit: fd.get("unit"),
    languages: fd.getAll("languages"),
    photos,
    lang: getLang(),
  };
}

function previewListing(data) {
  const cat = CATEGORIES.some((c) => c.id === data.category) ? data.category : "other";
  return {
    id: "preview",
    authorId: currentUser()?.id,
    type: TYPES.includes(data.type) ? data.type : "offer",
    category: cat,
    title: data.title?.trim() || t("publish.previewTitle"),
    description: data.description || "",
    payment: data.payment || "free",
    amount: Number(data.amount) || 0,
    unit: data.unit || "total",
    date: data.date || null,
    time: data.time || null,
    city: data.city || t("publish.previewCity"),
    canton: data.canton || "—",
    urgent: data.urgent,
    photos,
    status: "active",
  };
}

function field(name, label, control, { required = false, hint = "", counter = 0 } = {}) {
  return html`<div class="field" data-field="${name}">
    <label class="field-label" for="f-${name}">${label}${required ? html` <span class="req" aria-hidden="true">*</span>` : ""}</label>
    ${control}
    <div class="field-foot">${hint ? html`<p class="help">${hint}</p>` : html`<span></span>`}${counter ? html`<span class="counter" data-counter="${name}">0 / ${counter}</span>` : ""}</div>
    <p class="field-error" id="err-${name}" hidden></p>
  </div>`;
}

function photoList() {
  return html`${photos.map((p, i) => html`<div class="photo-item"><img src="${p}" alt="${t("listing.photoN", { n: i + 1 })}"><button type="button" class="icon-btn icon-btn-sm" data-action="remove-photo" data-index="${i}" aria-label="${t("publish.removePhoto")}">${icon("x")}</button></div>`)}
  ${photos.length < 3 ? html`<label class="photo-add">${icon("camera")}<span>${t("publish.addPhoto")}</span><input type="file" accept="image/jpeg,image/png,image/webp" multiple data-photo-input class="sr-only"></label>` : ""}`;
}

export default {
  title: (ctx) => (ctx.query.get("edit") ? t("publish.editTitle") : t("publish.title")),
  refreshOn: ["auth"],

  render(ctx) {
    const me = currentUser();
    editId = ctx.query.get("edit");
    if (!me) {
      return html`<section class="section"><div class="container narrow">
        ${emptyState({
          iconName: "pencil",
          title: t("publish.gateTitle"),
          text: t("publish.gateText"),
          action: html`<div class="empty-actions"><a class="btn btn-primary" href="#/connexion?mode=register&next=${encodeURIComponent("#/publier")}">${t("auth.createAccount")}</a><a class="btn btn-ghost" href="#/connexion?next=${encodeURIComponent("#/publier")}">${t("auth.login")}</a></div>`,
        })}
      </div></section>`;
    }

    let v = {};
    if (editId) {
      const l = getListing(editId);
      if (!l || l.demo || (l.authorId !== me.id && !isAdmin())) {
        return html`<section class="section"><div class="container narrow">${emptyState({ iconName: "lock", title: t("publish.cannotEdit"), action: html`<a class="btn btn-primary" href="#/compte?tab=listings">${t("account.myListings")}</a>` })}</div></section>`;
      }
      v = { ...l };
      photos = [...(l.photos || [])];
    } else {
      v = storage.get("draft", {}) || {};
      photos = Array.isArray(v.photos) ? v.photos.slice(0, 3) : [];
    }
    const hasDraft = !editId && (v.title || v.description);
    const type = TYPES.includes(v.type) ? v.type : "offer";
    const payment = PAYMENTS.includes(v.payment) ? v.payment : "free";

    return html`
    <section class="page-head">
      <div class="container">
        <span class="kicker">${editId ? t("publish.editKicker") : t("publish.kicker")}</span>
        <h1 class="h1">${editId ? t("publish.editTitle") : t("publish.title")}</h1>
        <p class="lead">${t("publish.lead")}</p>
      </div>
    </section>

    <div class="container publish-layout">
      <form class="publish-form" id="publish-form" novalidate>
        ${hasDraft ? html`<div class="notice">${icon("info")}<span>${t("publish.draftRestored")}</span><button type="button" class="link-btn" data-action="clear-draft">${t("publish.clearDraft")}</button></div>` : ""}
        <p class="field-error form-error" id="err-form" hidden></p>

        <fieldset class="form-section">
          <legend><span class="step-badge">1</span>${t("publish.sType")}</legend>
          <div class="radio-cards">
            ${TYPES.map((ty) => html`<label class="radio-card"><input type="radio" name="type" value="${ty}" ${ty === type ? raw("checked") : ""}>
              <span class="radio-card-inner">${icon(TYPE_ICONS[ty])}<strong>${t("type." + ty)}</strong><small>${t("publish.type." + ty)}</small></span></label>`)}
          </div>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">2</span>${t("publish.sDetails")}</legend>
          ${field("title", t("publish.fTitle"), html`<input id="f-title" class="input" name="title" maxlength="90" required value="${typeof v.title === "string" ? v.title : ""}" placeholder="${t("publish.fTitlePh")}">`, { required: true, counter: 90 })}
          ${field("category", t("publish.fCategory"), html`<select id="f-category" class="select" name="category" required>
            <option value="">${t("publish.chooseCategory")}</option>
            ${CATEGORIES.map((c) => html`<option value="${c.id}" ${v.category === c.id ? raw("selected") : ""}>${categoryName(c.id)}</option>`)}
          </select>`, { required: true })}
          ${field("description", t("publish.fDescription"), html`<textarea id="f-description" class="input textarea" name="description" rows="6" maxlength="1500" required placeholder="${t("publish.fDescriptionPh")}">${typeof v.description === "string" ? v.description : ""}</textarea>`, { required: true, counter: 1500, hint: t("publish.fDescriptionHint") })}
          <div id="sensitive-warning" class="notice notice-warn" hidden></div>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">3</span>${t("publish.sWhere")}</legend>
          ${localityField({ name: "city", label: t("publish.fCity"), value: v.city || me.city || "", canton: v.canton || me.canton || "", npa: v.npa || "", required: true })}
          <p class="field-error" id="err-city" hidden></p>
          <p class="help">${icon("shield")}${t("publish.privacyHint")}</p>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">4</span>${t("publish.sWhen")}</legend>
          <div class="grid-2">
            ${field("date", t("publish.fDate"), html`<input id="f-date" class="input" type="date" name="date" min="${todayKey()}" value="${v.date || ""}">`, { hint: t("publish.fDateHint") })}
            ${field("time", t("publish.fTime"), html`<input id="f-time" class="input" type="time" name="time" value="${v.time || ""}">`)}
            ${field("duration", t("publish.fDuration"), html`<select id="f-duration" class="select" name="duration">
              <option value="">${t("common.flexible")}</option>
              ${DURATIONS.map((d) => html`<option value="${d}" ${Number(v.duration) === d ? raw("selected") : ""}>${t("duration." + d)}</option>`)}
            </select>`)}
            ${field("recurrence", t("publish.fRecurrence"), html`<select id="f-recurrence" class="select" name="recurrence">
              ${RECURRENCES.map((r) => html`<option value="${r}" ${v.recurrence === r ? raw("selected") : ""}>${t("recurrence." + r)}</option>`)}
            </select>`)}
          </div>
          <label class="check"><input type="checkbox" name="urgent" value="1" ${v.urgent ? raw("checked") : ""}><span>${icon("zap")}${t("publish.fUrgent")}</span></label>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">5</span>${t("publish.sPayment")}</legend>
          <div class="radio-cards">
            ${PAYMENTS.map((p) => html`<label class="radio-card"><input type="radio" name="payment" value="${p}" ${p === payment ? raw("checked") : ""}>
              <span class="radio-card-inner">${icon(PAY_ICONS[p])}<strong>${t("pay." + p)}</strong><small>${t("publish.pay." + p)}</small></span></label>`)}
          </div>
          <div class="grid-2 pay-fields" id="pay-fields" ${payment !== "paid" ? raw("hidden") : ""}>
            ${field("amount", t("publish.fAmount"), html`<div class="input-affix"><span>CHF</span><input id="f-amount" class="input" type="number" name="amount" min="1" max="5000" step="0.5" inputmode="decimal" value="${v.amount || ""}"></div>`)}
            ${field("unit", t("publish.fUnit"), html`<select id="f-unit" class="select" name="unit">${UNITS.map((u) => html`<option value="${u}" ${v.unit === u ? raw("selected") : ""}>${t("unit." + u)}</option>`)}</select>`)}
          </div>
          <p class="help">${icon("info")}${t("publish.payHint")}</p>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">6</span>${t("publish.sExtras")}</legend>
          <div class="field">
            <span class="field-label">${t("publish.fPhotos")}</span>
            <div class="photo-grid" id="photo-grid">${photoList()}</div>
            <p class="help">${icon("shield")}${t("publish.photoHint")}</p>
          </div>
          <div class="field">
            <span class="field-label">${t("publish.fLanguages")}</span>
            ${langChips("languages", v.languages || me.languages || [getLang()])}
          </div>
        </fieldset>

        <fieldset class="form-section">
          <legend><span class="step-badge">7</span>${t("publish.sConfirm")}</legend>
          <label class="check"><input type="checkbox" name="rules" value="1" required ${editId ? raw("checked") : ""}><span>${t("publish.cRules")} <a href="#/page/regles" target="_blank" rel="noopener">${t("publish.cRulesLink")}</a></span></label>
          <label class="check"><input type="checkbox" name="honest" value="1" required ${editId ? raw("checked") : ""}><span>${t("publish.cHonest")}</span></label>
          <p class="field-error" id="err-confirm" hidden></p>
        </fieldset>

        <div class="form-actions">
          <a class="btn btn-ghost" href="${editId ? `#/annonce/${editId}` : "#/"}">${t("common.cancel")}</a>
          <button type="submit" class="btn btn-primary btn-lg">${icon(editId ? "check" : "send")}${editId ? t("publish.save") : t("publish.submit")}</button>
        </div>
      </form>

      <aside class="publish-preview" aria-label="${t("publish.preview")}">
        <div class="preview-sticky">
          <p class="kicker">${icon("eye")}${t("publish.preview")}</p>
          <div id="preview-card"></div>
          <div class="tips-card">
            <h2 class="h4">${icon("sparkles")}${t("publish.tipsTitle")}</h2>
            <ul><li>${t("publish.tip1")}</li><li>${t("publish.tip2")}</li><li>${t("publish.tip3")}</li></ul>
          </div>
        </div>
      </aside>
    </div>`;
  },

  mount(root) {
    const form = $("#publish-form", root);
    if (!form) return;
    initLocalityFields(root);

    const updatePreview = () => {
      if (!form.isConnected) return; // la page a changé entre-temps
      const data = readForm(form);
      mount($("#preview-card"), listingCard(previewListing(data)));
      $("#pay-fields").hidden = data.payment !== "paid";
      $$("[data-counter]", form).forEach((c) => {
        const input = form.elements[c.dataset.counter];
        const max = input.maxLength;
        c.textContent = `${input.value.length} / ${max}`;
        c.classList.toggle("is-near", input.value.length > max * 0.9);
      });
      const found = detectSensitive(`${data.title} ${data.description}`);
      const warn = $("#sensitive-warning");
      if (found.length) {
        mount(warn, html`${icon("alert")}<span>${t("safety.sensitive." + (found.includes("scam") ? "scam" : found.includes("iban") ? "iban" : "contact"))}</span>`);
        warn.hidden = false;
      } else warn.hidden = true;
      if (!editId) storage.set("draft", { ...data, photos: photos.slice(0, 3) });
    };
    const debounced = debounce(updatePreview, 120);
    form.addEventListener("input", debounced);
    form.addEventListener("change", debounced);
    form.addEventListener("locality-change", debounced);
    updatePreview();

    // Photos : vérification du format réel + suppression des métadonnées (GPS)
    form.addEventListener("change", async (e) => {
      if (!e.target.matches("[data-photo-input]")) return;
      const files = [...e.target.files].slice(0, 3 - photos.length);
      for (const file of files) {
        try {
          photos.push(await processImage(file, 1100, 0.8));
        } catch (err) {
          toast(t(err.message === "too-large" ? "publish.photoTooLarge" : "publish.photoBadType"), "error");
        }
      }
      mount($("#photo-grid"), photoList());
      updatePreview();
    });
    root.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-action='remove-photo']");
      if (!btn) return;
      photos.splice(Number(btn.dataset.index), 1);
      mount($("#photo-grid"), photoList());
      updatePreview();
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      $$(".field-error", form).forEach((el) => { el.hidden = true; });
      $$("[aria-invalid]", form).forEach((el) => el.removeAttribute("aria-invalid"));
      const errors = {};
      if (!form.elements.rules.checked || !form.elements.honest.checked) errors.confirm = "confirm";
      const data = readForm(form);
      let result = { ok: false, errors: {} };
      if (!Object.keys(errors).length) {
        result = editId ? updateListing(editId, data) : createListing(data);
      } else {
        // Valide quand même le reste pour tout afficher d'un coup
        result = { ok: false, errors: { ...errors, ...(createListingDry(data)) } };
      }
      if (result.ok) {
        if (!editId) storage.remove("draft");
        photos = [];
        toast(editId ? t("publish.saved") : t("publish.published"), "success");
        location.hash = `#/annonce/${result.listing.id}`;
        return;
      }
      showErrors(form, result.errors);
    });
  },

  unmount() { editId = null; },
};

function createListingDry(data) {
  return validateListing(data).errors || {};
}

function showErrors(form, errors) {
  let first = null;
  for (const [key, code] of Object.entries(errors || {})) {
    const el = $(`#err-${key}`);
    if (el) {
      el.textContent = t(`err.${code}`);
      el.hidden = false;
    }
    const input = form.elements[key];
    if (input && input.setAttribute) {
      input.setAttribute("aria-invalid", "true");
      if (el) input.setAttribute("aria-describedby", el.id);
    }
    if (!first) first = (input && input.focus ? input : null) || el;
  }
  if (first) {
    first.scrollIntoView?.({ behavior: "smooth", block: "center" });
    first.focus?.({ preventScroll: true });
  }
  toast(t("err.formHasErrors"), "error");
}

export const publishActions = {
  "clear-draft": async () => {
    storage.remove("draft");
    photos = [];
    location.hash = "#/publier?new=" + Date.now();
  },
};

export { getCategory, confirmDialog };
