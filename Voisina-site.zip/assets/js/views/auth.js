/* Connexion / inscription */
import { html, raw, $, $$, mount } from "../util.js";
import { icon, logo } from "../icons.js";
import { t } from "../i18n.js";
import { login, register, currentUser, mergeGuestFavorites } from "../store.js";
import { passwordStrength } from "../auth.js";
import { localityField, initLocalityFields, toast } from "../ui.js";

let mode = "login";
let next = "#/compte";

/** N'autorise que des redirections internes (évite les redirections malveillantes). */
function safeNext(value) {
  return /^#\/[\w\-/?=&%.]*$/.test(value || "") ? value : "#/compte";
}

function pwField(name, label, autocomplete, withMeter = false) {
  return html`<div class="field">
    <label class="field-label" for="f-${name}">${label}</label>
    <div class="input-icon input-password">${icon("lock")}
      <input id="f-${name}" class="input" type="password" name="${name}" autocomplete="${autocomplete}" required maxlength="128">
      <button type="button" class="icon-btn icon-btn-sm pw-toggle" data-action="toggle-pw" data-target="f-${name}" aria-label="${t("auth.showPassword")}" aria-pressed="false">${icon("eye")}</button>
    </div>
    ${withMeter ? html`<div class="pw-meter" aria-hidden="true"><span></span><span></span><span></span><span></span></div><p class="help" id="pw-help">${t("auth.pwRules")}</p>` : ""}
    <p class="field-error" id="err-${name}" hidden></p>
  </div>`;
}

function loginForm() {
  return html`<form id="login-form" class="auth-form" novalidate>
    <div class="field">
      <label class="field-label" for="f-identifier">${t("auth.email")}</label>
      <div class="input-icon">${icon("mail")}<input id="f-identifier" class="input" name="identifier" type="text" autocomplete="username" required maxlength="120" inputmode="email"></div>
    </div>
    ${pwField("password", t("auth.password"), "current-password")}
    <p class="field-error form-error" id="err-login" role="alert" hidden></p>
    <button type="submit" class="btn btn-primary btn-lg btn-block">${t("auth.login")}</button>
    <p class="auth-switch">${t("auth.noAccount")} <button type="button" class="link-btn" data-action="auth-mode" data-mode="register">${t("auth.createAccount")}</button></p>
    <details class="demo-hint"><summary>${icon("info")}${t("auth.demoTitle")}</summary><p>${t("auth.demoText")}</p></details>
  </form>`;
}

function registerForm() {
  return html`<form id="register-form" class="auth-form" novalidate>
    <div class="grid-2">
      <div class="field"><label class="field-label" for="f-firstname">${t("auth.firstname")}</label><input id="f-firstname" class="input" name="firstname" autocomplete="given-name" required maxlength="40"><p class="field-error" id="err-firstname" hidden></p></div>
      <div class="field"><label class="field-label" for="f-lastname">${t("auth.lastname")}</label><input id="f-lastname" class="input" name="lastname" autocomplete="family-name" required maxlength="40"><p class="field-error" id="err-lastname" hidden></p></div>
    </div>
    <p class="help">${icon("eyeOff")}${t("auth.nameHint")}</p>
    <div class="field">
      <label class="field-label" for="f-email">${t("auth.email")}</label>
      <div class="input-icon">${icon("mail")}<input id="f-email" class="input" name="email" type="email" autocomplete="email" required maxlength="120"></div>
      <p class="field-error" id="err-email" hidden></p>
    </div>
    ${pwField("password", t("auth.password"), "new-password", true)}
    ${pwField("passwordConfirm", t("auth.passwordConfirm"), "new-password")}
    ${localityField({ name: "city", label: t("auth.city"), required: true })}
    <p class="field-error" id="err-city" hidden></p>
    <label class="check"><input type="checkbox" name="terms" value="1" required><span>${raw(t("auth.terms", { terms: `<a href="#/page/conditions" target="_blank" rel="noopener">${t("footer.terms")}</a>`, privacy: `<a href="#/page/confidentialite" target="_blank" rel="noopener">${t("footer.privacy")}</a>` }))}</span></label>
    <p class="field-error" id="err-terms" hidden></p>
    <p class="field-error form-error" id="err-form" role="alert" hidden></p>
    <button type="submit" class="btn btn-primary btn-lg btn-block">${t("auth.createAccount")}</button>
    <p class="auth-switch">${t("auth.haveAccount")} <button type="button" class="link-btn" data-action="auth-mode" data-mode="login">${t("auth.login")}</button></p>
  </form>`;
}

function setBusy(form, busy) {
  const btn = form.querySelector("button[type=submit]");
  btn.disabled = busy;
  btn.classList.toggle("is-loading", busy);
}

export default {
  title: () => (mode === "register" ? t("auth.createAccount") : t("auth.login")),
  refreshOn: [],

  render(ctx) {
    mode = ctx.query.get("mode") === "register" ? "register" : "login";
    next = safeNext(ctx.query.get("next"));
    if (currentUser()) {
      setTimeout(() => { location.hash = next; }, 0);
      return html``;
    }
    return html`
    <section class="auth-page">
      <div class="container auth-grid">
        <div class="auth-card card">
          <div class="auth-brand">${logo()}<span>Voisina</span></div>
          <div class="tabs" role="tablist">
            <button type="button" role="tab" class="tab${mode === "login" ? " is-active" : ""}" aria-selected="${mode === "login" ? "true" : "false"}" data-action="auth-mode" data-mode="login">${t("auth.login")}</button>
            <button type="button" role="tab" class="tab${mode === "register" ? " is-active" : ""}" aria-selected="${mode === "register" ? "true" : "false"}" data-action="auth-mode" data-mode="register">${t("auth.createAccount")}</button>
          </div>
          <h1 class="h2 auth-title">${mode === "login" ? t("auth.welcomeBack") : t("auth.joinTitle")}</h1>
          <p class="muted auth-sub">${mode === "login" ? t("auth.loginSub") : t("auth.joinSub")}</p>
          <div id="auth-form-wrap">${mode === "login" ? loginForm() : registerForm()}</div>
        </div>
        <aside class="auth-aside">
          <h2 class="h3">${t("auth.whyTitle")}</h2>
          <ul class="check-list">
            <li>${icon("checkCircle")}<span>${t("auth.why1")}</span></li>
            <li>${icon("checkCircle")}<span>${t("auth.why2")}</span></li>
            <li>${icon("checkCircle")}<span>${t("auth.why3")}</span></li>
            <li>${icon("checkCircle")}<span>${t("auth.why4")}</span></li>
          </ul>
          <div class="auth-security">${icon("lock")}<p>${t("auth.securityNote")}</p></div>
        </aside>
      </div>
    </section>`;
  },

  mount(root) {
    initLocalityFields(root);
    const loginEl = $("#login-form", root);
    const registerEl = $("#register-form", root);

    loginEl?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const err = $("#err-login");
      err.hidden = true;
      const id = loginEl.identifier.value.trim();
      const pw = loginEl.password.value;
      if (!id || !pw) { err.textContent = t("err.fillAll"); err.hidden = false; return; }
      setBusy(loginEl, true);
      const res = await login(id, pw);
      setBusy(loginEl, false);
      if (!res.ok) {
        err.textContent = res.error === "locked" ? t("auth.locked", { seconds: res.remaining }) : t("auth.invalid");
        err.hidden = false;
        loginEl.password.value = "";
        loginEl.password.focus();
        return;
      }
      mergeGuestFavorites();
      toast(t("auth.loggedIn", { name: currentUser().firstname }), "success");
      location.hash = next;
    });

    if (registerEl) {
      const pw = registerEl.password;
      const meter = $(".pw-meter", registerEl);
      pw.addEventListener("input", () => {
        const s = passwordStrength(pw.value, [registerEl.firstname.value, registerEl.lastname.value, registerEl.email.value.split("@")[0]]);
        meter.dataset.score = pw.value ? String(Math.max(1, s.score)) : "0";
        $("#pw-help").textContent = !pw.value ? t("auth.pwRules") : s.ok ? t("auth.pwGood") : t("auth.pwIssue." + s.issues[0]);
      });
      registerEl.addEventListener("submit", async (e) => {
        e.preventDefault();
        $$(".field-error", registerEl).forEach((el) => { el.hidden = true; });
        const fd = new FormData(registerEl);
        setBusy(registerEl, true);
        const res = await register({
          firstname: fd.get("firstname"),
          lastname: fd.get("lastname"),
          email: fd.get("email"),
          password: fd.get("password"),
          passwordConfirm: fd.get("passwordConfirm"),
          city: fd.get("city"),
          canton: fd.get("canton"),
          terms: fd.get("terms") === "1",
        });
        setBusy(registerEl, false);
        if (!res.ok) {
          let first = null;
          for (const [k, code] of Object.entries(res.errors)) {
            const el = $(`#err-${k}`);
            if (el) { el.textContent = t(`err.${code}`); el.hidden = false; }
            first ||= registerEl.elements[k] || el;
          }
          first?.focus?.();
          return;
        }
        mergeGuestFavorites();
        toast(t("auth.welcome", { name: res.user.firstname }), "success");
        location.hash = next === "#/compte" ? "#/compte?welcome=1" : next;
      });
    }
  },
};

export const authActions = {
  "auth-mode": (el) => {
    const p = new URLSearchParams();
    if (el.dataset.mode === "register") p.set("mode", "register");
    if (next && next !== "#/compte") p.set("next", next);
    location.hash = `#/connexion${p.toString() ? "?" + p : ""}`;
  },
  "toggle-pw": (el) => {
    const input = document.getElementById(el.dataset.target);
    if (!input) return;
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    el.setAttribute("aria-pressed", show ? "true" : "false");
    el.setAttribute("aria-label", show ? t("auth.hidePassword") : t("auth.showPassword"));
    mount(el, icon(show ? "eyeOff" : "eye"));
  },
};
