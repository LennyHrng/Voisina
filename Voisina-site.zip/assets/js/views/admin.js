/* Espace administrateur : modération et statistiques */
import { html, raw, storage } from "../util.js";
import { icon } from "../icons.js";
import { t, fmtRelative, fmtNumber, categoryName } from "../i18n.js";
import { CATEGORIES } from "../data.js";
import { isAdmin, stats, getReports, resolveReport, getListing, getPerson, allListings, getAllUsersForAdmin, setListingHidden, isHidden } from "../store.js";
import { emptyState, confirmDialog, toast, listingTitle } from "../ui.js";

function kpi(iconName, label, value, tone = "") {
  return html`<div class="kpi ${tone}"><span class="kpi-icon">${icon(iconName)}</span><div><strong>${fmtNumber(value)}</strong><span>${label}</span></div></div>`;
}

function targetLabel(r) {
  if (r.targetType === "listing") {
    const l = getListing(r.targetId);
    return l ? html`<a href="#/annonce/${l.id}">${listingTitle(l)}</a>` : t("admin.deleted");
  }
  if (r.targetType === "user") {
    const p = getPerson(r.targetId);
    return p ? html`<a href="#/membre/${p.id}">${p.name}</a>` : t("admin.deleted");
  }
  return t("admin.conversation");
}

export default {
  title: () => t("nav.admin"),
  refreshOn: ["reports", "listings", "auth"],

  render() {
    if (!isAdmin()) {
      return html`<section class="section"><div class="container narrow">${emptyState({ iconName: "lock", title: t("admin.forbidden"), text: t("admin.forbiddenText"), action: html`<a class="btn btn-primary" href="#/connexion?next=${encodeURIComponent("#/admin")}">${t("auth.login")}</a>` })}</div></section>`;
    }
    const s = stats();
    const reports = getReports();
    const open = reports.filter((r) => r.status === "open");
    const closed = reports.filter((r) => r.status !== "open").slice(0, 8);
    const users = getAllUsersForAdmin();
    const listings = allListings();
    const memberListings = allListings({ includeInactive: true }).filter((l) => !l.demo);
    const counts = CATEGORIES.map((c) => ({ c, n: listings.filter((l) => l.category === c.id).length })).sort((a, b) => b.n - a.n);
    const max = Math.max(1, ...counts.map((x) => x.n));

    return html`
    <section class="page-head">
      <div class="container page-head-row">
        <div><span class="kicker">${icon("shield")}${t("admin.kicker")}</span><h1 class="h1">${t("admin.title")}</h1><p class="lead">${t("admin.lead")}</p></div>
        <div class="page-head-actions"><button type="button" class="btn btn-danger-ghost" data-action="reset-demo">${icon("refresh")}${t("admin.reset")}</button></div>
      </div>
    </section>
    <div class="container admin-wrap">
      <div class="kpi-grid">
        ${kpi("file", t("admin.kpiListings"), s.active)}
        ${kpi("users", t("admin.kpiUsers"), s.users)}
        ${kpi("message", t("admin.kpiMessages"), s.messages)}
        ${kpi("flag", t("admin.kpiReports"), s.reportsOpen, s.reportsOpen ? "kpi-alert" : "")}
      </div>

      <section class="card admin-section">
        <h2 class="h3">${icon("flag")}${t("admin.reportsTitle")} <span class="count-pill">${open.length}</span></h2>
        ${open.length ? html`<div class="table-wrap"><table class="table">
          <thead><tr><th>${t("admin.colTarget")}</th><th>${t("admin.colReason")}</th><th>${t("admin.colDetails")}</th><th>${t("admin.colWhen")}</th><th><span class="sr-only">${t("admin.colActions")}</span></th></tr></thead>
          <tbody>${open.map((r) => html`<tr>
            <td><span class="badge">${t("admin.type." + r.targetType)}</span> ${targetLabel(r)}</td>
            <td>${t("report.reason." + r.reason)}</td>
            <td class="td-details">${r.details || "—"}</td>
            <td>${fmtRelative(r.at)}</td>
            <td class="td-actions">
              ${r.targetType === "listing" ? html`<button type="button" class="btn btn-danger btn-sm" data-action="resolve-report" data-id="${r.id}" data-do="hide">${icon("eyeOff")}${t("admin.hide")}</button>` : ""}
              <button type="button" class="btn btn-ghost btn-sm" data-action="resolve-report" data-id="${r.id}" data-do="dismiss">${t("admin.dismiss")}</button>
            </td></tr>`)}</tbody></table></div>`
          : html`<p class="muted">${icon("checkCircle")} ${t("admin.noReports")}</p>`}
        ${closed.length ? html`<details class="admin-history"><summary>${t("admin.history")}</summary><ul>${closed.map((r) => html`<li>${t("admin.type." + r.targetType)} — ${t("report.reason." + r.reason)} — <strong>${t("admin.status." + r.status)}</strong> (${fmtRelative(r.resolvedAt || r.at)})</li>`)}</ul></details>` : ""}
      </section>

      <div class="admin-grid">
        <section class="card admin-section">
          <h2 class="h3">${icon("file")}${t("admin.memberListings")}</h2>
          ${memberListings.length ? html`<ul class="admin-list">${memberListings.map((l) => html`<li>
            <a href="#/annonce/${l.id}">${listingTitle(l)}</a>
            <span class="muted small">${getPerson(l.authorId)?.name || "—"} · ${l.city} · <span class="status status-${l.status}">${t("status." + l.status)}</span></span>
            <button type="button" class="btn btn-ghost btn-sm" data-action="admin-hide" data-id="${l.id}" data-hidden="${isHidden(l.id) ? "0" : "1"}">${icon(isHidden(l.id) ? "eye" : "eyeOff")}${isHidden(l.id) ? t("admin.unhide") : t("admin.hide")}</button>
          </li>`)}</ul>` : html`<p class="muted">${t("admin.noMemberListings")}</p>`}
        </section>

        <section class="card admin-section">
          <h2 class="h3">${icon("chart")}${t("admin.byCategory")}</h2>
          <ul class="bars">${counts.map(({ c, n }) => html`<li><span class="bar-label">${categoryName(c.id)}</span><span class="bar-track"><span class="bar tone-${c.tone}" data-w="${Math.round((n / max) * 100)}"></span></span><span class="bar-value">${n}</span></li>`)}</ul>
        </section>
      </div>

      <section class="card admin-section">
        <h2 class="h3">${icon("users")}${t("admin.members")} <span class="count-pill">${users.length}</span></h2>
        ${users.length ? html`<div class="table-wrap"><table class="table">
          <thead><tr><th>${t("admin.colName")}</th><th>${t("auth.email")}</th><th>${t("auth.city")}</th><th>${t("admin.colJoined")}</th></tr></thead>
          <tbody>${users.map((u) => html`<tr><td><a href="#/membre/${u.id}">${u.firstname} ${u.lastname}</a></td><td>${u.email}</td><td>${u.city || "—"} ${u.canton ? `(${u.canton})` : ""}</td><td>${fmtRelative(u.created)}</td></tr>`)}</tbody>
        </table></div><p class="help">${icon("lock")}${t("admin.pwNote")}</p>` : html`<p class="muted">${t("admin.noMembers")}</p>`}
      </section>
    </div>`;
  },

  mount(root) {
    // Largeur des barres appliquée en JS (compatible avec notre politique de sécurité CSP)
    root.querySelectorAll(".bar[data-w]").forEach((b) => { b.style.width = b.dataset.w + "%"; });
  },
};

export const adminActions = {
  "resolve-report": (el) => {
    if (resolveReport(el.dataset.id, el.dataset.do)) toast(el.dataset.do === "hide" ? t("admin.hidden") : t("admin.dismissed"), "success");
  },
  "reset-demo": async () => {
    if (!(await confirmDialog({ title: t("admin.resetTitle"), text: t("admin.resetText"), confirm: t("admin.reset"), danger: true }))) return;
    storage.clearAll();
    location.hash = "#/";
    location.reload();
  },
};

export { raw, setListingHidden };
