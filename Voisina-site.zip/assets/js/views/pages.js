/* Pages d'information : aide, sécurité, règles, conditions, confidentialité, mentions légales, à propos */
import { html } from "../util.js";
import { icon } from "../icons.js";
import { t, getLang } from "../i18n.js";
import { PAGES, PAGE_ORDER } from "../pages-content.js";
import { emptyState } from "../ui.js";

const PAGE_ICONS = { aide: "help", securite: "shieldCheck", regles: "users", conditions: "file", confidentialite: "lock", "mentions-legales": "info", "a-propos": "leaf" };

function content(slug) {
  const page = PAGES[slug];
  return page ? page[getLang()] || page.fr : null;
}

export default {
  title: (ctx) => content(ctx.params[0])?.title || t("notFound.title"),
  refreshOn: [],

  render(ctx) {
    const slug = ctx.params[0];
    const c = content(slug);
    if (!c) return html`<section class="section"><div class="container narrow">${emptyState({ iconName: "search", title: t("notFound.title"), action: html`<a class="btn btn-primary" href="#/">${t("notFound.home")}</a>` })}</div></section>`;
    return html`
    <section class="page-head">
      <div class="container narrow-wide">
        <span class="kicker">${icon(PAGE_ICONS[slug] || "file")}${t("pages.kicker")}</span>
        <h1 class="h1">${c.title}</h1>
        ${c.intro ? html`<p class="lead">${c.intro}</p>` : ""}
        ${c.updated ? html`<p class="muted small">${c.updated}</p>` : ""}
      </div>
    </section>
    <div class="container pages-layout">
      <nav class="pages-nav" aria-label="${t("pages.nav")}">
        ${PAGE_ORDER.map((s) => html`<a class="pages-nav-link${s === slug ? " is-active" : ""}" href="#/page/${s}" ${s === slug ? html`aria-current="page"` : ""}>${icon(PAGE_ICONS[s])}${content(s).title}</a>`)}
      </nav>
      <article class="prose">
        ${c.sections.map((s) => html`<section>
          <h2>${s.h}</h2>
          ${(s.p || []).map((p) => html`<p>${p}</p>`)}
          ${s.list ? html`<ul>${s.list.map((li) => html`<li>${li}</li>`)}</ul>` : ""}
          ${s.qa ? html`<div class="faq">${s.qa.map(([q, a]) => html`<details class="faq-item"><summary>${q}${icon("chevronDown")}</summary><p>${a}</p></details>`)}</div>` : ""}
        </section>`)}
        ${c.contact ? html`<div class="notice">${icon("mail")}<span>${c.contact}</span></div>` : ""}
      </article>
    </div>`;
  },
};
