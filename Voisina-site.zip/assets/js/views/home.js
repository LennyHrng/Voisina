/* Page d'accueil */
import { html, raw } from "../util.js";
import { icon } from "../icons.js";
import { t, fmtNumber, categoryName } from "../i18n.js";
import { CATEGORIES, getCategory } from "../data.js";
import { allListings, searchListings, getOrigin, setOrigin, stats, isFavorite } from "../store.js";
import { listingCard, priceLabel, listingTitle, localityField, initLocalityFields } from "../ui.js";
import { swissMapSvg, project, VIEW_W, VIEW_H } from "../switzerland.js";

function heroCards(listings) {
  const wanted = [["Lausanne", "right"], ["Zürich", "left"], ["Lugano", "left"]];
  return wanted
    .map(([city, side], i) => {
      const l = listings.find((x) => x.city === city && x.demo && x.type === (i === 1 ? "request" : "offer")) || listings.find((x) => x.city === city);
      if (!l) return "";
      const [x, y] = project(l.lng, l.lat);
      const cat = getCategory(l.category);
      return html`<a class="hero-float hero-float-${i} side-${side}" href="#/annonce/${l.id}" data-x="${((x / VIEW_W) * 100).toFixed(1)}" data-y="${((y / VIEW_H) * 100).toFixed(1)}">
        <span class="hero-float-icon tone-${cat.tone}">${icon(cat.icon)}</span>
        <span class="hero-float-text"><strong>${listingTitle(l)}</strong><span>${l.city} · ${priceLabel(l)}</span></span>
      </a>`;
    });
}

const FAQ = ["cost", "safety", "payment", "location", "languages", "data"];

export default {
  title: () => t("meta.homeTitle"),
  refreshOn: ["listings", "auth"],
  onData(kind) {
    if (kind === "favorites") {
      document.querySelectorAll(".fav-btn[data-id]").forEach((b) => {
        const on = isFavorite(b.dataset.id);
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", on ? "true" : "false");
      });
    }
  },

  render() {
    const listings = allListings();
    const s = stats();
    const origin = getOrigin();
    const recent = searchListings({ sort: origin ? "distance" : "recent" }, origin).slice(0, 8);
    const counts = {};
    listings.forEach((l) => { counts[l.category] = (counts[l.category] || 0) + 1; });
    const dots = listings.slice(0, 380).map((l) => ({ lat: l.lat, lng: l.lng, tone: getCategory(l.category).tone }));

    return html`
    <section class="hero">
      <div class="container hero-grid">
        <div class="hero-copy">
          <span class="eyebrow">${icon("leaf")}${t("home.eyebrow")}</span>
          <h1 class="display">${t("home.title1")}<br>${t("home.title2")}<br><em>${t("home.title3")}</em></h1>
          <p class="lead">${t("home.lead")}</p>

          <form class="hero-search" data-form="hero-search" role="search">
            <div class="field">
              <label class="sr-only" for="hero-q">${t("search.what")}</label>
              <div class="input-icon">${icon("search")}<input id="hero-q" class="input" name="q" placeholder="${t("search.whatPh")}" maxlength="80"></div>
            </div>
            ${localityField({ name: "where", placeholder: origin?.label || t("search.wherePh") })}
            <button class="btn btn-primary btn-lg" type="submit">${t("search.submit")}</button>
          </form>
          <div class="hero-quick">
            <button type="button" class="link-btn" data-action="locate">${icon("locate")}${t("search.nearMe")}</button>
            <span class="hero-quick-sep" aria-hidden="true">·</span>
            ${["shopping", "pets", "digital", "garden"].map((c) => html`<a class="pill" href="#/explorer?cat=${c}">${categoryName(c)}</a>`)}
          </div>
        </div>

        <div class="hero-visual" aria-hidden="true">
          <div class="hero-map">
            ${swissMapSvg(dots)}
            ${heroCards(listings)}
          </div>
        </div>
      </div>
    </section>

    <section class="stats-band" aria-label="${t("home.statsLabel")}">
      <div class="container stats-grid">
        <div class="stat"><strong>${fmtNumber(s.active)}</strong><span>${t("home.statListings")}</span></div>
        <div class="stat"><strong>26</strong><span>${t("home.statCantons")}</span></div>
        <div class="stat"><strong>4</strong><span>${t("home.statLangs")}</span></div>
        <div class="stat"><strong>0</strong><span>${t("home.statTrackers")}</span></div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="section-head">
          <div><span class="kicker">${t("home.catKicker")}</span><h2 class="h2">${t("home.catTitle")}</h2></div>
          <a class="btn btn-ghost" href="#/explorer">${t("home.seeAll")}${icon("arrowRight")}</a>
        </div>
        <div class="cat-grid">
          ${CATEGORIES.map((c) => html`<a class="cat-tile" href="#/explorer?cat=${c.id}">
            <span class="cat-icon tone-${c.tone}">${icon(c.icon)}</span>
            <span class="cat-name">${categoryName(c.id)}</span>
            <span class="cat-count">${t("home.catCount", { count: counts[c.id] || 0 })}</span>
          </a>`)}
        </div>
      </div>
    </section>

    <section class="section section-alt">
      <div class="container">
        <div class="section-head">
          <div><span class="kicker">${origin ? t("home.nearKicker", { place: origin.label }) : t("home.recentKicker")}</span><h2 class="h2">${t("home.recentTitle")}</h2></div>
          <a class="btn btn-ghost" href="#/explorer">${t("home.seeAll")}${icon("arrowRight")}</a>
        </div>
        <div class="listing-grid">
          ${recent.map(({ listing, distance }) => listingCard(listing, { distance }))}
        </div>
      </div>
    </section>

    <section class="section" id="how">
      <div class="container">
        <div class="section-head center">
          <div><span class="kicker">${t("home.howKicker")}</span><h2 class="h2">${t("home.howTitle")}</h2></div>
        </div>
        <ol class="steps">
          ${[["pencil", 1], ["message", 2], ["hand", 3]].map(([ic, n]) => html`<li class="step">
            <span class="step-num">${n}</span>
            <span class="step-icon">${icon(ic)}</span>
            <h3>${t(`home.step${n}Title`)}</h3>
            <p>${t(`home.step${n}Text`)}</p>
          </li>`)}
        </ol>
        <div class="center-actions">
          <a class="btn btn-primary btn-lg" href="#/publier">${icon("plus")}${t("home.ctaPublish")}</a>
          <a class="btn btn-ghost btn-lg" href="#/explorer">${t("home.ctaExplore")}</a>
        </div>
      </div>
    </section>

    <section class="section trust-section">
      <div class="container trust-grid">
        <div class="trust-intro">
          <span class="kicker kicker-light">${t("home.trustKicker")}</span>
          <h2 class="h2">${t("home.trustTitle")}</h2>
          <p>${t("home.trustText")}</p>
          <a class="btn btn-light" href="#/page/securite">${icon("shieldCheck")}${t("home.trustCta")}</a>
        </div>
        <div class="trust-cards">
          ${[["pin", "Loc"], ["lock", "Pwd"], ["flag", "Report"], ["eyeOff", "Track"]].map(([ic, k]) => html`<div class="trust-card">
            <span class="trust-icon">${icon(ic)}</span>
            <h3>${t(`home.trust${k}Title`)}</h3>
            <p>${t(`home.trust${k}Text`)}</p>
          </div>`)}
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container faq-wrap">
        <div>
          <span class="kicker">${t("home.faqKicker")}</span>
          <h2 class="h2">${t("home.faqTitle")}</h2>
          <p class="muted">${t("home.faqText")}</p>
          <a class="btn btn-ghost" href="#/page/aide">${t("home.faqMore")}${icon("arrowRight")}</a>
        </div>
        <div class="faq">
          ${FAQ.map((k) => html`<details class="faq-item"><summary>${t(`faq.${k}.q`)}${icon("chevronDown")}</summary><p>${t(`faq.${k}.a`)}</p></details>`)}
        </div>
      </div>
    </section>

    <section class="section cta-band">
      <div class="container cta-inner">
        <div>
          <h2 class="h2">${t("home.ctaTitle")}</h2>
          <p>${t("home.ctaText")}</p>
        </div>
        <div class="cta-actions">
          <a class="btn btn-light btn-lg" href="#/publier">${icon("plus")}${t("home.ctaPublish")}</a>
        </div>
      </div>
    </section>`;
  },

  mount(root) {
    initLocalityFields(root);
    let placeChosen = false;
    root.addEventListener("locality-change", (e) => {
      const loc = e.detail;
      setOrigin({ lat: loc.lat, lng: loc.lng, label: loc.name });
      placeChosen = true;
    });
    root.querySelector("[data-form='hero-search']")?.addEventListener("submit", (e) => {
      e.preventDefault();
      const p = new URLSearchParams();
      const q = e.target.q.value.trim();
      if (q) p.set("q", q);
      if (placeChosen) { p.set("radius", "25"); p.set("sort", "distance"); }
      location.hash = `#/explorer${p.toString() ? "?" + p : ""}`;
    });
    // Positionne les cartes flottantes sur l'illustration de la Suisse
    root.querySelectorAll(".hero-float").forEach((el) => {
      el.style.setProperty("--x", el.dataset.x + "%");
      el.style.setProperty("--y", el.dataset.y + "%");
    });
  },
};

export { raw };
