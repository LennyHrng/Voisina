/* Page "Explorer" : recherche, filtres, liste d'annonces et carte */
import { html, raw, $, $$, mount, debounce } from "../util.js";
import { icon } from "../icons.js";
import { t, cantonName, categoryName, fmtNumber } from "../i18n.js";
import { CATEGORIES, CANTON_CODES, TYPES, PAYMENTS, LOCALITIES } from "../data.js";
import { searchListings, getOrigin, setOrigin, isFavorite } from "../store.js";
import { listingCard, emptyState, localityField, initLocalityFields, toast } from "../ui.js";
import { createMap, listingsLayer, leafletReady, fitSwitzerland } from "../map.js";

const PAGE_SIZE = 16;
const FILTER_KEYS = ["q", "type", "cat", "canton", "pay", "radius", "urgent", "verified", "sort", "page"];

let state = null;
let map = null;
let layer = null;
let mapBounds = null;
let userMoved = false;

function readFilters(query) {
  const f = {};
  for (const k of FILTER_KEYS) {
    const v = query.get(k);
    if (v) f[k] = v;
  }
  if (f.type && !TYPES.includes(f.type)) delete f.type;
  if (f.cat && !CATEGORIES.some((c) => c.id === f.cat)) delete f.cat;
  if (f.canton && !CANTON_CODES.includes(f.canton)) delete f.canton;
  if (f.pay && !PAYMENTS.includes(f.pay)) delete f.pay;
  if (f.radius && !["5", "10", "25", "50"].includes(f.radius)) delete f.radius;
  f.page = Math.max(1, parseInt(f.page, 10) || 1);
  f.view = query.get("view") === "map" ? "map" : "list";
  return f;
}

function writeUrl() {
  const p = new URLSearchParams();
  for (const k of FILTER_KEYS) {
    const v = state.f[k];
    if (v && !(k === "page" && v === 1)) p.set(k, v);
  }
  if (state.f.view === "map") p.set("view", "map");
  const qs = p.toString();
  history.replaceState(null, "", `#/explorer${qs ? "?" + qs : ""}`);
}

function select(name, label, options, value) {
  return html`<label class="filter-select"><span class="sr-only">${label}</span>
    <select class="select" name="${name}" data-filter="${name}" aria-label="${label}">
      ${options.map(([v, text]) => html`<option value="${v}" ${String(v) === String(value || "") ? raw("selected") : ""}>${text}</option>`)}
    </select></label>`;
}

function filtersBar(f, origin) {
  return html`
  <div class="filter-row">
    <div class="segmented" role="group" aria-label="${t("filter.type")}">
      ${[["", t("filter.all")], ...TYPES.map((ty) => [ty, t("type." + ty)])].map(([v, text]) => html`<button type="button" class="seg${(f.type || "") === v ? " is-active" : ""}" data-action="filter-type" data-value="${v}" aria-pressed="${(f.type || "") === v ? "true" : "false"}">${text}</button>`)}
    </div>
    ${select("cat", t("filter.category"), [["", t("filter.allCategories")], ...CATEGORIES.map((c) => [c.id, categoryName(c.id)])], f.cat)}
    ${select("canton", t("filter.canton"), [["", t("filter.allCantons")], ...CANTON_CODES.map((c) => [c, `${cantonName(c)} (${c})`]).sort((a, b) => a[1].localeCompare(b[1]))], f.canton)}
    ${select("pay", t("filter.payment"), [["", t("filter.anyPayment")], ...PAYMENTS.map((p) => [p, t("pay." + p)])], f.pay)}
    ${select("radius", t("filter.radius"), [["", origin ? t("filter.anyDistance") : t("filter.radius")], ...["5", "10", "25", "50"].map((r) => [r, t("filter.within", { km: r })])], f.radius)}
    <label class="toggle"><input type="checkbox" data-filter="urgent" ${f.urgent ? raw("checked") : ""}><span>${icon("zap")}${t("filter.urgent")}</span></label>
    <label class="toggle"><input type="checkbox" data-filter="verified" ${f.verified ? raw("checked") : ""}><span>${icon("badgeCheck")}${t("filter.verified")}</span></label>
  </div>`;
}

function activeChips(f, origin) {
  const chips = [];
  if (origin) chips.push(html`<button type="button" class="chip chip-removable" data-action="clear-origin">${icon("pin")}${t("filter.around", { place: origin.label })}${icon("x")}</button>`);
  if (mapBounds) chips.push(html`<button type="button" class="chip chip-removable" data-action="clear-bounds">${icon("map")}${t("filter.mapArea")}${icon("x")}</button>`);
  if (f.q) chips.push(html`<button type="button" class="chip chip-removable" data-action="clear-filter" data-key="q">« ${f.q} »${icon("x")}</button>`);
  const any = chips.length || f.type || f.cat || f.canton || f.pay || f.radius || f.urgent || f.verified;
  if (!any) return "";
  return html`<div class="active-chips">${chips}<button type="button" class="link-btn" data-action="reset-filters">${t("filter.reset")}</button></div>`;
}

function renderResults() {
  const f = state.f;
  const origin = getOrigin();
  const all = searchListings({ ...f, bounds: mapBounds }, origin);
  const pages = Math.max(1, Math.ceil(all.length / PAGE_SIZE));
  if (f.page > pages) f.page = pages;
  const pageItems = all.slice((f.page - 1) * PAGE_SIZE, f.page * PAGE_SIZE);

  mount($("#results-count"), html`<strong>${fmtNumber(all.length)}</strong> ${t("explore.results", { count: all.length })}`);
  mount($("#active-chips"), activeChips(f, origin));
  mount(
    $("#results-grid"),
    pageItems.length
      ? html`${pageItems.map(({ listing, distance }) => listingCard(listing, { distance }))}`
      : emptyState({ iconName: "search", title: t("explore.emptyTitle"), text: t("explore.emptyText"), action: html`<div class="empty-actions"><button class="btn btn-ghost" data-action="reset-filters">${t("filter.reset")}</button><a class="btn btn-primary" href="#/publier">${icon("plus")}${t("explore.emptyPublish")}</a></div>` })
  );
  mount($("#pagination"), pagination(f.page, pages));
  layer?.setItems(all.map((r) => r.listing));
  writeUrl();
}

function pagination(page, pages) {
  if (pages <= 1) return "";
  const nums = [];
  const start = Math.max(1, Math.min(page - 2, pages - 4));
  const end = Math.min(pages, start + 4);
  for (let i = start; i <= end; i++) nums.push(i);
  return html`
    <button class="page-btn" data-action="page" data-page="${page - 1}" ${page === 1 ? raw("disabled") : ""} aria-label="${t("common.previous")}">${icon("chevronLeft")}</button>
    ${start > 1 ? html`<button class="page-btn" data-action="page" data-page="1">1</button>${start > 2 ? html`<span class="page-gap">…</span>` : ""}` : ""}
    ${nums.map((n) => html`<button class="page-btn${n === page ? " is-active" : ""}" data-action="page" data-page="${n}" ${n === page ? raw('aria-current="page"') : ""}>${n}</button>`)}
    ${end < pages ? html`${end < pages - 1 ? html`<span class="page-gap">…</span>` : ""}<button class="page-btn" data-action="page" data-page="${pages}">${pages}</button>` : ""}
    <button class="page-btn" data-action="page" data-page="${page + 1}" ${page === pages ? raw("disabled") : ""} aria-label="${t("common.next")}">${icon("chevronRight")}</button>`;
}

function setFilter(key, value, { resetPage = true } = {}) {
  if (value === "" || value === null || value === false || value === undefined) delete state.f[key];
  else state.f[key] = value;
  if (resetPage) state.f.page = 1;
  renderResults();
}

function applyView() {
  const layout = $("#explore-layout");
  if (!layout) return;
  layout.classList.toggle("show-map", state.f.view === "map");
  $$("[data-action='set-view']").forEach((b) => {
    const on = b.dataset.value === state.f.view;
    b.classList.toggle("is-active", on);
    b.setAttribute("aria-pressed", on ? "true" : "false");
  });
  setTimeout(() => map?.invalidateSize(), 60);
  writeUrl();
}

export const exploreActions = {
  "filter-type": (el) => {
    $$("[data-action='filter-type']").forEach((b) => { b.classList.toggle("is-active", b === el); b.setAttribute("aria-pressed", b === el ? "true" : "false"); });
    setFilter("type", el.dataset.value);
  },
  "clear-filter": (el) => {
    if (el.dataset.key === "q") { const q = $("#explore-q"); if (q) q.value = ""; }
    setFilter(el.dataset.key, "");
  },
  "reset-filters": () => {
    state.f = { page: 1, view: state.f.view };
    mapBounds = null;
    const q = $("#explore-q");
    if (q) q.value = "";
    mount($("#filter-bar"), filtersBar(state.f, getOrigin()));
    renderResults();
  },
  "clear-origin": () => {
    setOrigin(null);
    delete state.f.radius;
    if (state.f.sort === "distance") delete state.f.sort;
    mount($("#filter-bar"), filtersBar(state.f, null));
    const w = $("#f-where");
    if (w) { w.value = ""; w.placeholder = t("search.wherePh"); }
    renderResults();
  },
  "clear-bounds": () => { mapBounds = null; renderResults(); },
  "search-area": () => {
    if (!map) return;
    const b = map.getBounds();
    mapBounds = [b.getSouth(), b.getWest(), b.getNorth(), b.getEast()];
    const btn = $("#map-search-area");
    if (btn) btn.hidden = true;
    userMoved = false;
    state.f.page = 1;
    renderResults();
  },
  page: (el) => {
    state.f.page = Number(el.dataset.page) || 1;
    renderResults();
    $("#results-top")?.scrollIntoView({ behavior: "smooth", block: "start" });
  },
  "set-view": (el) => { state.f.view = el.dataset.value; applyView(); },
  "toggle-filters": (el) => {
    const bar = $("#filter-bar");
    const open = bar.classList.toggle("is-open");
    el.setAttribute("aria-expanded", open ? "true" : "false");
  },
};

export default {
  title: () => t("meta.exploreTitle"),
  refreshOn: [],

  render(ctx) {
    const f = readFilters(ctx.query);
    // Une nouvelle recherche arrivant par l'URL remet la zone de carte à zéro
    mapBounds = null;
    state = { f };
    const origin = getOrigin();
    const sortOptions = [["recent", t("sort.recent")], ["soon", t("sort.soon")], ["priceLow", t("sort.priceLow")], ["priceHigh", t("sort.priceHigh")]];
    if (origin) sortOptions.unshift(["distance", t("sort.distance")]);

    return html`
    <section class="page-head page-head-tight">
      <div class="container">
        <h1 class="h1">${t("explore.title")}</h1>
        <form class="explore-search" data-form="explore-search" role="search">
          <div class="field"><label class="sr-only" for="explore-q">${t("search.what")}</label>
            <div class="input-icon">${icon("search")}<input id="explore-q" class="input" name="q" value="${f.q || ""}" placeholder="${t("search.whatPh")}" maxlength="80"></div></div>
          ${localityField({ name: "where", value: "", placeholder: origin?.label || t("search.wherePh") })}
          <button type="button" class="btn btn-ghost btn-icon-only" data-action="locate" title="${t("search.nearMe")}" aria-label="${t("search.nearMe")}">${icon("locate")}</button>
          <button class="btn btn-primary" type="submit">${t("search.submit")}</button>
        </form>
        <button type="button" class="btn btn-ghost filters-toggle" data-action="toggle-filters" aria-expanded="false" aria-controls="filter-bar">${icon("sliders")}${t("filter.title")}</button>
        <div id="filter-bar" class="filter-bar">${filtersBar(f, origin)}</div>
      </div>
    </section>

    <section class="container explore-layout${f.view === "map" ? " show-map" : ""}" id="explore-layout">
      <div class="results-col">
        <div class="results-bar" id="results-top">
          <p id="results-count" class="results-count" aria-live="polite"></p>
          <div class="results-tools">
            <label class="sort"><span class="muted">${t("sort.label")}</span>
              <select class="select select-sm" data-filter="sort" aria-label="${t("sort.label")}">
                ${sortOptions.map(([v, text]) => html`<option value="${v}" ${(f.sort || (origin ? "distance" : "recent")) === v ? raw("selected") : ""}>${text}</option>`)}
              </select></label>
            <div class="segmented segmented-sm view-toggle" role="group" aria-label="${t("explore.view")}">
              <button type="button" class="seg${f.view === "list" ? " is-active" : ""}" data-action="set-view" data-value="list" aria-pressed="${f.view === "list" ? "true" : "false"}">${icon("list")}<span>${t("explore.list")}</span></button>
              <button type="button" class="seg${f.view === "map" ? " is-active" : ""}" data-action="set-view" data-value="map" aria-pressed="${f.view === "map" ? "true" : "false"}">${icon("map")}<span>${t("explore.map")}</span></button>
            </div>
          </div>
        </div>
        <div id="active-chips"></div>
        <div id="results-grid" class="listing-grid listing-grid-explore"></div>
        <nav id="pagination" class="pagination" aria-label="${t("common.pagination")}"></nav>
      </div>
      <div class="map-col">
        <div class="map-sticky">
          <div id="explore-map" class="map" role="region" aria-label="${t("explore.mapLabel")}"></div>
          <button type="button" class="btn btn-primary map-back-list" data-action="set-view" data-value="list">${icon("list")}${t("explore.list")}</button>
          <button type="button" id="map-search-area" class="btn btn-light map-search-area" data-action="search-area" hidden>${icon("search")}${t("explore.searchArea")}</button>
          <p class="map-note">${icon("shield")}${t("explore.mapPrivacy")}</p>
        </div>
      </div>
    </section>`;
  },

  mount(root) {
    initLocalityFields(root);
    const mapEl = $("#explore-map", root);
    map = createMap(mapEl, { zoom: 8 });
    if (map) {
      fitSwitzerland(map);
      layer = listingsLayer(map);
      map.on("dragstart zoomstart", () => { userMoved = true; });
      map.on("moveend", () => { const b = $("#map-search-area"); if (userMoved && b) b.hidden = false; });
    } else layer = null;
    renderResults();

    // Filtres (listes déroulantes et cases)
    root.addEventListener("change", (e) => {
      const el = e.target.closest("[data-filter]");
      if (!el) return;
      const key = el.dataset.filter;
      if (key === "radius" && el.value && !getOrigin()) {
        el.value = "";
        toast(t("filter.distanceNeedsPlace"), "info");
        $("#f-where")?.focus();
        return;
      }
      setFilter(key, el.type === "checkbox" ? (el.checked ? "1" : "") : el.value, { resetPage: key !== "sort" });
    });
    // Recherche instantanée pendant la frappe
    const q = $("#explore-q", root);
    q?.addEventListener("input", debounce(() => setFilter("q", q.value.trim()), 300));
    root.addEventListener("submit", (e) => {
      if (!e.target.matches("[data-form='explore-search']")) return;
      e.preventDefault();
      setFilter("q", q.value.trim());
      $("#results-top")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    // Choix d'une localité = point de référence pour la distance
    root.addEventListener("locality-change", (e) => {
      const loc = e.detail;
      setOrigin({ lat: loc.lat, lng: loc.lng, label: loc.name });
      if (!state.f.radius) state.f.radius = "25";
      state.f.sort = "distance";
      mount($("#filter-bar"), filtersBar(state.f, getOrigin()));
      const sortSel = root.querySelector("[data-filter='sort']");
      if (sortSel && ![...sortSel.options].some((o) => o.value === "distance")) {
        sortSel.insertAdjacentHTML("afterbegin", `<option value="distance">${t("sort.distance")}</option>`);
      }
      if (sortSel) sortSel.value = "distance";
      mapBounds = null;
      renderResults();
      if (map) map.setView([loc.lat, loc.lng], 11);
    });
  },

  /** Mise à jour légère quand les favoris changent (cœurs). */
  onData(kind) {
    if (kind === "favorites") {
      $$(".fav-btn[data-id]").forEach((b) => {
        const on = isFavorite(b.dataset.id);
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", on ? "true" : "false");
      });
    } else if (kind === "listings" || kind === "block") renderResults();
  },

  unmount() {
    map?.remove();
    map = null;
    layer = null;
    state = null;
    userMoved = false;
  },
};

export { LOCALITIES, leafletReady };
