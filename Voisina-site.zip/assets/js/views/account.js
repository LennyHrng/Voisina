/* Mon compte : profil, annonces, sécurité, données personnelles, préférences */
import { html, raw, $, $$, mount, processImage, downloadFile, safeImageSrc } from "../util.js";
import { icon } from "../icons.js";
import { t, fmtDate, cantonName, getLang, setLang, fmtRelative } from "../i18n.js";
import { currentUser, updateProfile, changePassword, deleteAccount, exportMyData, listingsByAuthor, getFavorites, getConversations, getPerson, logout, getPrefs, setPrefs, isAdmin } from "../store.js";
import { passwordStrength } from "../auth.js";
import { avatar, listingCard, emptyState, localityField, initLocalityFields, langChips, toast, confirmDialog, openDialog, priceLabel, listingTitle, categoryThumb } from "../ui.js";

const TABS = ["profile", "listings", "security", "data", "prefs"];
const TAB_ICONS = { profile: "user", listings: "file", security: "lock", data: "download", prefs: "sliders" };
let tab = "profile";
let pendingPhoto = undefined;

function profileTab(me) {
  const person = getPerson(me.id);
  return html`
  <form id="profile-form" class="card form-card" novalidate>
    <div class="profile-photo-row">
      <div id="profile-avatar">${avatar({ ...person, photo: pendingPhoto ?? me.photo }, "xl")}</div>
      <div>
        <label class="btn btn-ghost">${icon("camera")}${t("account.changePhoto")}<input type="file" accept="image/jpeg,image/png,image/webp" class="sr-only" id="photo-input"></label>
        ${(pendingPhoto ?? me.photo) ? html`<button type="button" class="link-btn danger" data-action="remove-avatar">${t("account.removePhoto")}</button>` : ""}
        <p class="help">${icon("shield")}${t("publish.photoHint")}</p>
      </div>
    </div>
    <div class="grid-2">
      <div class="field"><label class="field-label" for="f-firstname">${t("auth.firstname")}</label><input id="f-firstname" class="input" name="firstname" value="${me.firstname}" maxlength="40" required></div>
      <div class="field"><label class="field-label" for="f-lastname">${t("auth.lastname")}</label><input id="f-lastname" class="input" name="lastname" value="${me.lastname}" maxlength="40" required></div>
    </div>
    <p class="help">${icon("eyeOff")}${t("account.publicName", { name: person.name })}</p>
    ${localityField({ name: "city", label: t("auth.city"), value: me.city || "", canton: me.canton || "" })}
    <div class="field"><label class="field-label" for="f-bio">${t("account.bio")}</label>
      <textarea id="f-bio" class="input textarea" name="bio" rows="4" maxlength="400" placeholder="${t("account.bioPh")}">${me.bio || ""}</textarea></div>
    <div class="field"><label class="field-label" for="f-specialties">${t("account.specialties")}</label>
      <input id="f-specialties" class="input" name="specialties" value="${(me.specialties || []).join(", ")}" maxlength="200" placeholder="${t("account.specialtiesPh")}">
      <p class="help">${t("account.specialtiesHint")}</p></div>
    <div class="field"><span class="field-label">${t("account.languages")}</span>${langChips("languages", me.languages || [])}</div>
    <div class="form-actions">
      <a class="btn btn-ghost" href="#/membre/${me.id}">${icon("eye")}${t("account.viewPublic")}</a>
      <button type="submit" class="btn btn-primary">${icon("check")}${t("common.save")}</button>
    </div>
  </form>`;
}

function listingsTab(me) {
  const mine = listingsByAuthor(me.id, { includeInactive: true });
  if (!mine.length) return emptyState({ iconName: "file", title: t("account.noListings"), text: t("account.noListingsText"), action: html`<a class="btn btn-primary" href="#/publier">${icon("plus")}${t("nav.publish")}</a>` });
  return html`<ul class="my-listings">${mine.map((l) => html`<li class="my-listing card">
    ${categoryThumb(l, "my-listing-thumb")}
    <div class="my-listing-body">
      <a class="my-listing-title" href="#/annonce/${l.id}">${listingTitle(l)}</a>
      <p class="muted small">${l.city} · ${priceLabel(l)} · ${t("listing.published", { when: fmtRelative(l.created) })}</p>
      <span class="status status-${l.status}">${t("status." + l.status)}</span>
    </div>
    <div class="my-listing-actions">
      <a class="btn btn-ghost btn-sm" href="#/publier?edit=${l.id}">${icon("pencil")}${t("listing.edit")}</a>
      ${l.status !== "hidden" ? html`<button type="button" class="btn btn-ghost btn-sm" data-action="listing-status" data-id="${l.id}" data-status="${l.status === "done" ? "active" : "done"}">${icon(l.status === "done" ? "refresh" : "checkCircle")}${l.status === "done" ? t("listing.reactivate") : t("listing.markDone")}</button>` : ""}
      <button type="button" class="btn btn-danger-ghost btn-sm" data-action="listing-delete" data-id="${l.id}">${icon("trash")}${t("listing.delete")}</button>
    </div>
  </li>`)}</ul>`;
}

function securityTab(me) {
  if (me.role === "admin") {
    return html`<div class="card form-card"><p class="notice">${icon("info")}<span>${t("account.adminPwNote")}</span></p></div>`;
  }
  return html`
  <form id="password-form" class="card form-card" novalidate>
    <h2 class="h3">${t("account.changePassword")}</h2>
    <div class="field"><label class="field-label" for="f-old">${t("account.currentPassword")}</label><input id="f-old" class="input" type="password" name="old" autocomplete="current-password" required></div>
    <div class="field"><label class="field-label" for="f-new">${t("account.newPassword")}</label><input id="f-new" class="input" type="password" name="new" autocomplete="new-password" required><p class="help">${t("auth.pwRules")}</p></div>
    <div class="field"><label class="field-label" for="f-new2">${t("auth.passwordConfirm")}</label><input id="f-new2" class="input" type="password" name="new2" autocomplete="new-password" required></div>
    <p class="field-error form-error" id="err-pw" role="alert" hidden></p>
    <div class="form-actions"><button type="submit" class="btn btn-primary">${icon("key")}${t("account.updatePassword")}</button></div>
  </form>
  <div class="card form-card">
    <h2 class="h3">${t("account.howProtected")}</h2>
    <ul class="check-list">
      <li>${icon("checkCircle")}<span>${t("account.prot1")}</span></li>
      <li>${icon("checkCircle")}<span>${t("account.prot2")}</span></li>
      <li>${icon("checkCircle")}<span>${t("account.prot3")}</span></li>
    </ul>
    <button type="button" class="btn btn-ghost" data-action="logout">${icon("logout")}${t("nav.logout")}</button>
  </div>`;
}

function dataTab(me) {
  return html`
  <div class="card form-card">
    <h2 class="h3">${icon("download")}${t("account.exportTitle")}</h2>
    <p>${t("account.exportText")}</p>
    <button type="button" class="btn btn-primary" data-action="export-data">${icon("download")}${t("account.exportBtn")}</button>
  </div>
  <div class="card form-card">
    <h2 class="h3">${icon("info")}${t("account.storedTitle")}</h2>
    <ul class="data-list">
      <li><strong>${t("account.storedProfile")}</strong><span>${me.email}</span></li>
      <li><strong>${t("account.storedListings")}</strong><span>${listingsByAuthor(me.id, { includeInactive: true }).length}</span></li>
      <li><strong>${t("account.storedFavorites")}</strong><span>${getFavorites().length}</span></li>
      <li><strong>${t("account.storedConversations")}</strong><span>${getConversations().length}</span></li>
    </ul>
    <p class="help">${t("account.storedWhere")}</p>
  </div>
  ${me.role !== "admin" ? html`<div class="card form-card danger-zone">
    <h2 class="h3">${icon("trash")}${t("account.deleteTitle")}</h2>
    <p>${t("account.deleteText")}</p>
    <button type="button" class="btn btn-danger" data-action="delete-account">${icon("trash")}${t("account.deleteBtn")}</button>
  </div>` : ""}`;
}

function prefsTab() {
  const prefs = getPrefs();
  const theme = prefs.theme || "system";
  return html`<form id="prefs-form" class="card form-card">
    <div class="field"><label class="field-label" for="f-lang">${t("account.language")}</label>
      <select id="f-lang" class="select" name="lang">${["fr", "de", "it", "en"].map((l) => html`<option value="${l}" ${getLang() === l ? raw("selected") : ""}>${t("lang." + l)}</option>`)}</select></div>
    <fieldset class="field"><legend class="field-label">${t("account.theme")}</legend>
      <div class="segmented">${["system", "light", "dark"].map((th) => html`<label class="seg-radio"><input type="radio" name="theme" value="${th}" ${theme === th ? raw("checked") : ""}><span>${icon(th === "dark" ? "moon" : th === "light" ? "sun" : "laptop")}${t("theme." + th)}</span></label>`)}</div>
    </fieldset>
    <label class="check"><input type="checkbox" name="banner" value="1" ${!prefs.bannerDismissed ? raw("checked") : ""}><span>${t("account.showDemoBanner")}</span></label>
  </form>`;
}

export default {
  title: () => t("meta.accountTitle"),
  refreshOn: ["auth", "listings", "profile"],

  render(ctx) {
    const me = currentUser();
    if (!me) {
      setTimeout(() => { location.hash = `#/connexion?next=${encodeURIComponent("#/compte")}`; }, 0);
      return html``;
    }
    const q = ctx.query.get("tab");
    tab = TABS.includes(q) ? q : tab;
    if (!TABS.includes(tab)) tab = "profile";
    const person = getPerson(me.id);
    const welcome = ctx.query.get("welcome") === "1";
    const content = { profile: profileTab, listings: listingsTab, security: securityTab, data: dataTab, prefs: prefsTab }[tab](me);
    return html`
    <section class="page-head">
      <div class="container account-head">
        ${avatar(person, "lg")}
        <div>
          <h1 class="h1">${t("account.hello", { name: me.firstname })}</h1>
          <p class="muted">${me.email} · ${t("trust.memberSince")} ${fmtDate(me.created, { month: "long", year: "numeric" })}${me.canton ? ` · ${cantonName(me.canton)}` : ""}</p>
        </div>
        ${isAdmin() ? html`<a class="btn btn-primary account-admin-btn" href="#/admin">${icon("shield")}${t("nav.admin")}</a>` : ""}
      </div>
    </section>
    <div class="container">
      ${welcome ? html`<div class="notice notice-success">${icon("sparkles")}<span>${t("account.welcomeNotice")}</span><a class="btn btn-primary btn-sm" href="#/publier">${t("nav.publish")}</a></div>` : ""}
      <div class="account-layout">
        <nav class="account-nav" aria-label="${t("account.sections")}">
          ${TABS.map((k) => html`<a class="account-nav-link${k === tab ? " is-active" : ""}" href="#/compte?tab=${k}" ${k === tab ? raw('aria-current="page"') : ""}>${icon(TAB_ICONS[k])}${t("account.tab." + k)}</a>`)}
          <button type="button" class="account-nav-link" data-action="logout">${icon("logout")}${t("nav.logout")}</button>
        </nav>
        <div class="account-content">${content}</div>
      </div>
    </div>`;
  },

  mount(root) {
    initLocalityFields(root);
    pendingPhoto = undefined;

    const profile = $("#profile-form", root);
    if (profile) {
      $("#photo-input", root).addEventListener("change", async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        try {
          pendingPhoto = await processImage(file, 400, 0.85);
          const me = currentUser();
          mount($("#profile-avatar"), avatar({ ...getPerson(me.id), photo: pendingPhoto }, "xl"));
          toast(t("account.photoReady"), "info");
        } catch (err) {
          toast(t(err.message === "too-large" ? "publish.photoTooLarge" : "publish.photoBadType"), "error");
        }
      });
      profile.addEventListener("submit", (e) => {
        e.preventDefault();
        const fd = new FormData(profile);
        const patch = {
          firstname: fd.get("firstname"),
          lastname: fd.get("lastname"),
          city: fd.get("city"),
          canton: fd.get("canton"),
          bio: fd.get("bio"),
          specialties: String(fd.get("specialties") || "").split(",").map((s) => s.trim()).filter(Boolean),
          languages: fd.getAll("languages"),
        };
        if (pendingPhoto !== undefined) patch.photo = pendingPhoto;
        const res = updateProfile(patch);
        toast(res.ok ? t("account.saved") : t("err.quota"), res.ok ? "success" : "error");
      });
    }

    const pwForm = $("#password-form", root);
    pwForm?.addEventListener("submit", async (e) => {
      e.preventDefault();
      const err = $("#err-pw");
      err.hidden = true;
      if (pwForm.new.value !== pwForm.new2.value) { err.textContent = t("err.mismatch"); err.hidden = false; return; }
      if (!passwordStrength(pwForm.new.value).ok) { err.textContent = t("err.weak"); err.hidden = false; return; }
      const btn = pwForm.querySelector("[type=submit]");
      btn.disabled = true;
      const res = await changePassword(pwForm.old.value, pwForm.new.value);
      btn.disabled = false;
      if (!res.ok) { err.textContent = t(res.error === "invalid" ? "err.wrongPassword" : "err.weak"); err.hidden = false; return; }
      pwForm.reset();
      toast(t("account.passwordChanged"), "success");
    });

    const prefs = $("#prefs-form", root);
    prefs?.addEventListener("change", (e) => {
      const el = e.target;
      if (el.name === "lang") { setLang(el.value); window.dispatchEvent(new Event("voisina:lang")); }
      if (el.name === "theme") { setPrefs({ theme: el.value === "system" ? null : el.value }); window.dispatchEvent(new Event("voisina:theme")); }
      if (el.name === "banner") { setPrefs({ bannerDismissed: !el.checked }); window.dispatchEvent(new Event("voisina:banner")); }
      toast(t("account.saved"), "success");
    });
  },
};

export const accountActions = {
  "remove-avatar": () => {
    pendingPhoto = "";
    const me = currentUser();
    mount($("#profile-avatar"), avatar({ ...getPerson(me.id), photo: "" }, "xl"));
  },
  logout: () => {
    logout();
    toast(t("auth.loggedOut"), "success");
    location.hash = "#/";
  },
  "export-data": () => {
    const data = exportMyData();
    if (!data) return;
    downloadFile(`voisina-mes-donnees-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(data, null, 2), "application/json");
    toast(t("account.exported"), "success");
  },
  "delete-account": async () => {
    const result = await openDialog({
      title: t("account.deleteTitle"),
      size: "dialog-sm",
      body: html`<p class="dialog-text">${t("account.deleteConfirmText")}</p>
        <div class="field"><label class="field-label" for="f-del-pw">${t("auth.password")}</label><input id="f-del-pw" class="input" type="password" name="password" autocomplete="current-password" required></div>
        <p class="field-error" id="err-del" role="alert" hidden></p>`,
      footer: html`<button type="button" class="btn btn-ghost" data-dialog-close>${t("common.cancel")}</button><button type="submit" class="btn btn-danger">${icon("trash")}${t("account.deleteBtn")}</button>`,
      onSubmit: async (form) => {
        const res = await deleteAccount(form.password.value);
        if (!res.ok) {
          const err = form.querySelector("#err-del");
          err.textContent = t("err.wrongPassword");
          err.hidden = false;
          return false;
        }
        return true;
      },
    });
    if (result) {
      toast(t("account.deleted"), "success");
      location.hash = "#/";
    }
  },
};

export { safeImageSrc, listingCard };
