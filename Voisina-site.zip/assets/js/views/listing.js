/* Page de détail d'une annonce */
import { html, raw, $, safeImageSrc } from "../util.js";
import { icon } from "../icons.js";
import { t, pick, getLang, cantonName, categoryName, fmtDate, fmtRelative, fmtDuration, fmtDistance, languageName } from "../i18n.js";
import { getCategory } from "../data.js";
import { getListing, getPerson, currentUser, isFavorite, searchListings, getOrigin, startConversation, setListingStatus, deleteListing, setListingHidden, isAdmin, toggleBlock, isBlocked } from "../store.js";
import { listingCard, avatar, priceLabel, typeLabel, emptyState, stars, confirmDialog, reportDialog, shareLink, toast, listingTitle, listingDescription, categoryThumb } from "../ui.js";
import { detailMap } from "../map.js";
import { downloadIcs } from "../ics.js";
import { distanceKm } from "../util.js";

let map = null;
let currentId = null;

function notFound() {
  return html`<section class="section"><div class="container narrow">
    ${emptyState({ iconName: "search", title: t("listing.notFoundTitle"), text: t("listing.notFoundText"), action: html`<a class="btn btn-primary" href="#/explorer">${t("listing.backToExplore")}</a>` })}
  </div></section>`;
}

function fact(iconName, label, value) {
  return html`<div class="fact"><span class="fact-icon">${icon(iconName)}</span><div><dt>${label}</dt><dd>${value}</dd></div></div>`;
}

function gallery(l) {
  const photos = (l.photos || []).map(safeImageSrc).filter(Boolean);
  if (!photos.length) return categoryThumb(l, "detail-media");
  return html`<div class="gallery">
    <img class="gallery-main" id="gallery-main" src="${photos[0]}" alt="${listingTitle(l)}">
    ${photos.length > 1 ? html`<div class="gallery-thumbs">${photos.map((p, i) => html`<button type="button" class="gallery-thumb${i === 0 ? " is-active" : ""}" data-action="gallery" data-index="${i}" aria-label="${t("listing.photoN", { n: i + 1 })}"><img src="${p}" alt=""></button>`)}</div>` : ""}
  </div>`;
}

export default {
  title: (ctx) => {
    const l = getListing(ctx.params[0]);
    return l ? listingTitle(l) : t("listing.notFoundTitle");
  },
  refreshOn: ["listings", "auth", "block"],

  render(ctx) {
    const id = ctx.params[0];
    currentId = id;
    const l = getListing(id);
    const me = currentUser();
    const owner = me && l && l.authorId === me.id;
    const admin = isAdmin();
    if (!l || (l.status === "hidden" && !admin && !owner) || (isBlocked(l?.authorId) && !admin)) return notFound();

    const author = getPerson(l.authorId);
    const cat = getCategory(l.category);
    const fav = isFavorite(l.id);
    const origin = getOrigin();
    const dist = origin ? distanceKm(origin, l) : null;
    const similar = searchListings({ cat: l.category }, { lat: l.lat, lng: l.lng })
      .filter((r) => r.listing.id !== l.id && r.listing.authorId !== l.authorId)
      .sort((a, b) => a.distance - b.distance)
      .filter((r, i, arr) => arr.findIndex((x) => listingTitle(x.listing) === listingTitle(r.listing)) === i && listingTitle(r.listing) !== listingTitle(l))
      .slice(0, 4);
    const sourceLang = l.demo ? null : l.lang;
    const showTranslate = sourceLang && sourceLang !== getLang();
    const text = listingDescription(l);
    const deeplUrl = showTranslate ? `https://www.deepl.com/translator#${sourceLang}/${getLang() === "en" ? "en" : getLang()}/${encodeURIComponent((listingTitle(l) + "\n\n" + text).slice(0, 1500))}` : "";

    return html`
    <div class="container">
      <nav class="breadcrumb" aria-label="${t("common.breadcrumb")}">
        <a href="#/explorer">${t("nav.explore")}</a>${icon("chevronRight")}
        <a href="#/explorer?cat=${l.category}">${categoryName(l.category)}</a>${icon("chevronRight")}
        <span aria-current="page">${listingTitle(l)}</span>
      </nav>

      ${l.status === "hidden" ? html`<div class="notice notice-danger">${icon("eyeOff")}${t("listing.hiddenNotice")}</div>` : ""}
      ${l.status === "done" ? html`<div class="notice">${icon("checkCircle")}${t("listing.doneNotice")}</div>` : ""}

      <div class="detail-layout">
        <article class="detail-main">
          ${gallery(l)}
          <div class="detail-chips">
            <span class="chip chip-type type-${l.type}">${typeLabel(l.type)}</span>
            <span class="chip">${icon(cat.icon)}${categoryName(l.category)}</span>
            ${l.urgent ? html`<span class="chip chip-urgent">${icon("zap")}${t("listing.urgent")}</span>` : ""}
            ${l.demo ? html`<span class="chip chip-muted" title="${t("demo.chipTitle")}">${icon("info")}${t("demo.chip")}</span>` : ""}
          </div>
          <h1 class="h1 detail-title">${listingTitle(l)}</h1>
          <p class="detail-sub">${icon("pin")}${l.npa ? `${l.npa} ` : ""}${l.city}, ${cantonName(l.canton)}${dist !== null ? html` · <strong>${fmtDistance(dist)}</strong>` : ""} · ${t("listing.published", { when: fmtRelative(l.created) })}</p>

          <dl class="facts">
            ${fact("calendar", t("listing.date"), l.date ? fmtDate(l.date + "T12:00:00", { weekday: "long", day: "numeric", month: "long" }) : t("listing.flexibleDate"))}
            ${fact("clock", t("listing.time"), l.time ? `${l.time} · ${fmtDuration(l.duration)}` : fmtDuration(l.duration))}
            ${fact("repeat", t("listing.recurrence"), t("recurrence." + (l.recurrence || "once")))}
            ${fact("coins", t("listing.payment"), priceLabel(l))}
            ${l.languages?.length ? fact("languages", t("listing.languages"), l.languages.map(languageName).join(", ")) : ""}
          </dl>

          <section class="detail-section">
            <h2 class="h3">${t("listing.description")}</h2>
            <p class="prose-text">${text}</p>
            ${showTranslate ? html`<p class="translate-note">${icon("languages")}${t("listing.writtenIn", { lang: languageName(sourceLang) })} · <a href="${deeplUrl}" target="_blank" rel="noopener noreferrer">${t("listing.translate")}</a></p>` : ""}
          </section>

          <section class="detail-section">
            <h2 class="h3">${t("listing.where")}</h2>
            <div id="detail-map" class="map map-detail" role="region" aria-label="${t("listing.mapLabel")}"></div>
            <p class="map-note">${icon("shield")}${t("listing.approxLocation")}</p>
          </section>

          <aside class="safety-box">
            <h2 class="h4">${icon("shieldCheck")}${t("safety.boxTitle")}</h2>
            <ul>
              <li>${t("safety.tip1")}</li>
              <li>${t("safety.tip2")}</li>
              <li>${t("safety.tip3")}</li>
            </ul>
            <a href="#/page/securite">${t("safety.more")}</a>
          </aside>
        </article>

        <aside class="detail-side">
          <div class="side-card price-card">
            <div class="price-big${l.payment === "free" ? " is-free" : ""}">${priceLabel(l)}</div>
            ${l.payment === "paid" && l.unit === "total" ? html`<p class="muted small">${t("listing.totalHint")}</p>` : ""}
            <div class="side-actions">
              ${owner
                ? html`<a class="btn btn-primary btn-block" href="#/publier?edit=${l.id}">${icon("pencil")}${t("listing.edit")}</a>
                  <button type="button" class="btn btn-ghost btn-block" data-action="listing-status" data-id="${l.id}" data-status="${l.status === "done" ? "active" : "done"}">${icon(l.status === "done" ? "refresh" : "checkCircle")}${l.status === "done" ? t("listing.reactivate") : t("listing.markDone")}</button>
                  <button type="button" class="btn btn-danger-ghost btn-block" data-action="listing-delete" data-id="${l.id}">${icon("trash")}${t("listing.delete")}</button>`
                : html`<button type="button" class="btn btn-primary btn-block btn-lg" data-action="contact" data-id="${l.id}" ${l.status !== "active" ? raw("disabled") : ""}>${icon("message")}${t("listing.contact")}</button>`}
              <div class="side-row">
                <button type="button" class="btn btn-ghost fav-toggle${fav ? " is-active" : ""}" data-action="fav" data-id="${l.id}" aria-pressed="${fav ? "true" : "false"}">${icon("heart")}<span>${fav ? t("fav.saved") : t("fav.save")}</span></button>
                <button type="button" class="btn btn-ghost" data-action="share" data-id="${l.id}">${icon("share")}<span>${t("listing.share")}</span></button>
              </div>
              ${l.date ? html`<button type="button" class="btn btn-ghost btn-block" data-action="ics" data-id="${l.id}">${icon("calendar")}${t("listing.addToCalendar")}</button>` : ""}
            </div>
          </div>

          <div class="side-card author-card">
            <div class="author-head">
              ${avatar(author, "lg")}
              <div>
                <a class="author-name" href="#/membre/${l.authorId}">${author?.name || t("common.formerMember")}</a>
                ${author?.verified ? html`<span class="badge badge-verified">${icon("badgeCheck")}${t("trust.verified")}</span>` : html`<span class="badge">${t("trust.notVerified")}</span>`}
                <div class="muted small">${icon("pin")}${author?.city || l.city}</div>
              </div>
            </div>
            <dl class="author-stats">
              <div><dt>${t("trust.rating")}</dt><dd>${stars(author?.rating)}</dd></div>
              <div><dt>${t("trust.reviews")}</dt><dd>${author?.reviews ?? 0}</dd></div>
              <div><dt>${t("trust.completed")}</dt><dd>${author?.completed ?? 0}</dd></div>
              <div><dt>${t("trust.memberSince")}</dt><dd>${author?.created ? fmtDate(author.created, { month: "short", year: "numeric" }) : "—"}</dd></div>
            </dl>
            <a class="btn btn-ghost btn-block" href="#/membre/${l.authorId}">${icon("user")}${t("trust.viewProfile")}</a>
          </div>

          ${!owner ? html`<div class="side-links">
            <button type="button" class="link-btn danger" data-action="report" data-type="listing" data-id="${l.id}">${icon("flag")}${t("report.listing")}</button>
            ${me ? html`<button type="button" class="link-btn" data-action="block" data-id="${l.authorId}">${icon("ban")}${t("block.user")}</button>` : ""}
          </div>` : ""}

          ${admin ? html`<div class="side-card admin-card">
            <h2 class="h4">${icon("shield")}${t("admin.moderation")}</h2>
            <button type="button" class="btn ${l.status === "hidden" ? "btn-primary" : "btn-danger"} btn-block" data-action="admin-hide" data-id="${l.id}" data-hidden="${l.status === "hidden" ? "0" : "1"}">${icon(l.status === "hidden" ? "eye" : "eyeOff")}${l.status === "hidden" ? t("admin.unhide") : t("admin.hide")}</button>
          </div>` : ""}
        </aside>
      </div>

      ${similar.length ? html`<section class="section-sm">
        <h2 class="h2">${t("listing.similar")}</h2>
        <div class="listing-grid">${similar.map(({ listing, distance }) => listingCard(listing, { distance }))}</div>
      </section>` : ""}
    </div>`;
  },

  mount(root) {
    const l = getListing(currentId);
    const el = $("#detail-map", root);
    if (l && el) map = detailMap(el, l);
  },

  onData(kind) {
    if (kind === "favorites") {
      const fav = isFavorite(currentId);
      document.querySelectorAll(`[data-action="fav"][data-id="${currentId}"]`).forEach((b) => {
        b.classList.toggle("is-active", fav);
        b.setAttribute("aria-pressed", fav ? "true" : "false");
        const span = b.querySelector("span");
        if (span) span.textContent = fav ? t("fav.saved") : t("fav.save");
      });
    }
  },

  unmount() {
    map?.remove();
    map = null;
  },
};

/* Actions propres à cette page */
export const listingActions = {
  contact: (el) => {
    const me = currentUser();
    if (!me) {
      toast(t("auth.loginToContact"), "info");
      location.hash = `#/connexion?next=${encodeURIComponent("#/annonce/" + el.dataset.id)}`;
      return;
    }
    const conv = startConversation(el.dataset.id);
    if (conv) location.hash = `#/messages/${conv.id}`;
  },
  share: (el) => {
    const l = getListing(el.dataset.id);
    if (l) shareLink(`${location.href.split("#")[0]}#/annonce/${l.id}`, listingTitle(l));
  },
  ics: (el) => {
    const l = getListing(el.dataset.id);
    if (l) { downloadIcs([l], `voisina-${l.id}.ics`); toast(t("calendar.icsDone"), "success"); }
  },
  report: (el) => reportDialog(el.dataset.type, el.dataset.id),
  block: async (el) => {
    const person = getPerson(el.dataset.id);
    const blocking = !isBlocked(el.dataset.id);
    if (blocking && !(await confirmDialog({ title: t("block.confirmTitle", { name: person?.name || "" }), text: t("block.confirmText"), confirm: t("block.confirm"), danger: true }))) return;
    const now = toggleBlock(el.dataset.id);
    toast(now ? t("block.done") : t("block.undone"), "success");
    if (now && location.hash.startsWith("#/annonce/")) location.hash = "#/explorer";
  },
  "listing-status": (el) => {
    if (setListingStatus(el.dataset.id, el.dataset.status)) toast(el.dataset.status === "done" ? t("listing.markedDone") : t("listing.reactivated"), "success");
  },
  "listing-delete": async (el) => {
    if (!(await confirmDialog({ title: t("listing.deleteTitle"), text: t("listing.deleteText"), confirm: t("listing.delete"), danger: true }))) return;
    if (deleteListing(el.dataset.id)) {
      toast(t("listing.deleted"), "success");
      if (location.hash.startsWith("#/annonce/")) location.hash = "#/compte?tab=listings";
    }
  },
  "admin-hide": (el) => {
    const hide = el.dataset.hidden === "1";
    if (setListingHidden(el.dataset.id, hide)) toast(hide ? t("admin.hidden") : t("admin.unhidden"), "success");
  },
  gallery: (el) => {
    const l = getListing(currentId);
    const photo = safeImageSrc(l?.photos?.[Number(el.dataset.index)]);
    if (photo) {
      $("#gallery-main").src = photo;
      document.querySelectorAll(".gallery-thumb").forEach((b) => b.classList.toggle("is-active", b === el));
    }
  },
};

export { pick };
