/* Profil public d'un membre */
import { html } from "../util.js";
import { icon } from "../icons.js";
import { t, fmtDate, cantonName, languageName } from "../i18n.js";
import { getPerson, listingsByAuthor, currentUser, isBlocked } from "../store.js";
import { avatar, listingCard, emptyState, stars } from "../ui.js";

export default {
  title: (ctx) => getPerson(ctx.params[0])?.name || t("profile.notFound"),
  refreshOn: ["listings", "block", "profile", "auth"],

  render(ctx) {
    const id = ctx.params[0];
    const p = getPerson(id);
    const me = currentUser();
    if (!p) {
      return html`<section class="section"><div class="container narrow">${emptyState({ iconName: "user", title: t("profile.notFound"), action: html`<a class="btn btn-primary" href="#/explorer">${t("listing.backToExplore")}</a>` })}</div></section>`;
    }
    const listings = listingsByAuthor(id);
    const isMe = me?.id === id;
    const blocked = isBlocked(id);
    return html`
    <section class="page-head profile-head">
      <div class="container profile-hero">
        ${avatar(p, "xl")}
        <div class="profile-hero-info">
          <h1 class="h1">${p.name}</h1>
          <div class="profile-badges">
            ${p.role === "admin" ? html`<span class="badge badge-verified">${icon("shield")}${t("profile.team")}</span>` : ""}
            ${p.verified ? html`<span class="badge badge-verified">${icon("badgeCheck")}${t("trust.verified")}</span>` : html`<span class="badge">${t("trust.notVerified")}</span>`}
            ${p.demo ? html`<span class="badge badge-muted">${icon("info")}${t("demo.member")}</span>` : ""}
          </div>
          <p class="muted">${icon("pin")}${p.city || "—"}${p.canton ? `, ${cantonName(p.canton)}` : ""} · ${t("trust.memberSince")} ${p.created ? fmtDate(p.created, { month: "long", year: "numeric" }) : "—"}</p>
        </div>
        <div class="profile-actions">
          ${isMe ? html`<a class="btn btn-primary" href="#/compte">${icon("pencil")}${t("profile.edit")}</a>` : html`
            <button type="button" class="btn btn-ghost" data-action="report" data-type="user" data-id="${id}">${icon("flag")}${t("report.user")}</button>
            ${me ? html`<button type="button" class="btn btn-ghost" data-action="block" data-id="${id}">${icon("ban")}${blocked ? t("block.unblock") : t("block.user")}</button>` : ""}`}
        </div>
      </div>
    </section>
    <div class="container profile-layout">
      <aside class="profile-side">
        <div class="card">
          <dl class="author-stats author-stats-lg">
            <div><dt>${t("trust.rating")}</dt><dd>${stars(p.rating)}</dd></div>
            <div><dt>${t("trust.reviews")}</dt><dd>${p.reviews ?? 0}</dd></div>
            <div><dt>${t("trust.completed")}</dt><dd>${p.completed ?? 0}</dd></div>
            <div><dt>${t("profile.activeListings")}</dt><dd>${listings.length}</dd></div>
          </dl>
        </div>
        ${p.bio ? html`<div class="card"><h2 class="h4">${t("profile.about")}</h2><p class="prose-text">${p.bio}</p></div>` : ""}
        ${p.languages?.length ? html`<div class="card"><h2 class="h4">${icon("languages")}${t("account.languages")}</h2><div class="tag-list">${p.languages.map((l) => html`<span class="tag">${languageName(l)}</span>`)}</div></div>` : ""}
        ${p.specialties?.length ? html`<div class="card"><h2 class="h4">${icon("sparkles")}${t("account.specialties")}</h2><div class="tag-list">${p.specialties.map((s) => html`<span class="tag">${s}</span>`)}</div></div>` : ""}
        <p class="help">${icon("shield")}${t("profile.privacy")}</p>
      </aside>
      <section>
        <h2 class="h3">${t("profile.listingsBy", { name: p.firstname })}</h2>
        ${listings.length ? html`<div class="listing-grid listing-grid-compact">${listings.map((l) => listingCard(l))}</div>` : html`<p class="muted">${t("profile.noListings")}</p>`}
      </section>
    </div>`;
  },
};
