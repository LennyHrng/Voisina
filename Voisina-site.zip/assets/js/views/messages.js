/* Messagerie */
import { html, raw, $, mount, detectSensitive } from "../util.js";
import { icon } from "../icons.js";
import { t, fmtTime, fmtDate, fmtRelative } from "../i18n.js";
import { currentUser, getConversations, getConversation, otherParticipant, getPerson, getListing, unreadCount, sendMessage, markConversationRead, typing, deleteConversation } from "../store.js";
import { avatar, emptyState, listingTitle, confirmDialog, reportDialog, toast } from "../ui.js";
import { getDemoData } from "../seed.js";

let activeId = null;

function convItem(c) {
  const other = getPerson(otherParticipant(c));
  const listing = getListing(c.listingId);
  const last = c.messages[c.messages.length - 1];
  const unread = unreadCount(c);
  const me = currentUser();
  return html`<a class="conv-item${c.id === activeId ? " is-active" : ""}${unread ? " is-unread" : ""}" href="#/messages/${c.id}" ${c.id === activeId ? raw('aria-current="true"') : ""}>
    ${avatar(other, "md")}
    <span class="conv-body">
      <span class="conv-top"><strong>${other?.name || t("common.formerMember")}</strong><span class="conv-time">${last ? fmtRelative(last.at) : ""}</span></span>
      <span class="conv-listing">${listing ? listingTitle(listing) : t("messages.listingGone")}</span>
      <span class="conv-preview">${last ? (last.from === me?.id ? t("messages.you") + " " : "") + last.text : t("messages.noMessagesYet")}</span>
    </span>
    ${unread ? html`<span class="badge-count" aria-label="${t("messages.unread", { count: unread })}">${unread}</span>` : ""}
  </a>`;
}

function listPane() {
  const convs = getConversations();
  if (!convs.length) {
    return emptyState({ iconName: "message", title: t("messages.emptyTitle"), text: t("messages.emptyText"), action: html`<a class="btn btn-primary" href="#/explorer">${t("messages.findListing")}</a>` });
  }
  return html`${convs.map(convItem)}`;
}

function messagesPane(c) {
  const me = currentUser();
  const otherId = otherParticipant(c);
  const other = getPerson(otherId);
  let lastDay = "";
  const items = [];
  for (const m of c.messages) {
    const day = new Date(m.at).toDateString();
    if (day !== lastDay) {
      lastDay = day;
      items.push(html`<div class="chat-day"><span>${fmtDate(m.at, { weekday: "long", day: "numeric", month: "long" })}</span></div>`);
    }
    const mine = m.from === me.id;
    items.push(html`<div class="bubble-row${mine ? " is-mine" : ""}">
      ${!mine ? avatar(other, "xs") : ""}
      <div class="bubble"><p>${m.text}</p><span class="bubble-time">${fmtTime(m.at)}${mine ? html` ${icon("check")}` : ""}</span></div>
    </div>`);
  }
  if (typing.has(c.id)) items.push(html`<div class="bubble-row">${avatar(other, "xs")}<div class="bubble typing" aria-label="${t("messages.typing", { name: other?.name || "" })}"><span></span><span></span><span></span></div></div>`);
  return html`
    <div class="chat-safety">${icon("shieldCheck")}<span>${t("messages.safetyBanner")}</span> <a href="#/page/securite">${t("safety.more")}</a></div>
    ${!c.messages.length ? html`<p class="chat-hint">${t("messages.firstHint")}</p>` : ""}
    ${items}`;
}

function chatPane(c) {
  const otherId = otherParticipant(c);
  const other = getPerson(otherId);
  const listing = getListing(c.listingId);
  const demo = getDemoData().authorsById.has(otherId);
  return html`
  <header class="chat-head">
    <a class="icon-btn chat-back" href="#/messages" aria-label="${t("common.back")}">${icon("arrowLeft")}</a>
    ${avatar(other, "md")}
    <div class="chat-head-info">
      <a class="chat-name" href="#/membre/${otherId}">${other?.name || t("common.formerMember")}</a>
      ${listing ? html`<a class="chat-listing" href="#/annonce/${listing.id}">${icon("file")}${listingTitle(listing)}</a>` : ""}
    </div>
    <div class="chat-head-actions">
      <button type="button" class="icon-btn" data-action="report" data-type="conversation" data-id="${c.id}" aria-label="${t("report.conversation")}" title="${t("report.conversation")}">${icon("flag")}</button>
      <button type="button" class="icon-btn" data-action="block" data-id="${otherId}" aria-label="${t("block.user")}" title="${t("block.user")}">${icon("ban")}</button>
      <button type="button" class="icon-btn" data-action="delete-conv" data-id="${c.id}" aria-label="${t("messages.delete")}" title="${t("messages.delete")}">${icon("trash")}</button>
    </div>
  </header>
  ${demo ? html`<p class="chat-demo">${icon("info")}${t("messages.demoNotice")}</p>` : ""}
  <div class="chat-messages" id="chat-messages" aria-live="polite">${messagesPane(c)}</div>
  <form class="chat-composer" id="chat-composer" data-id="${c.id}">
    <div id="composer-warning" class="composer-warning" hidden></div>
    <div class="composer-row">
      <label for="chat-input" class="sr-only">${t("messages.placeholder")}</label>
      <textarea id="chat-input" class="input" name="text" rows="1" maxlength="1000" placeholder="${t("messages.placeholder")}" autocomplete="off"></textarea>
      <button type="submit" class="btn btn-primary btn-send" aria-label="${t("messages.send")}">${icon("send")}</button>
    </div>
  </form>`;
}

export default {
  title: () => t("meta.messagesTitle"),
  refreshOn: ["auth", "block"],

  render(ctx) {
    const me = currentUser();
    if (!me) {
      return html`<section class="section"><div class="container narrow">${emptyState({
        iconName: "message", title: t("messages.gateTitle"), text: t("messages.gateText"),
        action: html`<div class="empty-actions"><a class="btn btn-primary" href="#/connexion?next=${encodeURIComponent("#/messages")}">${t("auth.login")}</a><a class="btn btn-ghost" href="#/connexion?mode=register&next=${encodeURIComponent("#/messages")}">${t("auth.createAccount")}</a></div>`,
      })}</div></section>`;
    }
    activeId = ctx.params[0] || null;
    const conv = activeId ? getConversation(activeId) : null;
    if (activeId && !conv) activeId = null;
    if (conv) markConversationRead(conv.id);

    return html`
    <div class="container messages-wrap">
      <h1 class="h1 messages-title">${t("messages.title")}</h1>
      <div class="messages-app${conv ? " has-active" : ""}">
        <nav class="conv-list" id="conv-list" aria-label="${t("messages.conversations")}">${listPane()}</nav>
        <section class="chat" id="chat">
          ${conv ? chatPane(conv) : html`<div class="chat-empty">${icon("message")}<p>${t("messages.selectConv")}</p></div>`}
        </section>
      </div>
    </div>`;
  },

  mount(root) {
    const msgs = $("#chat-messages", root);
    if (msgs) msgs.scrollTop = msgs.scrollHeight;
    const form = $("#chat-composer", root);
    if (!form) return;
    const input = $("#chat-input", form);
    const warn = $("#composer-warning", form);
    const autosize = () => {
      input.style.height = "auto";
      input.style.height = Math.min(160, input.scrollHeight) + "px";
      const found = detectSensitive(input.value);
      if (found.length) {
        mount(warn, html`${icon("alert")}<span>${t("safety.sensitive." + (found.includes("scam") ? "scam" : found.includes("iban") ? "iban" : "contactChat"))}</span>`);
        warn.hidden = false;
      } else warn.hidden = true;
    };
    input.addEventListener("input", autosize);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        form.requestSubmit();
      }
    });
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const text = input.value.trim();
      if (!text) return;
      const res = sendMessage(form.dataset.id, text);
      if (res.ok) {
        input.value = "";
        autosize();
      } else toast(t("err.generic"), "error");
    });
    if (window.matchMedia("(min-width: 900px)").matches) input.focus({ preventScroll: true });
  },

  onData(kind) {
    if (!["messages", "typing", "read"].includes(kind) || !currentUser()) return;
    const list = $("#conv-list");
    if (list) mount(list, listPane());
    const conv = activeId ? getConversation(activeId) : null;
    const msgs = $("#chat-messages");
    if (conv && msgs) {
      if (kind === "messages") markConversationRead(conv.id);
      mount(msgs, messagesPane(conv));
      msgs.scrollTop = msgs.scrollHeight;
    }
  },

  unmount() { activeId = null; },
};

export const messagesActions = {
  "delete-conv": async (el) => {
    if (!(await confirmDialog({ title: t("messages.deleteTitle"), text: t("messages.deleteText"), confirm: t("messages.delete"), danger: true }))) return;
    deleteConversation(el.dataset.id);
    toast(t("messages.deleted"), "success");
    location.hash = "#/messages";
  },
};

export { reportDialog };
