/* Export vers les agendas (Google Agenda, Apple Calendrier, Outlook…)
   au format standard iCalendar (.ics — norme RFC 5545). */
import { downloadFile } from "./util.js";
import { pick } from "./i18n.js";

const TZ = `BEGIN:VTIMEZONE
TZID:Europe/Zurich
BEGIN:DAYLIGHT
TZOFFSETFROM:+0100
TZOFFSETTO:+0200
TZNAME:CEST
DTSTART:19810329T020000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU
END:DAYLIGHT
BEGIN:STANDARD
TZOFFSETFROM:+0200
TZOFFSETTO:+0100
TZNAME:CET
DTSTART:19961027T030000
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU
END:STANDARD
END:VTIMEZONE`;

/** Échappement des caractères spéciaux du format .ics */
const escText = (s) => String(s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");

/** Les lignes .ics ne doivent pas dépasser 75 octets. */
function fold(line) {
  const out = [];
  let current = "";
  for (const ch of line) {
    if (new TextEncoder().encode(current + ch).length > 74) {
      out.push(current);
      current = " " + ch;
    } else current += ch;
  }
  out.push(current);
  return out.join("\r\n");
}

const stamp = (d) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");

function eventFor(listing, baseUrl) {
  if (!listing.date) return null;
  const [y, m, d] = listing.date.split("-");
  const [hh, mm] = (listing.time || "09:00").split(":");
  const start = new Date(Number(y), Number(m) - 1, Number(d), Number(hh), Number(mm));
  const end = new Date(start.getTime() + (listing.duration || 60) * 60000);
  const local = (dt) => `${dt.getFullYear()}${String(dt.getMonth() + 1).padStart(2, "0")}${String(dt.getDate()).padStart(2, "0")}T${String(dt.getHours()).padStart(2, "0")}${String(dt.getMinutes()).padStart(2, "0")}00`;
  const lines = [
    "BEGIN:VEVENT",
    `UID:${listing.id}@voisina.ch`,
    `DTSTAMP:${stamp(new Date())}`,
    listing.time ? `DTSTART;TZID=Europe/Zurich:${local(start)}` : `DTSTART;VALUE=DATE:${y}${m}${d}`,
    listing.time ? `DTEND;TZID=Europe/Zurich:${local(end)}` : null,
    listing.recurrence === "weekly" ? "RRULE:FREQ=WEEKLY;COUNT=8" : listing.recurrence === "monthly" ? "RRULE:FREQ=MONTHLY;COUNT=6" : null,
    `SUMMARY:${escText("Voisina · " + pick(listing.title))}`,
    `DESCRIPTION:${escText(pick(listing.description) + "\n\n" + baseUrl + "#/annonce/" + listing.id)}`,
    `LOCATION:${escText(`${listing.npa ? listing.npa + " " : ""}${listing.city} (${listing.canton})`)}`,
    `URL:${baseUrl}#/annonce/${listing.id}`,
    "END:VEVENT",
  ].filter(Boolean);
  return lines.map(fold).join("\r\n");
}

export function buildIcs(listings) {
  const base = location.href.split("#")[0];
  const events = listings.map((l) => eventFor(l, base)).filter(Boolean);
  return ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Voisina//Entraide locale//FR", "CALSCALE:GREGORIAN", "METHOD:PUBLISH", "X-WR-CALNAME:Voisina", TZ.replace(/\n/g, "\r\n"), ...events, "END:VCALENDAR"].join("\r\n") + "\r\n";
}

export function downloadIcs(listings, filename = "voisina.ics") {
  const content = buildIcs(listings);
  downloadFile(filename, content, "text/calendar;charset=utf-8");
}
