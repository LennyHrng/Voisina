/* =====================================================================
   COUCHE DE DONNÉES
   ---------------------------------------------------------------------
   C'est le SEUL fichier qui lit/écrit les données. Les pages passent
   toujours par ces fonctions. Pour brancher un vrai serveur plus tard
   (ex. Supabase), il suffira de réécrire ce fichier (voir docs/).

   Toutes les données saisies sont VALIDÉES et NETTOYÉES ici, même si le
   formulaire les a déjà vérifiées (principe : ne jamais faire confiance
   aux données reçues).
   ===================================================================== */
import { storage, uid, safeImageSrc, distanceKm, parseDateKey, todayKey } from "./util.js";
import { getDemoData } from "./seed.js";
import { CANTON_CODES, CATEGORY_IDS, TYPES, PAYMENTS, UNITS, DURATIONS, RECURRENCES, LANGS, LOCALITIES } from "./data.js";
import { ADMIN_ACCOUNT, hashPassword, verifyPassword, createSession, readSession, destroySession, loginLock, registerFailure, resetFailures, isValidEmail, passwordStrength } from "./auth.js";
import { t, getLang, categoryName } from "./i18n.js";

/* ------------------------- Abonnements -------------------------- */
const listeners = new Set();
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit(kind = "data") { listeners.forEach((fn) => { try { fn(kind); } catch (e) { console.error(e); } }); }

/* ------------------------- Nettoyage ---------------------------- */
/** Supprime les caractères de contrôle et limite la longueur. */
export function cleanText(value, max = 500, multiline = false) {
  let s = String(value ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​-‏‪-‮]/g, "");
  s = multiline ? s.replace(/\r\n?/g, "\n").replace(/\n{3,}/g, "\n\n") : s.replace(/\s+/g, " ");
  return s.trim().slice(0, max);
}

const inSwitzerland = (lat, lng) => Number.isFinite(lat) && Number.isFinite(lng) && lat > 45.7 && lat < 47.95 && lng > 5.8 && lng < 10.6;

/* ============================ UTILISATEURS ============================ */
const getStoredUsers = () => {
  const users = storage.get("users", []);
  return Array.isArray(users) ? users : [];
};
const saveUsers = (users) => storage.set("users", users);

function findUserRecord(id) {
  if (id === ADMIN_ACCOUNT.id) {
    const override = storage.get("adminProfile", {});
    return { ...ADMIN_ACCOUNT, ...override, password: ADMIN_ACCOUNT.password };
  }
  return getStoredUsers().find((u) => u.id === id) || null;
}

/** Utilisateur connecté (sans son empreinte de mot de passe). */
export function currentUser() {
  const session = readSession();
  if (!session) return null;
  const user = findUserRecord(session.userId);
  if (!user) { destroySession(); return null; }
  const { password, ...safe } = user;
  return safe;
}

export const isAdmin = () => currentUser()?.role === "admin";

/** Nom affiché publiquement : prénom + initiale (protection de la vie privée). */
export function displayName(person) {
  if (!person) return t("common.formerMember");
  const initial = person.lastname ? ` ${person.lastname.trim()[0].toUpperCase()}.` : "";
  return `${person.firstname}${initial}`;
}

/** Profil public d'une personne (membre démo, membre local ou admin). */
export function getPerson(id) {
  const demo = getDemoData().authorsById.get(id);
  if (demo) return { ...demo, name: displayName(demo) };
  const user = findUserRecord(id);
  if (!user) return null;
  const listings = allListingsRaw().filter((l) => l.authorId === id);
  return {
    id: user.id,
    demo: false,
    firstname: user.firstname,
    lastname: user.lastname,
    name: displayName(user),
    city: user.city,
    canton: user.canton,
    verified: !!user.verified,
    role: user.role || "user",
    rating: null,
    reviews: 0,
    completed: listings.filter((l) => l.status === "done").length,
    created: user.created,
    specialties: user.specialties || [],
    languages: user.languages || [],
    bio: user.bio || "",
    photo: safeImageSrc(user.photo),
  };
}

export async function register(input) {
  const firstname = cleanText(input.firstname, 40);
  const lastname = cleanText(input.lastname, 40);
  const email = cleanText(input.email, 120).toLowerCase();
  const errors = {};
  if (firstname.length < 2) errors.firstname = "required";
  if (lastname.length < 2) errors.lastname = "required";
  if (!isValidEmail(email)) errors.email = "email";
  if (email === ADMIN_ACCOUNT.email || email === "admin" || getStoredUsers().some((u) => u.email === email)) errors.email = "taken";
  const strength = passwordStrength(input.password, [firstname, lastname, email.split("@")[0]]);
  if (!strength.ok) errors.password = "weak";
  if (input.password !== input.passwordConfirm) errors.passwordConfirm = "mismatch";
  const loc = LOCALITIES.find((l) => l.name === input.city) || null;
  const canton = CANTON_CODES.includes(input.canton) ? input.canton : loc?.canton;
  if (!canton) errors.city = "required";
  if (!input.terms) errors.terms = "required";
  if (Object.keys(errors).length) return { ok: false, errors };

  const user = {
    id: uid("u_"),
    email,
    firstname,
    lastname,
    city: cleanText(input.city, 60),
    canton,
    languages: [getLang()],
    specialties: [],
    bio: "",
    photo: "",
    role: "user",
    verified: false,
    blocked: [],
    created: new Date().toISOString(),
    password: await hashPassword(input.password),
  };
  const users = getStoredUsers();
  users.push(user);
  if (!saveUsers(users)) return { ok: false, errors: { form: "quota" } };
  createSession(user.id);
  addNotification(user.id, { kind: "welcome", link: "#/compte" });
  emit("auth");
  return { ok: true, user };
}

export async function login(identifier, password) {
  const lock = loginLock();
  if (lock.remaining > 0) return { ok: false, error: "locked", remaining: lock.remaining };
  const id = cleanText(identifier, 120).toLowerCase();
  let record = null;
  if (id === "admin" || id === ADMIN_ACCOUNT.email) record = ADMIN_ACCOUNT;
  else record = getStoredUsers().find((u) => u.email === id) || null;

  // On calcule toujours une empreinte, même si le compte n'existe pas :
  // le temps de réponse ne révèle donc pas si l'e-mail est inscrit.
  const valid = record ? await verifyPassword(password, record.password) : (await hashPassword(String(password || "x")), false);
  if (!valid) {
    registerFailure();
    const after = loginLock();
    return { ok: false, error: after.remaining > 0 ? "locked" : "invalid", remaining: after.remaining };
  }
  resetFailures();
  createSession(record.id);
  emit("auth");
  return { ok: true };
}

export function logout() {
  destroySession();
  emit("auth");
}

function updateUserRecord(id, updater) {
  if (id === ADMIN_ACCOUNT.id) {
    const current = storage.get("adminProfile", {});
    const next = updater({ ...ADMIN_ACCOUNT, ...current });
    const { password, id: _i, email, role, ...profile } = next;
    storage.set("adminProfile", profile);
    return true;
  }
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.id === id);
  if (index < 0) return false;
  users[index] = updater(users[index]);
  return saveUsers(users);
}

export function updateProfile(patch) {
  const me = currentUser();
  if (!me) return { ok: false };
  const loc = patch.city !== undefined ? LOCALITIES.find((l) => l.name === patch.city) : null;
  const ok = updateUserRecord(me.id, (u) => ({
    ...u,
    firstname: patch.firstname !== undefined ? cleanText(patch.firstname, 40) || u.firstname : u.firstname,
    lastname: patch.lastname !== undefined ? cleanText(patch.lastname, 40) || u.lastname : u.lastname,
    city: patch.city !== undefined ? cleanText(patch.city, 60) || u.city : u.city,
    canton: loc ? loc.canton : CANTON_CODES.includes(patch.canton) ? patch.canton : u.canton,
    bio: patch.bio !== undefined ? cleanText(patch.bio, 400, true) : u.bio,
    languages: Array.isArray(patch.languages) ? patch.languages.filter((l) => LANGS.includes(l)) : u.languages,
    specialties: Array.isArray(patch.specialties) ? patch.specialties.map((s) => cleanText(s, 30)).filter(Boolean).slice(0, 8) : u.specialties,
    photo: patch.photo !== undefined ? safeImageSrc(patch.photo) : u.photo,
  }));
  if (!ok) return { ok: false, error: "quota" };
  emit("profile");
  return { ok: true };
}

export async function changePassword(oldPassword, newPassword) {
  const me = currentUser();
  if (!me || me.role === "admin") return { ok: false, error: "forbidden" };
  const record = findUserRecord(me.id);
  if (!(await verifyPassword(oldPassword, record.password))) return { ok: false, error: "invalid" };
  if (!passwordStrength(newPassword, [me.firstname, me.lastname]).ok) return { ok: false, error: "weak" };
  const password = await hashPassword(newPassword);
  updateUserRecord(me.id, (u) => ({ ...u, password }));
  return { ok: true };
}

/** Droit à l'effacement (nLPD) : supprime le compte et toutes ses données. */
export async function deleteAccount(password) {
  const me = currentUser();
  if (!me || me.role === "admin") return { ok: false, error: "forbidden" };
  const record = findUserRecord(me.id);
  if (!(await verifyPassword(password, record.password))) return { ok: false, error: "invalid" };
  saveUsers(getStoredUsers().filter((u) => u.id !== me.id));
  storage.set("listings", getUserListings().filter((l) => l.authorId !== me.id));
  storage.set("conversations", getConversationsRaw().filter((c) => !c.participants.includes(me.id)));
  const favs = storage.get("favorites", {});
  delete favs[me.id];
  storage.set("favorites", favs);
  const notifs = storage.get("notifications", {});
  delete notifs[me.id];
  storage.set("notifications", notifs);
  destroySession();
  bump();
  emit("auth");
  return { ok: true };
}

/** Droit d'accès / portabilité (nLPD) : export de toutes mes données. */
export function exportMyData() {
  const me = currentUser();
  if (!me) return null;
  return {
    exportedAt: new Date().toISOString(),
    service: "Voisina (prototype)",
    profile: me,
    listings: getUserListings().filter((l) => l.authorId === me.id),
    favorites: getFavorites(),
    conversations: getConversationsRaw().filter((c) => c.participants.includes(me.id)),
    reports: getReports().filter((r) => r.by === me.id),
    notifications: getNotifications(),
  };
}

export function toggleBlock(personId) {
  const me = currentUser();
  if (!me || personId === me.id) return false;
  let blockedNow = false;
  updateUserRecord(me.id, (u) => {
    const list = new Set(u.blocked || []);
    if (list.has(personId)) list.delete(personId);
    else { list.add(personId); blockedNow = true; }
    return { ...u, blocked: [...list] };
  });
  bump();
  emit("block");
  return blockedNow;
}

export const isBlocked = (personId) => (currentUser()?.blocked || []).includes(personId);

export function getAllUsersForAdmin() {
  if (!isAdmin()) return [];
  return getStoredUsers().map(({ password, ...u }) => u);
}

/* ============================== ANNONCES ============================== */
let version = 0;
let listingsCache = null;
function bump() { version++; listingsCache = null; }

const getUserListings = () => {
  const list = storage.get("listings", []);
  return Array.isArray(list) ? list : [];
};

function getModeration() {
  return storage.get("moderation", { hidden: [] });
}

/** Toutes les annonces (démo + membres), sans filtre de blocage. */
function allListingsRaw() {
  if (listingsCache) return listingsCache;
  const hidden = new Set(getModeration().hidden || []);
  const demo = getDemoData().listings.map((l) => (hidden.has(l.id) ? { ...l, status: "hidden" } : l));
  const users = getUserListings().map((l) => (hidden.has(l.id) ? { ...l, status: "hidden" } : l));
  listingsCache = [...users, ...demo];
  return listingsCache;
}

/** Annonces visibles par l'utilisateur actuel. */
export function allListings({ includeInactive = false } = {}) {
  const blocked = new Set(currentUser()?.blocked || []);
  return allListingsRaw().filter((l) => (includeInactive || l.status === "active") && !blocked.has(l.authorId));
}

export function getListing(id) {
  return allListingsRaw().find((l) => l.id === String(id)) || null;
}

export const listingsByAuthor = (authorId, opts) => allListings(opts).filter((l) => l.authorId === authorId);

/** Valide et nettoie une annonce. Retourne { data } ou { errors }. */
export function validateListing(input) {
  const errors = {};
  const title = cleanText(input.title, 90);
  const description = cleanText(input.description, 1500, true);
  if (title.length < 5) errors.title = "min5";
  if (description.length < 20) errors.description = "min20";
  if (!TYPES.includes(input.type)) errors.type = "required";
  if (!CATEGORY_IDS.includes(input.category)) errors.category = "required";
  if (!PAYMENTS.includes(input.payment)) errors.payment = "required";
  const loc = LOCALITIES.find((l) => l.name === input.city);
  const lat = Number(input.lat ?? loc?.lat);
  const lng = Number(input.lng ?? loc?.lng);
  const canton = CANTON_CODES.includes(input.canton) ? input.canton : loc?.canton;
  if (!input.city || !canton || !inSwitzerland(lat, lng)) errors.city = "location";
  let amount = null;
  if (input.payment === "paid") {
    amount = Math.round(Number(input.amount) * 2) / 2;
    if (!Number.isFinite(amount) || amount <= 0 || amount > 5000) errors.amount = "amount";
  }
  let date = null;
  let time = null;
  if (input.date) {
    const d = parseDateKey(input.date);
    const max = new Date();
    max.setFullYear(max.getFullYear() + 1);
    if (!d || input.date < todayKey() || d > max) errors.date = "date";
    else date = input.date;
    if (input.time) {
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.time)) errors.time = "time";
      else time = input.time;
    }
  }
  const duration = DURATIONS.includes(Number(input.duration)) ? Number(input.duration) : null;
  const photos = (Array.isArray(input.photos) ? input.photos : []).map(safeImageSrc).filter(Boolean).slice(0, 3);
  const npa = /^\d{4}$/.test(String(input.npa || "")) ? String(input.npa) : loc?.npa || "";

  if (Object.keys(errors).length) return { errors };
  // Position floutée autour du centre de la localité (jamais l'adresse exacte).
  const jitter = () => (Math.random() - 0.5) * 0.02;
  return {
    data: {
      type: input.type,
      category: input.category,
      title,
      description,
      lang: LANGS.includes(input.lang) ? input.lang : getLang(),
      payment: input.payment,
      amount,
      unit: UNITS.includes(input.unit) ? input.unit : "total",
      date,
      time,
      duration,
      recurrence: RECURRENCES.includes(input.recurrence) ? input.recurrence : "once",
      urgent: !!input.urgent,
      city: cleanText(input.city, 60),
      npa,
      canton,
      lat: Math.round((lat + jitter()) * 10000) / 10000,
      lng: Math.round((lng + jitter()) * 10000) / 10000,
      languages: (Array.isArray(input.languages) ? input.languages : []).filter((l) => LANGS.includes(l)),
      photos,
    },
  };
}

export function createListing(input) {
  const me = currentUser();
  if (!me) return { ok: false, errors: { form: "auth" } };
  const { data, errors } = validateListing(input);
  if (errors) return { ok: false, errors };
  const listing = { ...data, id: uid("u"), authorId: me.id, demo: false, created: new Date().toISOString(), status: "active", views: 0 };
  const list = getUserListings();
  list.unshift(listing);
  if (!storage.set("listings", list)) return { ok: false, errors: { form: "quota" } };
  bump();
  addNotification(me.id, { kind: "published", params: { title: listing.title }, link: `#/annonce/${listing.id}` });
  emit("listings");
  return { ok: true, listing };
}

export function updateListing(id, input) {
  const me = currentUser();
  const list = getUserListings();
  const index = list.findIndex((l) => l.id === id);
  if (!me || index < 0 || (list[index].authorId !== me.id && me.role !== "admin")) return { ok: false, errors: { form: "forbidden" } };
  const { data, errors } = validateListing(input);
  if (errors) return { ok: false, errors };
  // On garde la position existante si la localité n'a pas changé.
  if (list[index].city === data.city) { data.lat = list[index].lat; data.lng = list[index].lng; }
  list[index] = { ...list[index], ...data, updated: new Date().toISOString() };
  if (!storage.set("listings", list)) return { ok: false, errors: { form: "quota" } };
  bump();
  emit("listings");
  return { ok: true, listing: list[index] };
}

export function setListingStatus(id, status) {
  const me = currentUser();
  const list = getUserListings();
  const index = list.findIndex((l) => l.id === id);
  if (!me || index < 0 || (list[index].authorId !== me.id && me.role !== "admin")) return false;
  if (!["active", "done"].includes(status)) return false;
  list[index] = { ...list[index], status };
  storage.set("listings", list);
  bump();
  emit("listings");
  return true;
}

export function deleteListing(id) {
  const me = currentUser();
  const list = getUserListings();
  const target = list.find((l) => l.id === id);
  if (!me || !target || (target.authorId !== me.id && me.role !== "admin")) return false;
  storage.set("listings", list.filter((l) => l.id !== id));
  bump();
  emit("listings");
  return true;
}

/** Recherche + filtres + tri. `origin` = point de référence pour la distance. */
export function searchListings(f = {}, origin = null) {
  const q = String(f.q || "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const words = q.split(/\s+/).filter(Boolean);
  const lang = getLang();
  let results = allListings().map((l) => ({ listing: l, distance: origin ? distanceKm(origin, l) : null }));

  results = results.filter(({ listing: l, distance }) => {
    if (f.type && l.type !== f.type) return false;
    if (f.cat && l.category !== f.cat) return false;
    if (f.canton && l.canton !== f.canton) return false;
    if (f.pay && l.payment !== f.pay) return false;
    if (f.urgent && !l.urgent) return false;
    if (f.verified && !getPerson(l.authorId)?.verified) return false;
    if (f.radius && origin && distance !== null && distance > Number(f.radius)) return false;
    if (f.bounds) {
      const [s, w, n, e] = f.bounds;
      if (l.lat < s || l.lat > n || l.lng < w || l.lng > e) return false;
    }
    if (words.length) {
      const title = typeof l.title === "object" ? Object.values(l.title).join(" ") : l.title;
      const desc = typeof l.description === "object" ? l.description[lang] || "" : l.description;
      const hay = `${title} ${desc} ${l.city} ${l.npa} ${l.canton} ${categoryName(l.category)}`.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
      if (!words.every((w) => hay.includes(w))) return false;
    }
    return true;
  });

  const sort = f.sort || (origin ? "distance" : "recent");
  const byDate = (a, b) => new Date(b.listing.created) - new Date(a.listing.created);
  if (sort === "distance" && origin) results.sort((a, b) => a.distance - b.distance);
  else if (sort === "soon") results.sort((a, b) => (a.listing.date || "9999").localeCompare(b.listing.date || "9999") || (a.listing.time || "").localeCompare(b.listing.time || ""));
  else if (sort === "priceLow") results.sort((a, b) => (a.listing.amount || 0) - (b.listing.amount || 0));
  else if (sort === "priceHigh") results.sort((a, b) => (b.listing.amount || 0) - (a.listing.amount || 0));
  else results.sort(byDate);
  return results;
}

/* ============================== FAVORIS =============================== */
const favOwner = () => currentUser()?.id || "guest";

export function getFavorites() {
  const all = storage.get("favorites", {});
  const list = all[favOwner()];
  return Array.isArray(list) ? list : [];
}

export const isFavorite = (id) => getFavorites().includes(id);

export function toggleFavorite(id) {
  if (!getListing(id)) return false;
  const all = storage.get("favorites", {});
  const owner = favOwner();
  const list = new Set(Array.isArray(all[owner]) ? all[owner] : []);
  const added = !list.has(id);
  if (added) list.add(id); else list.delete(id);
  all[owner] = [...list];
  storage.set("favorites", all);
  emit("favorites");
  return added;
}

export function clearFavorites() {
  const all = storage.get("favorites", {});
  all[favOwner()] = [];
  storage.set("favorites", all);
  emit("favorites");
}

/** Au moment de la connexion, on fusionne les favoris "invité" dans le compte. */
export function mergeGuestFavorites() {
  const me = currentUser();
  if (!me) return;
  const all = storage.get("favorites", {});
  if (!all.guest?.length) return;
  all[me.id] = [...new Set([...(all[me.id] || []), ...all.guest])];
  all.guest = [];
  storage.set("favorites", all);
}

/* ============================ MESSAGERIE ============================== */
function getConversationsRaw() {
  const list = storage.get("conversations", []);
  return Array.isArray(list) ? list : [];
}
const saveConversations = (list) => storage.set("conversations", list);

export function getConversations() {
  const me = currentUser();
  if (!me) return [];
  const blocked = new Set(me.blocked || []);
  return getConversationsRaw()
    .filter((c) => c.participants.includes(me.id))
    .filter((c) => !blocked.has(c.participants.find((p) => p !== me.id)))
    .sort((a, b) => new Date(b.updated) - new Date(a.updated));
}

export const getConversation = (id) => getConversations().find((c) => c.id === id) || null;

export function otherParticipant(conv) {
  const me = currentUser();
  return conv.participants.find((p) => p !== me?.id);
}

export function unreadCount(conv) {
  const me = currentUser();
  if (!me) return 0;
  const lastRead = conv.readBy?.[me.id] || 0;
  return conv.messages.filter((m) => m.from !== me.id && new Date(m.at).getTime() > lastRead).length;
}

export const totalUnread = () => getConversations().reduce((sum, c) => sum + unreadCount(c), 0);

/** Ouvre (ou retrouve) la conversation liée à une annonce. */
export function startConversation(listingId) {
  const me = currentUser();
  const listing = getListing(listingId);
  if (!me || !listing || listing.authorId === me.id) return null;
  const list = getConversationsRaw();
  let conv = list.find((c) => c.listingId === listingId && c.participants.includes(me.id));
  if (!conv) {
    conv = { id: uid("c_"), listingId, participants: [me.id, listing.authorId], messages: [], readBy: { [me.id]: Date.now() }, updated: new Date().toISOString(), created: new Date().toISOString() };
    list.push(conv);
    saveConversations(list);
    emit("messages");
  }
  return conv;
}

export const typing = new Set();

export function sendMessage(convId, text) {
  const me = currentUser();
  const body = cleanText(text, 1000, true);
  if (!me || !body) return { ok: false };
  const list = getConversationsRaw();
  const conv = list.find((c) => c.id === convId && c.participants.includes(me.id));
  if (!conv) return { ok: false };
  const now = new Date().toISOString();
  conv.messages.push({ id: uid("m_"), from: me.id, text: body, at: now });
  conv.updated = now;
  conv.readBy = { ...conv.readBy, [me.id]: Date.now() };
  if (!saveConversations(list)) return { ok: false, error: "quota" };
  const other = conv.participants.find((p) => p !== me.id);
  if (getDemoData().authorsById.has(other)) scheduleDemoReply(conv.id, other);
  else addNotification(other, { kind: "message", params: { name: displayName(me) }, link: `#/messages/${conv.id}` });
  emit("messages");
  return { ok: true };
}

const DEMO_REPLIES = {
  fr: ["Bonjour {name} ! Merci pour votre message. Oui, c'est toujours d'actualité 🙂 Quand seriez-vous disponible ?", "Parfait, ça me convient. Je vous propose qu'on se retrouve d'abord dans un lieu public, par exemple devant la gare de {city}.", "Super, merci beaucoup ! À bientôt."],
  de: ["Hallo {name}! Danke für Ihre Nachricht. Ja, das ist noch aktuell 🙂 Wann hätten Sie Zeit?", "Perfekt, das passt mir. Ich schlage vor, dass wir uns zuerst an einem öffentlichen Ort treffen, zum Beispiel beim Bahnhof {city}.", "Super, vielen Dank! Bis bald."],
  it: ["Buongiorno {name}! Grazie per il messaggio. Sì, è ancora attuale 🙂 Quando sarebbe disponibile?", "Perfetto, mi va bene. Propongo di incontrarci prima in un luogo pubblico, per esempio davanti alla stazione di {city}.", "Ottimo, grazie mille! A presto."],
  en: ["Hi {name}! Thanks for your message. Yes, it's still available 🙂 When would suit you?", "Perfect, that works for me. I suggest we first meet somewhere public, for example outside {city} station.", "Great, thank you so much! See you soon."],
};

function scheduleDemoReply(convId, authorId) {
  typing.add(convId);
  setTimeout(() => emit("typing"), 50);
  setTimeout(() => {
    typing.delete(convId);
    const list = getConversationsRaw();
    const conv = list.find((c) => c.id === convId);
    const me = currentUser();
    if (!conv || !me) { emit("messages"); return; }
    const theirs = conv.messages.filter((m) => m.from === authorId).length;
    const lines = DEMO_REPLIES[getLang()] || DEMO_REPLIES.fr;
    const listing = getListing(conv.listingId);
    const text = lines[Math.min(theirs, lines.length - 1)].replace("{name}", me.firstname).replace("{city}", listing?.city || "");
    const now = new Date().toISOString();
    conv.messages.push({ id: uid("m_"), from: authorId, text, at: now, auto: true });
    conv.updated = now;
    saveConversations(list);
    const author = getPerson(authorId);
    addNotification(me.id, { kind: "message", params: { name: author?.name || "" }, link: `#/messages/${convId}` });
    emit("messages");
  }, 1600 + Math.random() * 1200);
}

export function markConversationRead(convId) {
  const me = currentUser();
  if (!me) return;
  const list = getConversationsRaw();
  const conv = list.find((c) => c.id === convId && c.participants.includes(me.id));
  if (!conv || unreadCount(conv) === 0) return;
  conv.readBy = { ...conv.readBy, [me.id]: Date.now() };
  saveConversations(list);
  emit("read");
}

export function deleteConversation(convId) {
  const me = currentUser();
  if (!me) return;
  saveConversations(getConversationsRaw().filter((c) => !(c.id === convId && c.participants.includes(me.id))));
  emit("messages");
}

/* ============================ SIGNALEMENTS ============================ */
export const REPORT_REASONS = ["scam", "inappropriate", "dangerous", "spam", "illegal", "other"];

export function getReports() {
  const list = storage.get("reports", []);
  return Array.isArray(list) ? list : [];
}

export function createReport({ targetType, targetId, reason, details }) {
  const me = currentUser();
  if (!["listing", "user", "conversation"].includes(targetType) || !REPORT_REASONS.includes(reason)) return false;
  const list = getReports();
  list.unshift({ id: uid("r_"), targetType, targetId: String(targetId), reason, details: cleanText(details, 500, true), by: me?.id || "guest", at: new Date().toISOString(), status: "open" });
  storage.set("reports", list.slice(0, 500));
  emit("reports");
  return true;
}

export function resolveReport(id, action) {
  if (!isAdmin()) return false;
  const list = getReports();
  const report = list.find((r) => r.id === id);
  if (!report) return false;
  report.status = action === "hide" ? "actioned" : "dismissed";
  report.resolvedAt = new Date().toISOString();
  storage.set("reports", list);
  if (action === "hide" && report.targetType === "listing") setListingHidden(report.targetId, true);
  if (report.by && report.by !== "guest") addNotification(report.by, { kind: "reportDone", link: "#/" });
  emit("reports");
  return true;
}

export function setListingHidden(id, hidden) {
  if (!isAdmin()) return false;
  const mod = getModeration();
  const set = new Set(mod.hidden || []);
  if (hidden) set.add(id); else set.delete(id);
  storage.set("moderation", { ...mod, hidden: [...set] });
  bump();
  emit("listings");
  return true;
}

export const isHidden = (id) => (getModeration().hidden || []).includes(id);

/* =========================== NOTIFICATIONS ============================ */
export function addNotification(userId, { kind, params = {}, link = "" }) {
  if (!userId) return;
  const all = storage.get("notifications", {});
  const list = Array.isArray(all[userId]) ? all[userId] : [];
  list.unshift({ id: uid("n_"), kind, params, link, at: new Date().toISOString(), read: false });
  all[userId] = list.slice(0, 50);
  storage.set("notifications", all);
  emit("notifications");
}

export function getNotifications() {
  const me = currentUser();
  if (!me) return [];
  const list = storage.get("notifications", {})[me.id];
  return Array.isArray(list) ? list : [];
}

export function markNotificationsRead() {
  const me = currentUser();
  if (!me) return;
  const all = storage.get("notifications", {});
  (all[me.id] || []).forEach((n) => { n.read = true; });
  storage.set("notifications", all);
  emit("notifications");
}

/* ============================ PRÉFÉRENCES ============================= */
export function getPrefs() {
  return storage.get("prefs", {});
}

export function setPrefs(patch) {
  storage.set("prefs", { ...getPrefs(), ...patch });
  emit("prefs");
}

/** Point de référence choisi pour calculer les distances (reste sur l'appareil). */
export function getOrigin() {
  const o = storage.get("origin", null);
  return o && inSwitzerland(o.lat, o.lng) ? o : null;
}

export function setOrigin(origin) {
  if (origin && inSwitzerland(origin.lat, origin.lng)) {
    storage.set("origin", { lat: Math.round(origin.lat * 1000) / 1000, lng: Math.round(origin.lng * 1000) / 1000, label: cleanText(origin.label, 60) });
  } else storage.remove("origin");
  emit("origin");
}

/* ============================ STATISTIQUES ============================ */
export function stats() {
  const listings = allListingsRaw();
  return {
    active: listings.filter((l) => l.status === "active").length,
    userListings: getUserListings().length,
    users: getStoredUsers().length,
    reportsOpen: getReports().filter((r) => r.status === "open").length,
    conversations: getConversationsRaw().length,
    messages: getConversationsRaw().reduce((s, c) => s + c.messages.length, 0),
    hidden: (getModeration().hidden || []).length,
  };
}

export const dataVersion = () => version;
