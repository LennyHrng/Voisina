/* =====================================================================
   VOISINA — point d'entrée de l'application
   ---------------------------------------------------------------------
   - Routeur : chaque "page" correspond à une adresse #/... (liens
     partageables, bouton retour du navigateur fonctionnel).
   - En-tête, pied de page, barre mobile, notifications.
   - Délégation des clics : un seul écouteur gère tous les boutons
     data-action (compatible avec notre politique de sécurité CSP).
   ===================================================================== */
import { html, raw, $, $$, mount, storage } from "./util.js";
import { icon, logo } from "./icons.js";
import { t, getLang, setLang, fmtRelative } from "./i18n.js";
import { LANGS } from "./data.js";
import * as store from "./store.js";
import { actions, registerActions, toast, initDialog, avatar } from "./ui.js";

import home from "./views/home.js";
import explore, { exploreActions } from "./views/explore.js";
import listing, { listingActions } from "./views/listing.js";
import publish, { publishActions } from "./views/publish.js";
import messages, { messagesActions } from "./views/messages.js";
import planning, { planningActions } from "./views/planning.js";
import auth, { authActions } from "./views/auth.js";
import account, { accountActions } from "./views/account.js";
import profile from "./views/profile.js";
import admin, { adminActions } from "./views/admin.js";
import pages from "./views/pages.js";

/* ------------------------------ Routes ------------------------------ */
const notFound = {
  title: () => t("notFound.title"),
  render: () => html`<section class="section"><div class="container narrow center">
    <p class="big-404">404</p><h1 class="h2">${t("notFound.title")}</h1><p class="muted">${t("notFound.text")}</p>
    <a class="btn btn-primary" href="#/">${t("notFound.home")}</a></div></section>`,
};

const ROUTES = [
  [/^$/, home],
  [/^explorer$/, explore],
  [/^annonce\/([\w-]{1,40})$/, listing],
  [/^publier$/, publish],
  [/^messages(?:\/([\w-]{1,40}))?$/, messages],
  [/^planning$/, planning],
  [/^connexion$/, auth],
  [/^compte$/, account],
  [/^membre\/([\w-]{1,40})$/, profile],
  [/^admin$/, admin],
  [/^page\/([\w-]{1,40})$/, pages],
];

let currentView = null;
let currentCtx = null;

function parseHash() {
  const hash = location.hash.replace(/^#\/?/, "");
  const [path, qs = ""] = hash.split("?");
  return { path: decodeURIComponent(path).replace(/\/$/, ""), query: new URLSearchParams(qs) };
}

function render({ keepScroll = false } = {}) {
  const { path, query } = parseHash();
  let view = notFound;
  let params = [];
  for (const [re, v] of ROUTES) {
    const m = re.exec(path);
    if (m) { view = v; params = m.slice(1); break; }
  }
  const sameView = view === currentView && currentCtx?.path === path;
  if (currentView?.unmount) { try { currentView.unmount(); } catch (e) { console.error(e); } }
  currentView = view;
  currentCtx = { path, params, query };

  const root = $("#view");
  const y = window.scrollY;
  try {
    mount(root, view.render(currentCtx));
    view.mount?.(root, currentCtx);
  } catch (e) {
    console.error(e);
    mount(root, html`<section class="section"><div class="container narrow center"><h1 class="h2">${t("err.pageTitle")}</h1><p class="muted">${t("err.pageText")}</p><a class="btn btn-primary" href="#/">${t("notFound.home")}</a></div></section>`);
  }
  document.title = `${view.title ? view.title(currentCtx) + " · " : ""}Voisina`;
  if (keepScroll || sameView) window.scrollTo(0, y);
  else window.scrollTo(0, 0);
  if (!keepScroll && !sameView) $("#main").focus({ preventScroll: true });
  renderChrome();
}

/* ----------------------- En-tête et navigation ---------------------- */
const NAV = [
  ["explorer", "search", "nav.explore"],
  ["planning", "calendar", "nav.planning"],
  ["messages", "message", "nav.messages"],
  ["page/securite", "shield", "nav.safety"],
];

function isActive(route) {
  const { path } = parseHash();
  return path === route || path.startsWith(route + "/") ? " is-active" : "";
}

function notificationText(n) {
  const key = `notif.${n.kind}`;
  return t(key, n.params || {});
}

function renderHeader() {
  const me = store.currentUser();
  const unread = me ? store.totalUnread() : 0;
  const notifs = store.getNotifications();
  const unreadNotifs = notifs.filter((n) => !n.read).length;
  const theme = document.documentElement.getAttribute("data-theme");
  const dark = theme === "dark" || (!theme && window.matchMedia("(prefers-color-scheme: dark)").matches);

  mount($("#site-header"), html`
  <div class="container header-inner">
    <a class="brand" href="#/" aria-label="${t("nav.home")} — Voisina">${logo()}<span class="brand-name">Voisina</span></a>
    <nav class="main-nav" aria-label="${t("nav.main")}">
      ${NAV.map(([route, ic, key]) => html`<a class="nav-link${isActive(route)}" href="#/${route}" ${isActive(route) ? raw('aria-current="page"') : ""}>${icon(ic)}<span>${t(key)}</span>${route === "messages" && unread ? html`<span class="badge-count">${unread}</span>` : ""}</a>`)}
    </nav>
    <div class="header-actions">
      <a class="btn btn-primary btn-publish" href="#/publier">${icon("plus")}<span>${t("nav.publish")}</span></a>
      <div class="menu-wrap">
        <button type="button" class="icon-btn lang-btn" data-action="toggle-menu" data-menu="lang" aria-haspopup="true" aria-expanded="false" aria-label="${t("nav.language")}">${icon("globe")}<span>${getLang().toUpperCase()}</span></button>
        <div class="menu" id="menu-lang" hidden>
          ${LANGS.map((l) => html`<button type="button" class="menu-item${l === getLang() ? " is-active" : ""}" data-action="set-lang" data-lang="${l}" lang="${l}">${t("lang." + l)}${l === getLang() ? icon("check") : ""}</button>`)}
        </div>
      </div>
      <button type="button" class="icon-btn theme-btn" data-action="toggle-theme" aria-label="${dark ? t("theme.toLight") : t("theme.toDark")}" title="${dark ? t("theme.toLight") : t("theme.toDark")}">${icon(dark ? "sun" : "moon")}</button>
      ${me
        ? html`
        <div class="menu-wrap">
          <button type="button" class="icon-btn" data-action="toggle-menu" data-menu="notif" aria-haspopup="true" aria-expanded="false" aria-label="${t("notif.title")}${unreadNotifs ? ` (${unreadNotifs})` : ""}">${icon("bell")}${unreadNotifs ? html`<span class="dot-count">${unreadNotifs}</span>` : ""}</button>
          <div class="menu menu-wide" id="menu-notif" hidden>
            <div class="menu-head"><strong>${t("notif.title")}</strong>${unreadNotifs ? html`<button type="button" class="link-btn" data-action="notif-read">${t("notif.markRead")}</button>` : ""}</div>
            ${notifs.length ? notifs.slice(0, 8).map((n) => html`<a class="notif-item${n.read ? "" : " is-unread"}" href="${/^#\/[\w\-/?=&%.]*$/.test(n.link) ? n.link : "#/"}">
              <span class="notif-icon">${icon(n.kind === "message" ? "message" : n.kind === "published" ? "checkCircle" : n.kind === "reportDone" ? "shieldCheck" : "sparkles")}</span>
              <span><span class="notif-text">${notificationText(n)}</span><span class="notif-time">${fmtRelative(n.at)}</span></span></a>`) : html`<p class="menu-empty">${t("notif.empty")}</p>`}
          </div>
        </div>
        <div class="menu-wrap">
          <button type="button" class="avatar-btn" data-action="toggle-menu" data-menu="account" aria-haspopup="true" aria-expanded="false" aria-label="${t("nav.account")}">${avatar(store.getPerson(me.id), "sm")}</button>
          <div class="menu" id="menu-account" hidden>
            <div class="menu-head menu-user"><strong>${me.firstname} ${me.lastname}</strong><span class="muted small">${me.email}</span></div>
            <a class="menu-item" href="#/compte">${icon("user")}${t("nav.account")}</a>
            <a class="menu-item" href="#/compte?tab=listings">${icon("file")}${t("account.myListings")}</a>
            <a class="menu-item" href="#/planning">${icon("heart")}${t("nav.planning")}</a>
            ${me.role === "admin" ? html`<a class="menu-item" href="#/admin">${icon("shield")}${t("nav.admin")}</a>` : ""}
            <button type="button" class="menu-item" data-action="logout">${icon("logout")}${t("nav.logout")}</button>
          </div>
        </div>`
        : html`<a class="btn btn-ghost btn-login" href="#/connexion">${icon("user")}<span>${t("nav.login")}</span></a>`}
    </div>
  </div>`);
}

function renderTabbar() {
  const me = store.currentUser();
  const unread = me ? store.totalUnread() : 0;
  const { path } = parseHash();
  const tab = (route, ic, label, extra = "") => {
    const active = route === "" ? path === "" : path === route || path.startsWith(route + "/");
    return html`<a class="tab-link${active ? " is-active" : ""}" href="#/${route}" ${active ? raw('aria-current="page"') : ""}>${icon(ic)}<span>${label}</span>${extra}</a>`;
  };
  mount($("#tabbar"), html`
    ${tab("", "home", t("nav.home"))}
    ${tab("explorer", "search", t("nav.explore"))}
    <a class="tab-publish" href="#/publier" aria-label="${t("nav.publish")}">${icon("plus")}</a>
    ${tab("messages", "message", t("nav.messagesShort"), unread ? html`<span class="badge-count">${unread}</span>` : "")}
    ${tab(me ? "compte" : "connexion", "user", me ? t("nav.profile") : t("nav.login"))}`);
}

function renderFooter() {
  mount($("#site-footer"), html`
  <div class="container footer-grid">
    <div class="footer-brand">
      <a class="brand" href="#/">${logo()}<span class="brand-name">Voisina</span></a>
      <p>${t("footer.tagline")}</p>
      <ul class="footer-badges">
        <li>${icon("eyeOff")}${t("footer.noTracking")}</li>
        <li>${icon("lock")}${t("footer.secure")}</li>
      </ul>
    </div>
    <div><h2 class="footer-title">${t("footer.explore")}</h2><ul>
      <li><a href="#/explorer">${t("footer.listings")}</a></li>
      <li><a href="#/explorer?view=map">${t("footer.map")}</a></li>
      <li><a href="#/publier">${t("nav.publish")}</a></li>
      <li><a href="#/planning">${t("nav.planning")}</a></li>
    </ul></div>
    <div><h2 class="footer-title">${t("footer.community")}</h2><ul>
      <li><a href="#/page/aide">${t("footer.help")}</a></li>
      <li><a href="#/page/securite">${t("footer.safety")}</a></li>
      <li><a href="#/page/regles">${t("footer.rules")}</a></li>
      <li><a href="#/page/a-propos">${t("footer.about")}</a></li>
    </ul></div>
    <div><h2 class="footer-title">${t("footer.legal")}</h2><ul>
      <li><a href="#/page/confidentialite">${t("footer.privacy")}</a></li>
      <li><a href="#/page/conditions">${t("footer.terms")}</a></li>
      <li><a href="#/page/mentions-legales">${t("footer.imprint")}</a></li>
    </ul></div>
  </div>
  <div class="container footer-bottom">
    <span>© 2026 Voisina · ${t("footer.project")}</span>
    <span class="footer-langs">${LANGS.map((l) => html`<button type="button" class="link-btn${l === getLang() ? " is-active" : ""}" data-action="set-lang" data-lang="${l}" lang="${l}">${l.toUpperCase()}</button>`)}</span>
    <span>${t("footer.madeIn")}</span>
  </div>`);
}

function renderBanner() {
  const banner = $("#demo-banner");
  if (store.getPrefs().bannerDismissed) { banner.hidden = true; return; }
  banner.hidden = false;
  mount(banner, html`<div class="container demo-banner-inner">${icon("info")}<p>${t("demo.banner")} <a href="#/page/a-propos">${t("demo.learnMore")}</a></p>
    <button type="button" class="icon-btn icon-btn-sm" data-action="dismiss-banner" aria-label="${t("common.close")}">${icon("x")}</button></div>`);
}

function renderChrome() {
  renderHeader();
  renderTabbar();
}

function renderAll() {
  renderBanner();
  renderFooter();
  render({ keepScroll: true });
}

/* ------------------------------ Menus ------------------------------ */
function closeMenus(except = null) {
  $$(".menu").forEach((m) => {
    if (m.id !== except) {
      m.hidden = true;
      const btn = document.querySelector(`[data-menu="${m.id.replace("menu-", "")}"]`);
      btn?.setAttribute("aria-expanded", "false");
    }
  });
}

/* ------------------------- Actions globales ------------------------ */
function applyTheme(theme) {
  if (theme === "dark" || theme === "light") document.documentElement.setAttribute("data-theme", theme);
  else document.documentElement.removeAttribute("data-theme");
}

registerActions({
  ...exploreActions, ...listingActions, ...publishActions, ...messagesActions,
  ...planningActions, ...authActions, ...accountActions, ...adminActions,

  "toggle-menu": (el) => {
    const menu = $(`#menu-${el.dataset.menu}`);
    const open = menu.hidden;
    closeMenus(open ? menu.id : null);
    menu.hidden = !open;
    el.setAttribute("aria-expanded", String(open));
    if (open) menu.querySelector("a, button")?.focus();
  },
  "set-lang": (el) => {
    setLang(el.dataset.lang);
    renderAll();
    toast(t("toast.langChanged"), "success");
  },
  "toggle-theme": () => {
    const current = document.documentElement.getAttribute("data-theme");
    const dark = current === "dark" || (!current && window.matchMedia("(prefers-color-scheme: dark)").matches);
    const next = dark ? "light" : "dark";
    store.setPrefs({ theme: next });
    applyTheme(next);
    renderHeader();
  },
  fav: (el) => {
    const id = el.dataset.id;
    if (!store.getListing(id)) return;
    const added = store.toggleFavorite(id);
    toast(added ? t("fav.added") : t("fav.removed"), "success");
  },
  "notif-read": () => { store.markNotificationsRead(); },
  skip: () => { $("#main").focus(); $("#main").scrollIntoView(); },
  "dismiss-banner": () => { store.setPrefs({ bannerDismissed: true }); renderBanner(); },
  locate: (el) => {
    if (!navigator.geolocation) { toast(t("loc.unsupported"), "error"); return; }
    el.disabled = true;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        el.disabled = false;
        const { latitude: lat, longitude: lng } = pos.coords;
        if (lat < 45.7 || lat > 47.95 || lng < 5.8 || lng > 10.6) { toast(t("loc.outside"), "info"); return; }
        store.setOrigin({ lat, lng, label: t("loc.myPosition") });
        toast(t("loc.found"), "success");
        const target = "#/explorer?radius=10&sort=distance";
        if (location.hash === target) render({ keepScroll: true });
        else location.hash = target;
      },
      () => { el.disabled = false; toast(t("loc.denied"), "error"); },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 600000 }
    );
  },
});

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (el && actions[el.dataset.action]) {
    if (el.tagName === "A") e.preventDefault();
    actions[el.dataset.action](el, e);
    if (el.dataset.action !== "toggle-menu") closeMenus();
    return;
  }
  if (!e.target.closest(".menu-wrap")) closeMenus();
  // Un clic sur un lien d'un menu le ferme
  if (e.target.closest(".menu a")) closeMenus();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeMenus();
});

/* --------------------- Réactions aux changements -------------------- */
store.onChange((kind) => {
  renderChrome();
  if (!currentView) return;
  currentView.onData?.(kind, currentCtx);
  if (currentView.refreshOn?.includes(kind)) render({ keepScroll: true });
});

window.addEventListener("hashchange", () => { closeMenus(); render(); });
window.addEventListener("voisina:lang", renderAll);
window.addEventListener("voisina:theme", () => { applyTheme(store.getPrefs().theme); renderHeader(); });
window.addEventListener("voisina:banner", renderBanner);
// Synchronisation entre plusieurs onglets ouverts
window.addEventListener("storage", (e) => { if (e.key?.startsWith("voisina:")) renderAll(); });

/* --------------------------- Démarrage ----------------------------- */
function start() {
  storage.purgeLegacy(); // efface les anciennes données (mots de passe en clair de la v1)
  document.documentElement.lang = getLang();
  initDialog();
  renderBanner();
  renderFooter();
  render();
  document.body.classList.add("is-ready");

  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
}

start();
