/* =====================================================================
   DONNÉES DE DÉMONSTRATION
   ---------------------------------------------------------------------
   Les annonces d'exemple sont générées avec une "graine" fixe : tout le
   monde voit exactement les mêmes annonces, sur tous les appareils.
   => un lien partagé (#/annonce/d42) mène à la même annonce chez un ami.
   Elles sont clairement signalées comme fictives dans l'interface.
   ===================================================================== */
import { LOCALITIES, TEMPLATES, NAMES, SPECIALTY_POOL, LANGS, CATEGORY_IDS } from "./data.js";
import { seededRandom, dateKey } from "./util.js";

const DEMO_COUNT = 420;
const BIG_CITIES = new Set(["Zürich", "Genève", "Basel", "Lausanne", "Bern", "Winterthur", "Luzern", "St. Gallen", "Lugano", "Biel/Bienne", "Fribourg", "Neuchâtel", "Sion"]);

const BIOS = {
  fr: ["J'habite le quartier depuis {n} ans et j'aime rendre service.", "Toujours partant·e pour un coup de main entre voisins !", "Parent de deux enfants, je crois beaucoup à l'entraide locale.", "Retraité·e actif·ve, j'ai du temps à partager."],
  de: ["Ich wohne seit {n} Jahren im Quartier und helfe gerne.", "Immer bereit für Nachbarschaftshilfe!", "Mutter/Vater von zwei Kindern – ich glaube an lokale Solidarität.", "Aktiv pensioniert, ich habe Zeit zu teilen."],
  it: ["Abito nel quartiere da {n} anni e mi piace dare una mano.", "Sempre pronto/a ad aiutare i vicini!", "Genitore di due figli, credo molto nell'aiuto reciproco.", "Pensionato/a attivo/a, ho tempo da condividere."],
};

let cache = null;

/** Génère (une seule fois) les membres et annonces de démonstration. */
export function getDemoData() {
  if (cache) return cache;
  const r = seededRandom(20260622);
  const pick = (arr) => arr[Math.floor(r() * arr.length)];

  // Localités pondérées : les grandes villes ont plus d'annonces.
  const weighted = [];
  LOCALITIES.forEach((loc) => {
    const w = BIG_CITIES.has(loc.name) ? 5 : 1;
    for (let i = 0; i < w; i++) weighted.push(loc);
  });

  const authors = [];
  const byLocality = new Map();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  function createAuthor(loc) {
    const lang = loc.lang === "it" ? "it" : loc.lang === "de" ? "de" : "fr";
    const first = pick(NAMES[lang].first);
    const last = pick(NAMES[lang].last);
    const cats = [pick(CATEGORY_IDS), pick(CATEGORY_IDS)];
    const specialties = [...new Set(cats.map((c) => SPECIALTY_POOL[c][LANGS.indexOf(lang)]))];
    const since = new Date(today.getTime() - Math.floor(30 + r() * 900) * 86400000);
    const author = {
      id: `du${authors.length + 1}`,
      demo: true,
      firstname: first,
      lastname: last,
      city: loc.name,
      canton: loc.canton,
      lang,
      verified: r() > 0.3,
      rating: Math.round((4.2 + r() * 0.8) * 10) / 10,
      reviews: Math.floor(r() * 60),
      completed: Math.floor(r() * 40),
      created: since.toISOString(),
      specialties,
      languages: lang === "fr" ? ["fr", r() > 0.6 ? "de" : "en"] : lang === "de" ? ["de", r() > 0.5 ? "fr" : "en"] : ["it", r() > 0.5 ? "fr" : "de"],
      bio: pick(BIOS[lang]).replace("{n}", String(2 + Math.floor(r() * 20))),
    };
    authors.push(author);
    if (!byLocality.has(loc.name)) byLocality.set(loc.name, []);
    byLocality.get(loc.name).push(author);
    return author;
  }

  const listings = [];
  for (let i = 1; i <= DEMO_COUNT; i++) {
    const loc = pick(weighted);
    const locals = byLocality.get(loc.name) || [];
    const author = locals.length && r() < 0.45 ? pick(locals) : createAuthor(loc);
    const tpl = pick(TEMPLATES);

    const createdDaysAgo = Math.floor(r() * 30);
    const created = new Date(Date.now() - createdDaysAgo * 86400000 - Math.floor(r() * 12) * 3600000);
    const hasDate = r() > 0.15;
    const eventDate = new Date(today.getTime() + (1 + Math.floor(r() * 45)) * 86400000);
    const hour = 8 + Math.floor(r() * 12);
    const minute = r() > 0.5 ? "30" : "00";
    let amount = tpl.amt;
    if (tpl.pay === "paid") amount = Math.max(5, tpl.amt + Math.round((r() - 0.5) * 4) * 5);

    listings.push({
      id: `d${i}`,
      demo: true,
      authorId: author.id,
      type: tpl.ty,
      category: tpl.c,
      title: tpl.t,
      description: tpl.d,
      payment: tpl.pay,
      amount: tpl.pay === "paid" ? amount : null,
      unit: tpl.unit,
      date: hasDate ? dateKey(eventDate) : null,
      time: hasDate ? `${String(hour).padStart(2, "0")}:${minute}` : null,
      duration: tpl.dur,
      recurrence: tpl.rec || "once",
      urgent: r() < 0.08,
      city: loc.name,
      npa: loc.npa,
      canton: loc.canton,
      // Position floutée (±1,5 km) : jamais l'adresse exacte.
      lat: Math.round((loc.lat + (r() - 0.5) * 0.028) * 10000) / 10000,
      lng: Math.round((loc.lng + (r() - 0.5) * 0.04) * 10000) / 10000,
      languages: author.languages,
      photos: [],
      created: created.toISOString(),
      status: "active",
      views: 5 + Math.floor(r() * 180),
    });
  }

  cache = { authors, listings, authorsById: new Map(authors.map((a) => [a.id, a])) };
  return cache;
}
